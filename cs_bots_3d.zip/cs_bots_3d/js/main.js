import { Game } from './game.js';

const menu = document.getElementById('menu');
const hud = document.getElementById('hud');
const pauseEl = document.getElementById('pause');
const viewport = document.getElementById('viewport');
const toastEl = document.getElementById('toast');
const feedEl = document.getElementById('feed');
const netBadge = document.getElementById('net-badge');
const netStatus = document.getElementById('net-status');
const roomInput = document.getElementById('room-code');

let mode = 'solo';
let game = null;
let peer = null;
let conn = null;
let toastT = 0;
let isHost = false;
let roomCode = '';

// Mode tabs
document.querySelectorAll('.mode-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.mode-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    mode = btn.dataset.mode;
    document.getElementById('solo-opts').classList.toggle('hidden', mode !== 'solo');
    document.getElementById('local-opts').classList.toggle('hidden', mode !== 'local');
    document.getElementById('online-opts').classList.toggle('hidden', mode !== 'online');
  });
});

function toast(msg, sec = 1.5) {
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  toastT = sec;
}
function feed(msg) {
  const d = document.createElement('div');
  d.textContent = msg;
  feedEl.prepend(d);
  while (feedEl.children.length > 6) feedEl.lastChild.remove();
  setTimeout(() => d.remove(), 4000);
}
function hudUpdate(s) {
  document.getElementById('hp-fill').style.width = Math.max(0, s.hp) + '%';
  document.getElementById('ammo').textContent = s.reloading ? '… / ' + s.reserve : s.mag + ' / ' + s.reserve;
  document.getElementById('wpn').textContent = s.weapon;
  document.getElementById('score').textContent = 'K ' + s.kills + ' · D ' + s.deaths;
}

setInterval(() => {
  if (toastT > 0) {
    toastT -= 0.1;
    if (toastT <= 0) toastEl.classList.remove('show');
  }
}, 100);

function genCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = '';
  for (let i = 0; i < 5; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function loadPeerJs() {
  return new Promise((resolve, reject) => {
    if (window.Peer) return resolve();
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js';
    s.onload = resolve;
    s.onerror = () => reject(new Error('PeerJS load failed'));
    document.head.appendChild(s);
  });
}

async function hostRoom() {
  try {
    await loadPeerJs();
    roomCode = genCode();
    roomInput.value = roomCode;
    netStatus.textContent = 'Создание комнаты…';
    peer = new Peer('cs3d-' + roomCode);
    peer.on('open', () => {
      isHost = true;
      netStatus.textContent = 'Код: ' + roomCode + ' — ждём друга…';
      netBadge.textContent = 'HOST ' + roomCode;
    });
    peer.on('connection', (c) => {
      conn = c;
      setupConn();
      netStatus.textContent = 'Друг подключился! Нажми «Играть»';
    });
    peer.on('error', (e) => { netStatus.textContent = 'Ошибка: ' + e.type; });
  } catch (e) {
    netStatus.textContent = 'Не удалось загрузить сеть. Проверь интернет.';
  }
}

async function joinRoom() {
  const code = (roomInput.value || '').trim().toUpperCase();
  if (code.length < 4) {
    netStatus.textContent = 'Введи код комнаты';
    return;
  }
  try {
    await loadPeerJs();
    netStatus.textContent = 'Подключение…';
    peer = new Peer();
    peer.on('open', () => {
      conn = peer.connect('cs3d-' + code, { reliable: true });
      setupConn();
      roomCode = code;
      isHost = false;
      netBadge.textContent = 'JOIN ' + code;
    });
    peer.on('error', (e) => { netStatus.textContent = 'Ошибка: ' + e.type; });
  } catch (e) {
    netStatus.textContent = 'Не удалось загрузить сеть.';
  }
}

function setupConn() {
  conn.on('open', () => {
    netStatus.textContent = 'Связь установлена ✓';
  });
  conn.on('data', (data) => {
    if (!game || !data) return;
    if (data.type === 'state') {
      game.ensureRemote(data.state.name);
      game.applyRemoteState(data.state);
    }
    if (data.type === 'hit') {
      game.remoteShootAtPlayer(data.dmg || 28);
    }
  });
  conn.on('close', () => {
    toast('Связь потеряна');
    netStatus.textContent = 'Отключено';
  });
}

function netSend(msg) {
  if (conn && conn.open) conn.send(msg);
}

function startGame() {
  if (game) {
    game.dispose();
    game = null;
  }
  if (mode === 'online' && (!conn || !conn.open)) {
    toast('Сначала подключи друга');
    netStatus.textContent = 'Нужно создать или войти в комнату';
    return;
  }

  menu.classList.add('hidden');
  pauseEl.classList.add('hidden');
  hud.classList.remove('hidden');
  netBadge.classList.toggle('hidden', mode !== 'online');

  const opts = {
    mode,
    botCount: +document.getElementById('bot-count').value,
    diff: document.getElementById('diff').value,
    onToast: toast,
    onFeed: feed,
    onHud: hudUpdate,
    onNetSend: mode === 'online' ? netSend : null,
  };

  game = new Game(viewport, opts);
  if (mode === 'online') {
    game.ensureRemote('Друг');
  }
  game.start();

  // pointer lock
  const canvas = game.renderer.domElement;
  canvas.requestPointerLock();
  canvas.addEventListener('click', () => {
    if (game && !game.paused) canvas.requestPointerLock();
  });
}

function quitToMenu() {
  if (game) {
    game.dispose();
    game = null;
  }
  document.exitPointerLock();
  hud.classList.add('hidden');
  pauseEl.classList.add('hidden');
  menu.classList.remove('hidden');
  feedEl.innerHTML = '';
}

document.getElementById('btn-play').addEventListener('click', startGame);
document.getElementById('btn-host').addEventListener('click', hostRoom);
document.getElementById('btn-join').addEventListener('click', joinRoom);
document.getElementById('btn-resume').addEventListener('click', () => {
  if (!game) return;
  pauseEl.classList.add('hidden');
  game.resume();
  game.renderer.domElement.requestPointerLock();
});
document.getElementById('btn-quit').addEventListener('click', quitToMenu);

window.addEventListener('keydown', (e) => {
  if (game) game.keys[e.code] = true;
  if (e.code === 'Escape') {
    if (!game) return;
    if (game.paused) {
      pauseEl.classList.add('hidden');
      game.resume();
      game.renderer.domElement.requestPointerLock();
    } else {
      game.pause();
      document.exitPointerLock();
      pauseEl.classList.remove('hidden');
    }
  }
  if (!game || game.paused) return;
  if (e.code === 'KeyR') game.reload();
  if (e.code === 'Enter' && mode === 'local') game.localP2Shoot();
});
window.addEventListener('keyup', (e) => {
  if (game) game.keys[e.code] = false;
});
window.addEventListener('mousedown', (e) => {
  if (e.button === 0 && game) game.keys['Mouse0'] = true;
});
window.addEventListener('mouseup', (e) => {
  if (e.button === 0 && game) game.keys['Mouse0'] = false;
});
document.addEventListener('mousemove', (e) => {
  if (!game || game.paused) return;
  if (document.pointerLockElement) {
    game.yaw += e.movementX * 0.0022;
    game.pitch -= e.movementY * 0.0022;
    game.pitch = Math.max(-1.4, Math.min(1.4, game.pitch));
  }
});
