import * as THREE from 'three';

/** Procedural textures + arena map */
function makeTex(draw, size = 128) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d');
  draw(g, size);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.magFilter = THREE.NearestFilter;
  return t;
}

const wallTex = makeTex((g, s) => {
  g.fillStyle = '#4a5568';
  g.fillRect(0, 0, s, s);
  for (let y = 0; y < s; y += 16) {
    for (let x = 0; x < s; x += 32) {
      const ox = (Math.floor(y / 16) % 2) * 16;
      g.fillStyle = '#3d4654';
      g.fillRect(x + ox, y, 30, 14);
      g.strokeStyle = '#2a3038';
      g.strokeRect(x + ox, y, 30, 14);
    }
  }
  // dirt
  g.fillStyle = 'rgba(0,0,0,0.15)';
  for (let i = 0; i < 40; i++) g.fillRect(Math.random() * s, Math.random() * s, 3, 3);
});
wallTex.repeat.set(2, 2);

const floorTex = makeTex((g, s) => {
  g.fillStyle = '#2c2418';
  g.fillRect(0, 0, s, s);
  for (let y = 0; y < s; y += 32) {
    for (let x = 0; x < s; x += 32) {
      g.fillStyle = (x + y) % 64 === 0 ? '#332a1c' : '#2a2216';
      g.fillRect(x, y, 31, 31);
      g.strokeStyle = '#1a1510';
      g.strokeRect(x, y, 31, 31);
    }
  }
});
floorTex.repeat.set(12, 12);

const ceilTex = makeTex((g, s) => {
  g.fillStyle = '#1a1e28';
  g.fillRect(0, 0, s, s);
  g.strokeStyle = '#12151c';
  for (let i = 0; i < s; i += 32) {
    g.beginPath(); g.moveTo(i, 0); g.lineTo(i, s); g.stroke();
    g.beginPath(); g.moveTo(0, i); g.lineTo(s, i); g.stroke();
  }
});
ceilTex.repeat.set(8, 8);

export const MAP_SIZE = 40;
export const WALL_H = 3.2;

/** 0 empty, 1 wall */
export function buildGrid() {
  const S = MAP_SIZE;
  const g = Array.from({ length: S }, () => Array(S).fill(0));
  for (let i = 0; i < S; i++) g[0][i] = g[S - 1][i] = g[i][0] = g[i][S - 1] = 1;

  const blocks = [
    [5, 5, 4, 3], [12, 4, 3, 5], [20, 6, 5, 3], [28, 5, 3, 4],
    [6, 14, 3, 5], [14, 16, 5, 3], [22, 14, 3, 4], [30, 15, 4, 3],
    [5, 26, 4, 3], [13, 28, 3, 5], [22, 26, 5, 3], [30, 28, 3, 4],
    [18, 18, 4, 4], [10, 22, 2, 2], [26, 10, 2, 2],
  ];
  blocks.forEach(([x, y, w, h]) => {
    for (let dy = 0; dy < h; dy++)
      for (let dx = 0; dx < w; dx++)
        if (y + dy < S && x + dx < S) g[y + dy][x + dx] = 1;
  });
  return g;
}

export function isSolid(grid, x, z) {
  const ix = Math.floor(x), iz = Math.floor(z);
  if (iz < 0 || ix < 0 || iz >= MAP_SIZE || ix >= MAP_SIZE) return true;
  return grid[iz][ix] === 1;
}

export function randomEmpty(grid) {
  for (let n = 0; n < 100; n++) {
    const x = 2 + Math.random() * (MAP_SIZE - 4);
    const z = 2 + Math.random() * (MAP_SIZE - 4);
    if (!isSolid(grid, x, z) && !isSolid(grid, x + 0.4, z) && !isSolid(grid, x, z + 0.4))
      return { x, z };
  }
  return { x: 3, z: 3 };
}

export function createWorld(scene, grid) {
  // lights
  const amb = new THREE.AmbientLight(0x8899aa, 0.55);
  scene.add(amb);
  const dir = new THREE.DirectionalLight(0xffe6cc, 0.85);
  dir.position.set(20, 40, 10);
  dir.castShadow = true;
  scene.add(dir);
  const fill = new THREE.PointLight(0x6688cc, 0.4, 80);
  fill.position.set(MAP_SIZE / 2, 6, MAP_SIZE / 2);
  scene.add(fill);

  // floor
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(MAP_SIZE, MAP_SIZE),
    new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.9 })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.set(MAP_SIZE / 2, 0, MAP_SIZE / 2);
  floor.receiveShadow = true;
  scene.add(floor);

  // ceiling
  const ceil = new THREE.Mesh(
    new THREE.PlaneGeometry(MAP_SIZE, MAP_SIZE),
    new THREE.MeshStandardMaterial({ map: ceilTex, roughness: 1 })
  );
  ceil.rotation.x = Math.PI / 2;
  ceil.position.set(MAP_SIZE / 2, WALL_H, MAP_SIZE / 2);
  scene.add(ceil);

  // walls as merged boxes
  const wallMat = new THREE.MeshStandardMaterial({
    map: wallTex, roughness: 0.85, metalness: 0.05,
  });
  const geo = new THREE.BoxGeometry(1, WALL_H, 1);
  for (let z = 0; z < MAP_SIZE; z++) {
    for (let x = 0; x < MAP_SIZE; x++) {
      if (grid[z][x] !== 1) continue;
      const m = new THREE.Mesh(geo, wallMat);
      m.position.set(x + 0.5, WALL_H / 2, z + 0.5);
      m.castShadow = true;
      m.receiveShadow = true;
      scene.add(m);
    }
  }

  // sky-ish fog
  scene.fog = new THREE.Fog(0x1a2030, 12, 38);
  scene.background = new THREE.Color(0x1a2030);
}

/** Simple humanoid mesh for bots/players */
export function createCharacterMesh(color) {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.7 });
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xe0c8a0, roughness: 0.8 });

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.7, 0.28), bodyMat);
  torso.position.y = 1.05;
  torso.castShadow = true;
  g.add(torso);

  const head = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.32, 0.28), skinMat);
  head.position.y = 1.55;
  head.castShadow = true;
  g.add(head);

  const legGeo = new THREE.BoxGeometry(0.16, 0.55, 0.18);
  const legL = new THREE.Mesh(legGeo, bodyMat);
  legL.position.set(-0.12, 0.35, 0);
  const legR = new THREE.Mesh(legGeo, bodyMat);
  legR.position.set(0.12, 0.35, 0);
  g.add(legL, legR);

  const armGeo = new THREE.BoxGeometry(0.12, 0.5, 0.12);
  const armL = new THREE.Mesh(armGeo, bodyMat);
  armL.position.set(-0.32, 1.05, 0);
  const armR = new THREE.Mesh(armGeo, bodyMat);
  armR.position.set(0.32, 1.05, 0);
  g.add(armL, armR);

  // HP bar
  const hpBg = new THREE.Mesh(
    new THREE.PlaneGeometry(0.5, 0.06),
    new THREE.MeshBasicMaterial({ color: 0x222222 })
  );
  hpBg.position.y = 1.85;
  g.add(hpBg);
  const hpFill = new THREE.Mesh(
    new THREE.PlaneGeometry(0.48, 0.045),
    new THREE.MeshBasicMaterial({ color: 0x3fb950 })
  );
  hpFill.position.set(0, 1.85, 0.01);
  g.add(hpFill);
  g.userData.hpFill = hpFill;
  g.userData.hpBg = hpBg;

  return g;
}

export function createWeaponViewmodel() {
  const g = new THREE.Group();
  const dark = new THREE.MeshStandardMaterial({ color: 0x2a2a2a, metalness: 0.6, roughness: 0.4 });
  const wood = new THREE.MeshStandardMaterial({ color: 0x5c4030, roughness: 0.8 });

  const body = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.14, 0.55), dark);
  body.position.set(0.18, -0.18, -0.45);
  g.add(body);
  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.4, 8), dark);
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0.18, -0.14, -0.85);
  g.add(barrel);
  const stock = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.12, 0.2), wood);
  stock.position.set(0.18, -0.2, -0.15);
  g.add(stock);
  const mag = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.18, 0.1), dark);
  mag.position.set(0.18, -0.32, -0.4);
  g.add(mag);

  g.position.set(0.25, -0.25, -0.4);
  return g;
}
