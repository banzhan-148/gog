import * as THREE from 'three';
import {
  MAP_SIZE, createWorld, buildGrid, isSolid, randomEmpty,
  createCharacterMesh, createWeaponViewmodel,
} from './world.js';

const WEAPON = {
  name: 'AK-47',
  dmg: 32,
  rpm: 600,
  magSize: 30,
  reserveStart: 90,
  spread: 0.022,
  range: 45,
  reloadMs: 2100,
};

export class Game {
  constructor(container, opts) {
    this.opts = opts;
    this.grid = buildGrid();
    this.clock = new THREE.Clock();
    this.keys = {};
    this.particles = [];
    this.bots = [];
    this.remote = null; // other human in online/local
    this.running = false;
    this.paused = false;
    this.shootCd = 0;
    this.reloading = false;
    this.reloadT = 0;
    this.mag = WEAPON.magSize;
    this.reserve = WEAPON.reserveStart;
    this.kills = 0;
    this.deaths = 0;
    this.yaw = 0;
    this.pitch = 0;
    this.onToast = opts.onToast || (() => {});
    this.onFeed = opts.onFeed || (() => {});
    this.onHud = opts.onHud || (() => {});
    this.onNetSend = opts.onNetSend || null;

    this.scene = new THREE.Scene();
    createWorld(this.scene, this.grid);

    this.camera = new THREE.PerspectiveCamera(75, 1, 0.08, 80);
    this.eyeH = 1.6;

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);

    this.weapon = createWeaponViewmodel();
    this.camera.add(this.weapon);
    this.scene.add(this.camera);

    // local player collider state
    const spawn = randomEmpty(this.grid);
    this.pos = new THREE.Vector3(spawn.x, this.eyeH, spawn.z);
    this.hp = 100;
    this.alive = true;
    this.respawnT = 0;
    this.muzzle = 0;
    this.bob = 0;

    if (opts.mode === 'solo') this.spawnBots(opts.botCount || 5, opts.diff || 'normal');
    if (opts.mode === 'local') this.setupLocalP2();

    this._onResize = () => this.resize();
    window.addEventListener('resize', this._onResize);
    this.resize();
  }

  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  spawnBots(n, diff) {
    this.diff = diff;
    for (let i = 0; i < n; i++) {
      const p = randomEmpty(this.grid);
      const mesh = createCharacterMesh(0x8B4513);
      mesh.position.set(p.x, 0, p.z);
      this.scene.add(mesh);
      this.bots.push({
        mesh,
        x: p.x, z: p.z,
        yaw: Math.random() * Math.PI * 2,
        hp: 100, maxHp: 100, alive: true,
        speed: diff === 'hard' ? 3.2 : diff === 'easy' ? 2.0 : 2.6,
        shootCd: 1 + Math.random(),
        name: 'Bot' + (10 + i),
        acc: diff === 'hard' ? 0.85 : diff === 'easy' ? 0.4 : 0.6,
      });
    }
  }

  setupLocalP2() {
    const p = randomEmpty(this.grid);
    const mesh = createCharacterMesh(0x2a6aad);
    mesh.position.set(p.x, 0, p.z);
    this.scene.add(mesh);
    this.remote = {
      mesh, x: p.x, z: p.z, yaw: 0, pitch: 0,
      hp: 100, maxHp: 100, alive: true, name: 'Игрок 2',
      isLocalP2: true,
      keys: {},
    };
  }

  /** Online remote player proxy */
  ensureRemote(name) {
    if (this.remote) return;
    const p = randomEmpty(this.grid);
    const mesh = createCharacterMesh(0x2a6aad);
    mesh.position.set(p.x, 0, p.z);
    this.scene.add(mesh);
    this.remote = {
      mesh, x: p.x, z: p.z, yaw: 0,
      hp: 100, maxHp: 100, alive: true, name: name || 'Друг',
      isLocalP2: false,
    };
  }

  applyRemoteState(s) {
    if (!this.remote) this.ensureRemote(s.name);
    const r = this.remote;
    r.x = s.x; r.z = s.z; r.yaw = s.yaw;
    r.hp = s.hp; r.alive = s.alive;
    r.mesh.position.set(r.x, 0, r.z);
    r.mesh.rotation.y = r.yaw + Math.PI;
    r.mesh.visible = r.alive;
    this._setHpBar(r.mesh, r.hp / r.maxHp);
  }

  getNetState() {
    return {
      x: this.pos.x, z: this.pos.z, yaw: this.yaw,
      hp: this.hp, alive: this.alive, name: 'Игрок',
    };
  }

  _setHpBar(mesh, ratio) {
    const fill = mesh.userData.hpFill;
    if (!fill) return;
    fill.scale.x = Math.max(0.01, ratio);
    fill.position.x = -0.24 * (1 - ratio);
    fill.material.color.setHex(ratio > 0.4 ? 0x3fb950 : 0xda3633);
  }

  tryMove(ent, dx, dz, rad = 0.28) {
    const nx = ent.x + dx, nz = ent.z + dz;
    if (!isSolid(this.grid, nx, ent.z) && !isSolid(this.grid, nx, ent.z - rad) && !isSolid(this.grid, nx, ent.z + rad))
      ent.x = nx;
    if (!isSolid(this.grid, ent.x, nz) && !isSolid(this.grid, ent.x - rad, nz) && !isSolid(this.grid, ent.x + rad, nz))
      ent.z = nz;
  }

  hasLOS(ax, az, bx, bz) {
    const dist = Math.hypot(bx - ax, bz - az);
    const steps = Math.ceil(dist * 6);
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      if (isSolid(this.grid, ax + (bx - ax) * t, az + (bz - az) * t)) return false;
    }
    return true;
  }

  shoot() {
    if (!this.alive || this.reloading || this.mag <= 0) {
      if (this.mag <= 0) this.reload();
      return;
    }
    const interval = 60 / WEAPON.rpm;
    if (this.shootCd > 0) return;
    this.shootCd = interval;
    this.mag--;
    this.muzzle = 1;
    this.weapon.position.z = -0.32;

    const spread = (Math.random() - 0.5) * WEAPON.spread * 2;
    const yaw = this.yaw + spread;
    const pitch = this.pitch + (Math.random() - 0.5) * WEAPON.spread;
    const dir = new THREE.Vector3(
      Math.sin(yaw) * Math.cos(pitch),
      Math.sin(pitch),
      -Math.cos(yaw) * Math.cos(pitch)
    ).normalize();

    const origin = this.pos.clone();
    let hit = null, hitDist = WEAPON.range;

    const targets = [...this.bots];
    if (this.remote && this.remote.alive) targets.push(this.remote);

    for (const t of targets) {
      if (!t.alive) continue;
      const tx = t.x, tz = t.z, ty = 1.0;
      const to = new THREE.Vector3(tx - origin.x, ty - origin.y, tz - origin.z);
      const dist = to.length();
      if (dist > WEAPON.range) continue;
      const nd = to.clone().normalize();
      const dot = nd.dot(dir);
      if (dot < 0.97) continue; // ~14° cone tightened by distance
      const ang = Math.acos(Math.min(1, dot));
      if (ang > Math.atan2(0.4, dist)) continue;
      if (!this.hasLOS(origin.x, origin.z, tx, tz)) continue;
      if (dist < hitDist) { hit = t; hitDist = dist; }
    }

    if (hit) {
      hit.hp -= WEAPON.dmg;
      this._setHpBar(hit.mesh, hit.hp / hit.maxHp);
      if (hit.hp <= 0) {
        hit.alive = false;
        hit.mesh.visible = false;
        this.kills++;
        this.onFeed('Вы ★ ' + hit.name);
        this.onToast('Убит ' + hit.name);
        if (hit.name && hit.name.startsWith('Bot')) {
          setTimeout(() => this.respawnBot(hit), 2800);
        } else if (hit.isLocalP2) {
          setTimeout(() => this.respawnRemote(hit), 2500);
        }
        // online: peer handles own respawn via state
      }
      if (this.onNetSend) this.onNetSend({ type: 'hit', dmg: WEAPON.dmg });
    }
  }

  remoteShootAtPlayer(dmg) {
    if (!this.alive) return;
    this.hp -= dmg;
    if (this.hp <= 0) {
      this.hp = 0;
      this.alive = false;
      this.deaths++;
      this.respawnT = 2.5;
      this.onFeed((this.remote && this.remote.name) + ' ★ Вы');
      this.onToast('Вы убиты');
    }
  }

  reload() {
    if (this.reloading || this.mag >= WEAPON.magSize || this.reserve <= 0) return;
    this.reloading = true;
    this.reloadT = WEAPON.reloadMs / 1000;
    this.onToast('Перезарядка…');
  }

  respawnBot(b) {
    const p = randomEmpty(this.grid);
    b.x = p.x; b.z = p.z; b.hp = 100; b.alive = true;
    b.mesh.visible = true;
    b.mesh.position.set(b.x, 0, b.z);
    this._setHpBar(b.mesh, 1);
  }

  respawnRemote(r) {
    const p = randomEmpty(this.grid);
    r.x = p.x; r.z = p.z; r.hp = 100; r.alive = true;
    r.mesh.visible = true;
    r.mesh.position.set(r.x, 0, r.z);
    this._setHpBar(r.mesh, 1);
  }

  respawnSelf() {
    const p = randomEmpty(this.grid);
    this.pos.set(p.x, this.eyeH, p.z);
    this.hp = 100;
    this.alive = true;
    this.mag = WEAPON.magSize;
    this.respawnT = 0;
  }

  updateBots(dt) {
    for (const b of this.bots) {
      if (!b.alive) continue;
      b.shootCd = Math.max(0, b.shootCd - dt);
      const dx = this.pos.x - b.x;
      const dz = this.pos.z - b.z;
      const dist = Math.hypot(dx, dz);
      const targetYaw = Math.atan2(dx, -dz);
      let dy = targetYaw - b.yaw;
      while (dy > Math.PI) dy -= Math.PI * 2;
      while (dy < -Math.PI) dy += Math.PI * 2;
      b.yaw += dy * Math.min(1, 3 * dt);

      const los = this.alive && dist < 18 && this.hasLOS(b.x, b.z, this.pos.x, this.pos.z);
      if (los) {
        if (dist > 5) {
          this.tryMove(b, Math.sin(b.yaw) * b.speed * dt, -Math.cos(b.yaw) * b.speed * dt);
        }
        // strafe
        const s = Math.sin(b.yaw + Math.PI / 2) * b.speed * 0.4 * dt * (Math.sin(performance.now() / 500) > 0 ? 1 : -1);
        const c = -Math.cos(b.yaw + Math.PI / 2) * b.speed * 0.4 * dt * (Math.sin(performance.now() / 500) > 0 ? 1 : -1);
        this.tryMove(b, s, c);

        if (b.shootCd <= 0 && Math.abs(dy) < 0.4) {
          b.shootCd = this.diff === 'hard' ? 0.3 : this.diff === 'easy' ? 0.6 : 0.42;
          if (Math.random() < b.acc) {
            const dmg = 10 + Math.floor(Math.random() * 16);
            this.hp -= dmg;
            if (this.hp <= 0) {
              this.hp = 0; this.alive = false; this.deaths++;
              this.respawnT = 2.5;
              this.onFeed(b.name + ' ★ Вы');
              this.onToast('Вы убиты');
            }
          }
        }
      } else {
        this.tryMove(b, Math.sin(b.yaw) * b.speed * dt * 0.7, -Math.cos(b.yaw) * b.speed * dt * 0.7);
        if (Math.random() < 0.01) b.yaw += (Math.random() - 0.5) * 1.2;
      }
      b.mesh.position.set(b.x, 0, b.z);
      b.mesh.rotation.y = b.yaw + Math.PI;
      // billboard HP bars toward camera
      if (b.mesh.userData.hpBg) {
        b.mesh.userData.hpBg.lookAt(this.camera.position);
        b.mesh.userData.hpFill.lookAt(this.camera.position);
      }
    }
  }

  updateLocalP2(dt) {
    const r = this.remote;
    if (!r || !r.isLocalP2) return;
    if (!r.alive) return;
    const k = this.keys;
    const speed = 3.2;
    let mx = 0, mz = 0;
    if (k['ArrowUp']) { mx += Math.sin(r.yaw); mz += -Math.cos(r.yaw); }
    if (k['ArrowDown']) { mx -= Math.sin(r.yaw); mz -= -Math.cos(r.yaw); }
    if (k['ArrowLeft']) { mx += Math.sin(r.yaw - Math.PI / 2); mz += -Math.cos(r.yaw - Math.PI / 2); }
    if (k['ArrowRight']) { mx += Math.sin(r.yaw + Math.PI / 2); mz += -Math.cos(r.yaw + Math.PI / 2); }
    // look with IJKL
    if (k['KeyJ']) r.yaw -= 1.8 * dt;
    if (k['KeyL']) r.yaw += 1.8 * dt;
    const len = Math.hypot(mx, mz);
    if (len > 0) this.tryMove(r, (mx / len) * speed * dt, (mz / len) * speed * dt);
    r.mesh.position.set(r.x, 0, r.z);
    r.mesh.rotation.y = r.yaw + Math.PI;
    this._setHpBar(r.mesh, r.hp / r.maxHp);
    if (r.mesh.userData.hpBg) {
      r.mesh.userData.hpBg.lookAt(this.camera.position);
      r.mesh.userData.hpFill.lookAt(this.camera.position);
    }
  }

  localP2Shoot() {
    const r = this.remote;
    if (!r || !r.isLocalP2 || !r.alive) return;
    // hitscan toward P1 direction from P2
    const dir = new THREE.Vector3(Math.sin(r.yaw), 0, -Math.cos(r.yaw));
    const to = new THREE.Vector3(this.pos.x - r.x, 0, this.pos.z - r.z);
    const dist = to.length();
    if (dist > 35 || !this.alive) return;
    to.normalize();
    if (to.dot(dir) < 0.95) return;
    if (!this.hasLOS(r.x, r.z, this.pos.x, this.pos.z)) return;
    this.hp -= 28;
    if (this.hp <= 0) {
      this.hp = 0; this.alive = false; this.deaths++;
      this.respawnT = 2.5;
      this.onFeed('Игрок 2 ★ Вы');
    }
  }

  update(dt) {
    if (!this.alive) {
      this.respawnT -= dt;
      if (this.respawnT <= 0) this.respawnSelf();
    } else {
      const speed = (this.keys['ShiftLeft'] || this.keys['ShiftRight']) ? 5.2 : 3.4;
      let mx = 0, mz = 0;
      if (this.keys['KeyW']) { mx += Math.sin(this.yaw); mz += -Math.cos(this.yaw); }
      if (this.keys['KeyS']) { mx -= Math.sin(this.yaw); mz -= -Math.cos(this.yaw); }
      if (this.keys['KeyA']) { mx += Math.sin(this.yaw - Math.PI / 2); mz += -Math.cos(this.yaw - Math.PI / 2); }
      if (this.keys['KeyD']) { mx += Math.sin(this.yaw + Math.PI / 2); mz += -Math.cos(this.yaw + Math.PI / 2); }
      const len = Math.hypot(mx, mz);
      if (len > 0) {
        const ent = { x: this.pos.x, z: this.pos.z };
        this.tryMove(ent, (mx / len) * speed * dt, (mz / len) * speed * dt);
        this.pos.x = ent.x; this.pos.z = ent.z;
        this.bob += dt * 12;
      }
      if (this.keys['Mouse0']) this.shoot();
    }

    this.shootCd = Math.max(0, this.shootCd - dt);
    this.muzzle = Math.max(0, this.muzzle - dt * 6);
    if (this.reloading) {
      this.reloadT -= dt;
      if (this.reloadT <= 0) {
        const need = WEAPON.magSize - this.mag;
        const take = Math.min(need, this.reserve);
        this.mag += take; this.reserve -= take;
        this.reloading = false;
      }
    }

    // camera
    this.camera.position.copy(this.pos);
    this.camera.position.y = this.eyeH + Math.sin(this.bob) * 0.03;
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.y = -this.yaw;
    this.camera.rotation.x = this.pitch;

    // weapon bob / recoil recovery
    this.weapon.position.x = 0.25;
    this.weapon.position.y = -0.25 + Math.sin(this.bob) * 0.012;
    this.weapon.position.z = THREE.MathUtils.lerp(this.weapon.position.z, -0.4, 0.15);
    if (this.muzzle > 0.3) {
      // flash point light
    }

    this.updateBots(dt);
    this.updateLocalP2(dt);

    if (this.onNetSend && this.opts.mode === 'online') {
      this._netAcc = (this._netAcc || 0) + dt;
      if (this._netAcc > 0.05) {
        this._netAcc = 0;
        this.onNetSend({ type: 'state', state: this.getNetState() });
      }
    }

    this.onHud({
      hp: this.hp,
      mag: this.mag,
      reserve: this.reserve,
      reloading: this.reloading,
      kills: this.kills,
      deaths: this.deaths,
      weapon: WEAPON.name,
    });
  }

  render() {
    this.renderer.render(this.scene, this.camera);
  }

  start() {
    this.running = true;
    this.paused = false;
    this.clock.start();
    const loop = () => {
      if (!this.running) return;
      requestAnimationFrame(loop);
      if (this.paused) return;
      const dt = Math.min(0.05, this.clock.getDelta());
      this.update(dt);
      this.render();
    };
    loop();
  }

  pause() { this.paused = true; }
  resume() { this.paused = false; this.clock.getDelta(); }
  dispose() {
    this.running = false;
    window.removeEventListener('resize', this._onResize);
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode)
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
  }
}
