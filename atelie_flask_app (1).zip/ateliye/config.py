import os
from datetime import timedelta

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, "instance")
os.makedirs(INSTANCE_DIR, exist_ok=True)


def _load_or_create_secret_key():
    """
    Секретный ключ никогда не хранится в исходном коде. Он берётся из
    переменной окружения SECRET_KEY (рекомендуется для продакшена) либо
    один раз генерируется и сохраняется в instance/secret_key —
    каталог instance/ не должен попадать в систему контроля версий.
    """
    env_key = os.environ.get("SECRET_KEY")
    if env_key:
        return env_key

    key_path = os.path.join(INSTANCE_DIR, "secret_key")
    if os.path.exists(key_path):
        with open(key_path, "r", encoding="utf-8") as f:
            return f.read().strip()

    import secrets
    key = secrets.token_hex(32)
    with open(key_path, "w", encoding="utf-8") as f:
        f.write(key)
    os.chmod(key_path, 0o600)
    return key


class Config:
    SECRET_KEY = _load_or_create_secret_key()
    DATABASE_PATH = os.environ.get(
        "DATABASE_PATH", os.path.join(INSTANCE_DIR, "atelie.db")
    )

    # --- Требования безопасности сессий (п. 4.1.9 ТЗ) ---
    SESSION_COOKIE_HTTPONLY = True          # запрет доступа к cookie из JS
    SESSION_COOKIE_SAMESITE = "Lax"         # защита от части CSRF/клик-джекинга
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "0") == "1"
    # ^ включить (1) при работе по HTTPS в проде — за обратным прокси/Nginx
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)

    # --- Политика паролей и блокировки учётной записи ---
    PASSWORD_MIN_LENGTH = 8
    MAX_FAILED_LOGIN_ATTEMPTS = 5
    LOCKOUT_MINUTES = 15

    # --- Резервное копирование (п. 4.1.8 ТЗ) ---
    BACKUP_DIR = os.environ.get("BACKUP_DIR", os.path.join(INSTANCE_DIR, "backups"))
    BACKUP_RETENTION_DAYS = 90

    # Срок, в течение которого возможно восстановление удалённых записей (п. 4.1.4 ТЗ)
    SOFT_DELETE_RESTORE_DAYS = 30

    MAX_CONTENT_LENGTH = 2 * 1024 * 1024  # 2 МБ — предел размера входящего запроса
