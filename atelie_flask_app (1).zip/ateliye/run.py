from app import create_app

app = create_app()

if __name__ == "__main__":
    # Для разработки. В продакшене запускать через Gunicorn/uWSGI за Nginx (см. README.md),
    # с SESSION_COOKIE_SECURE=1 и реальным HTTPS-сертификатом.
    app.run(debug=False, host="127.0.0.1", port=5000)
