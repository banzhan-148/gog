"""
Быстрая проверка ключевых сценариев системы через тестовый клиент Flask,
без необходимости вручную работать с браузером.
Запуск: python smoke_test.py
"""
import os
import re
import sys
import tempfile

os.environ["DATABASE_PATH"] = tempfile.mktemp(suffix=".db")
os.environ["SECRET_KEY"] = "test-secret-key"

from app import create_app
from app.db import get_db
from app.security import hash_password

FAILED = []


def check(name, condition):
    status = "OK " if condition else "FAIL"
    print(f"[{status}] {name}")
    if not condition:
        FAILED.append(name)


def get_csrf(html):
    m = re.search(r'name="csrf_token" value="([^"]+)"', html)
    return m.group(1) if m else None


def main():
    app = create_app()
    with app.app_context():
        db = get_db()
        db.execute(
            "INSERT INTO users (username, password_hash, full_name, role) VALUES (?,?,?,?)",
            ("admin", hash_password("Admin1234"), "Тестовый Администратор", "admin"),
        )
        db.execute(
            "INSERT INTO users (username, password_hash, full_name, role) VALUES (?,?,?,?)",
            ("tailor1", hash_password("Tailor1234"), "Тестовый Портной", "executor"),
        )
        db.commit()

    client = app.test_client()

    # --- Неавторизованный доступ должен редиректить на логин ---
    r = client.get("/", follow_redirects=False)
    check("неавторизованный доступ к / -> редирект на логин", r.status_code == 302)

    # --- Логин с неверным паролем ---
    r = client.get("/auth/login")
    token = get_csrf(r.get_data(as_text=True))
    check("страница логина отдаёт CSRF-токен", token is not None)
    r = client.post("/auth/login", data={"username": "admin", "password": "wrong", "csrf_token": token}, follow_redirects=True)
    check("неверный пароль -> сообщение об ошибке", "Неверный логин или пароль" in r.get_data(as_text=True))

    # --- POST без CSRF-токена должен быть отклонён (400) ---
    r = client.post("/auth/login", data={"username": "admin", "password": "Admin1234"})
    check("POST без csrf_token отклоняется (400)", r.status_code == 400)

    # --- Успешный логин администратора ---
    r = client.get("/auth/login")
    token = get_csrf(r.get_data(as_text=True))
    r = client.post("/auth/login", data={"username": "admin", "password": "Admin1234", "csrf_token": token}, follow_redirects=True)
    check("успешный вход администратора", "Добро пожаловать" in r.get_data(as_text=True))

    r = client.get("/")
    check("дашборд доступен после входа", r.status_code == 200 and "Панель управления" in r.get_data(as_text=True))
    token = get_csrf(r.get_data(as_text=True))

    # --- Создание клиента ---
    r = client.post(
        "/clients/new",
        data={"full_name": "Иванов Иван Иванович", "phone": "+79001234567", "email": "", "birth_date": "", "notes": "", "csrf_token": token},
        follow_redirects=True,
    )
    check("клиент создан", "зарегистрирован" in r.get_data(as_text=True) or "Иванов" in r.get_data(as_text=True))

    with app.app_context():
        db = get_db()
        cl = db.execute("SELECT * FROM clients WHERE full_name=?", ("Иванов Иван Иванович",)).fetchone()
        check("клиент действительно в БД", cl is not None)
        client_id = cl["id"] if cl else None
        executor = db.execute("SELECT id FROM users WHERE username='tailor1'").fetchone()
        executor_id = executor["id"]

    # --- Дублирующая регистрация того же клиента должна не создавать дубль ---
    r = client.get(f"/clients/{client_id}")
    token = get_csrf(r.get_data(as_text=True))
    r = client.post(
        "/clients/new",
        data={"full_name": "Иванов Иван Иванович", "phone": "+79001234567", "email": "", "birth_date": "", "notes": "", "csrf_token": token},
        follow_redirects=True,
    )
    with app.app_context():
        db = get_db()
        count = db.execute("SELECT COUNT(*) c FROM clients WHERE full_name=?", ("Иванов Иван Иванович",)).fetchone()["c"]
        check("дубликат клиента не создан", count == 1)

    # --- Добавление мерок ---
    r = client.get(f"/clients/{client_id}")
    token = get_csrf(r.get_data(as_text=True))
    r = client.post(
        f"/clients/{client_id}/measurements/new",
        data={"m_Рост": "180", "m_Обхват груди": "100", "note": "Замер при первом визите", "csrf_token": token},
        follow_redirects=True,
    )
    check("мерки сохранены", "Мерки сохранены" in r.get_data(as_text=True))

    # --- Создание заказа ---
    r = client.get("/orders/new")
    token = get_csrf(r.get_data(as_text=True))
    r = client.post(
        "/orders/new",
        data={
            "client_id": str(client_id), "executor_id": str(executor_id), "order_type": "пошив",
            "description": "Тестовый заказ", "deadline": "2026-12-31",
            "item_name": "Костюм", "item_description": "Пошив классического костюма", "item_price": "5000",
            "csrf_token": token,
        },
        follow_redirects=True,
    )
    check("заказ оформлен", "Заказ оформлен" in r.get_data(as_text=True))

    with app.app_context():
        db = get_db()
        order = db.execute("SELECT * FROM orders WHERE client_id=?", (client_id,)).fetchone()
        check("заказ есть в БД с корректной суммой", order is not None and abs(order["price"] - 5000) < 0.01)
        order_id = order["id"]

    # --- Попытка выдать заказ без полной оплаты должна быть отклонена ---
    r = client.get(f"/orders/{order_id}")
    token = get_csrf(r.get_data(as_text=True))
    r = client.post(f"/orders/{order_id}/status", data={"status": "выдан", "csrf_token": token}, follow_redirects=True)
    check("нельзя выдать заказ без полной оплаты", "Нельзя выдать заказ без полной оплаты" in r.get_data(as_text=True))

    # --- Приём оплаты ---
    r = client.get(f"/orders/{order_id}")
    token = get_csrf(r.get_data(as_text=True))
    r = client.post(
        f"/orders/{order_id}/payments/new",
        data={"amount": "5000", "method": "наличные", "payment_type": "полная оплата", "csrf_token": token},
        follow_redirects=True,
    )
    check("оплата зарегистрирована", "Оплата зарегистрирована" in r.get_data(as_text=True))

    # --- Переплата должна отклоняться ---
    r = client.get(f"/orders/{order_id}")
    token = get_csrf(r.get_data(as_text=True))
    r = client.post(
        f"/orders/{order_id}/payments/new",
        data={"amount": "100", "method": "наличные", "payment_type": "доплата", "csrf_token": token},
        follow_redirects=True,
    )
    check("переплата отклонена", "превышает остаток" in r.get_data(as_text=True))

    # --- Теперь выдача заказа должна пройти успешно ---
    r = client.get(f"/orders/{order_id}")
    token = get_csrf(r.get_data(as_text=True))
    r = client.post(f"/orders/{order_id}/status", data={"status": "выдан", "csrf_token": token}, follow_redirects=True)
    check("заказ выдан после полной оплаты", "изменён на «выдан»" in r.get_data(as_text=True))

    # --- Печатная форма квитанции открывается ---
    r = client.get(f"/orders/{order_id}/print")
    check("печатная форма квитанции открывается", r.status_code == 200 and "Квитанция-заказ" in r.get_data(as_text=True))

    # --- Проверка доступа: исполнитель не должен попасть в админку ---
    # (сначала явно выходим из-под администратора: пока он в сессии, GET /auth/login
    # сразу редиректит на дашборд без формы, и извлечь новый csrf_token неоткуда)
    r = client.get("/", follow_redirects=True)
    token = get_csrf(r.get_data(as_text=True))
    client.post("/auth/logout", data={"csrf_token": token}, follow_redirects=True)

    r = client.get("/auth/login")
    token = get_csrf(r.get_data(as_text=True))
    r = client.post("/auth/login", data={"username": "tailor1", "password": "Tailor1234", "csrf_token": token}, follow_redirects=True)
    check("вход исполнителя выполнен", "Добро пожаловать" in r.get_data(as_text=True))
    r = client.get("/admin/users")
    check("исполнитель не имеет доступа к /admin/users (403)", r.status_code == 403)
    r = client.get("/reports/")
    check("исполнитель не имеет доступа к отчётам (403)", r.status_code == 403)
    r = client.get(f"/orders/{order_id}")
    check("исполнитель видит только свой заказ", r.status_code == 200)

    # --- Проверка блокировки после серии неверных паролей ---
    r = client.get("/", follow_redirects=True)
    token = get_csrf(r.get_data(as_text=True))
    client.post("/auth/logout", data={"csrf_token": token}, follow_redirects=True)
    for i in range(5):
        r = client.get("/auth/login")
        t = get_csrf(r.get_data(as_text=True))
        client.post("/auth/login", data={"username": "admin", "password": "wrong", "csrf_token": t}, follow_redirects=True)
    r = client.get("/auth/login")
    t = get_csrf(r.get_data(as_text=True))
    r = client.post("/auth/login", data={"username": "admin", "password": "Admin1234", "csrf_token": t}, follow_redirects=True)
    check("аккаунт временно заблокирован после 5 неверных попыток", "заблокирована" in r.get_data(as_text=True))

    print()
    if FAILED:
        print(f"ИТОГ: {len(FAILED)} проверок не пройдено: {FAILED}")
        sys.exit(1)
    else:
        print("ИТОГ: все проверки пройдены успешно.")


if __name__ == "__main__":
    main()
