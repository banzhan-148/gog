from flask import Blueprint, render_template, request

from app.db import get_db
from app.security import roles_required

bp = Blueprint("reports", __name__, url_prefix="/reports")


@bp.route("/")
@roles_required("admin", "director")
def index():
    db = get_db()
    date_from = request.args.get("date_from", "")
    date_to = request.args.get("date_to", "")

    period_clause = ""
    params = []
    if date_from:
        period_clause += " AND date(created_at) >= date(?)"
        params.append(date_from)
    if date_to:
        period_clause += " AND date(created_at) <= date(?)"
        params.append(date_to)

    # --- Выручка за период ---
    revenue_row = db.execute(
        f"SELECT COALESCE(SUM(amount),0) s, COUNT(*) c FROM payments WHERE is_deleted = 0 {period_clause}",
        params,
    ).fetchone()

    revenue_by_method = db.execute(
        f"""SELECT method, COALESCE(SUM(amount),0) s FROM payments
            WHERE is_deleted = 0 {period_clause} GROUP BY method""",
        params,
    ).fetchall()

    # --- Заказы по статусам ---
    orders_by_status = db.execute(
        f"""SELECT status, COUNT(*) c FROM orders WHERE is_deleted = 0 {period_clause}
            GROUP BY status ORDER BY c DESC""",
        params,
    ).fetchall()

    # --- Загрузка исполнителей ---
    executor_load = db.execute(
        f"""SELECT u.full_name,
                   COUNT(o.id) AS orders_count,
                   SUM(CASE WHEN o.status NOT IN ('выдан','отменён') THEN 1 ELSE 0 END) AS active_count,
                   COALESCE(SUM(o.price), 0) AS total_value
            FROM users u
            LEFT JOIN orders o ON o.executor_id = u.id AND o.is_deleted = 0 {period_clause.replace('created_at', 'o.created_at')}
            WHERE u.role = 'executor'
            GROUP BY u.id ORDER BY orders_count DESC""",
        params,
    ).fetchall()

    # --- Остатки материалов ---
    materials = db.execute(
        """SELECT name, unit, quantity, min_quantity, price,
                  (quantity <= min_quantity) AS low_stock
           FROM materials WHERE is_deleted = 0 ORDER BY low_stock DESC, name"""
    ).fetchall()

    return render_template(
        "reports/index.html",
        revenue=revenue_row, revenue_by_method=revenue_by_method,
        orders_by_status=orders_by_status, executor_load=executor_load,
        materials=materials, date_from=date_from, date_to=date_to,
    )
