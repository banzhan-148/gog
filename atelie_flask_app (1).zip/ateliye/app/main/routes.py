from flask import Blueprint, render_template, g

from app.db import get_db
from app.security import login_required

bp = Blueprint("main", __name__)


@bp.route("/")
@login_required
def dashboard():
    db = get_db()
    user = g.user

    stats = {}
    stats["active_orders"] = db.execute(
        "SELECT COUNT(*) c FROM orders WHERE is_deleted = 0 AND status NOT IN ('выдан','отменён')"
    ).fetchone()["c"]
    stats["ready_orders"] = db.execute(
        "SELECT COUNT(*) c FROM orders WHERE is_deleted = 0 AND status = 'готов'"
    ).fetchone()["c"]
    stats["overdue_orders"] = db.execute(
        """SELECT COUNT(*) c FROM orders
           WHERE is_deleted = 0 AND status NOT IN ('выдан','отменён')
             AND deadline IS NOT NULL AND date(deadline) < date('now')"""
    ).fetchone()["c"]
    stats["clients_total"] = db.execute(
        "SELECT COUNT(*) c FROM clients WHERE is_deleted = 0"
    ).fetchone()["c"]
    stats["low_stock"] = db.execute(
        "SELECT COUNT(*) c FROM materials WHERE is_deleted = 0 AND quantity <= min_quantity"
    ).fetchone()["c"]

    revenue_month = db.execute(
        """SELECT COALESCE(SUM(amount), 0) s FROM payments
           WHERE is_deleted = 0 AND strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')"""
    ).fetchone()["s"]
    stats["revenue_month"] = revenue_month

    my_orders = []
    if user["role"] == "executor":
        my_orders = db.execute(
            """SELECT o.*, c.full_name AS client_name FROM orders o
               JOIN clients c ON c.id = o.client_id
               WHERE o.executor_id = ? AND o.is_deleted = 0 AND o.status NOT IN ('выдан','отменён')
               ORDER BY o.deadline IS NULL, o.deadline ASC""",
            (user["id"],),
        ).fetchall()

    recent_orders = db.execute(
        """SELECT o.*, c.full_name AS client_name FROM orders o
           JOIN clients c ON c.id = o.client_id
           WHERE o.is_deleted = 0
           ORDER BY o.created_at DESC LIMIT 8"""
    ).fetchall()

    return render_template(
        "main/dashboard.html", stats=stats, my_orders=my_orders, recent_orders=recent_orders
    )
