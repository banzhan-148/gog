import re
import secrets
from datetime import datetime, timedelta
from functools import wraps

from flask import session, g, request, abort, redirect, url_for, flash, current_app
from werkzeug.security import generate_password_hash, check_password_hash

from app.db import get_db

ROLE_LABELS = {
    "admin": "Администратор",
    "receptionist": "Приёмщик заказов",
    "executor": "Исполнитель (закройщик/портной)",
    "director": "Руководитель",
}

# ---------------------------------------------------------------------------
# Пароли
# ---------------------------------------------------------------------------

def hash_password(raw_password: str) -> str:
    return generate_password_hash(raw_password)


def verify_password(password_hash: str, raw_password: str) -> bool:
    return check_password_hash(password_hash, raw_password)


def validate_password_policy(raw_password: str) -> list:
    """Возвращает список нарушений политики паролей (пусто — пароль годен)."""
    errors = []
    min_len = current_app.config["PASSWORD_MIN_LENGTH"]
    if len(raw_password) < min_len:
        errors.append(f"Пароль должен содержать не менее {min_len} символов.")
    if not re.search(r"[A-Za-zА-Яа-я]", raw_password):
        errors.append("Пароль должен содержать хотя бы одну букву.")
    if not re.search(r"[0-9]", raw_password):
        errors.append("Пароль должен содержать хотя бы одну цифру.")
    return errors


# ---------------------------------------------------------------------------
# CSRF-защита (собственная реализация — генерация/проверка токена в сессии)
# ---------------------------------------------------------------------------

def get_csrf_token() -> str:
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(24)
    return session["csrf_token"]


def validate_csrf():
    """Прерывает запрос кодом 400, если CSRF-токен формы не совпадает с сессией."""
    if request.method not in ("POST", "PUT", "PATCH", "DELETE"):
        return
    form_token = request.form.get("csrf_token", "")
    session_token = session.get("csrf_token", "")
    if not form_token or not session_token or not secrets.compare_digest(form_token, session_token):
        abort(400, description="Неверный CSRF-токен. Обновите страницу и повторите попытку.")


# ---------------------------------------------------------------------------
# Аутентификация (собственная сессионная реализация)
# ---------------------------------------------------------------------------

def login_user(user_row):
    # Регенерация идентификатора сессии при входе — защита от session fixation
    session.clear()
    session.permanent = True
    session["user_id"] = user_row["id"]
    session["role"] = user_row["role"]
    session["csrf_token"] = secrets.token_hex(24)


def logout_user():
    session.clear()


def get_current_user():
    if "user_id" not in session:
        return None
    if "_user_cache" in g:
        return g._user_cache
    db = get_db()
    user = db.execute(
        "SELECT * FROM users WHERE id = ? AND is_active = 1", (session["user_id"],)
    ).fetchone()
    if user is None:
        session.clear()
        return None
    g._user_cache = user
    return user


def is_account_locked(user_row) -> bool:
    locked_until = user_row["locked_until"]
    if not locked_until:
        return False
    try:
        return datetime.fromisoformat(locked_until) > datetime.now()
    except ValueError:
        return False


def register_failed_login(db, user_row):
    attempts = user_row["failed_attempts"] + 1
    locked_until = None
    if attempts >= current_app.config["MAX_FAILED_LOGIN_ATTEMPTS"]:
        locked_until = (
            datetime.now() + timedelta(minutes=current_app.config["LOCKOUT_MINUTES"])
        ).isoformat(timespec="seconds")
        attempts = 0
    db.execute(
        "UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?",
        (attempts, locked_until, user_row["id"]),
    )
    db.commit()


def register_successful_login(db, user_row):
    db.execute(
        "UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login_at = ? WHERE id = ?",
        (datetime.now().isoformat(timespec="seconds"), user_row["id"]),
    )
    db.commit()


# ---------------------------------------------------------------------------
# Декораторы контроля доступа (п. 4.1.9 ТЗ — разграничение прав по ролям)
# ---------------------------------------------------------------------------

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if get_current_user() is None:
            flash("Пожалуйста, войдите в систему.", "warning")
            return redirect(url_for("auth.login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def roles_required(*roles):
    """Доступ разрешён указанным ролям; администратору — всегда."""
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            user = get_current_user()
            if user is None:
                flash("Пожалуйста, войдите в систему.", "warning")
                return redirect(url_for("auth.login", next=request.path))
            if user["role"] != "admin" and user["role"] not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator
