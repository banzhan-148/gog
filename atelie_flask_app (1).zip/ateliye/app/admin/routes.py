from datetime import datetime, timedelta

from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, current_app

from app.db import get_db, backup_db
from app.security import roles_required, hash_password, validate_password_policy, ROLE_LABELS
from app.audit import log_action

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.route("/users")
@roles_required("admin")
def list_users():
    db = get_db()
    users = db.execute("SELECT * FROM users ORDER BY full_name").fetchall()
    return render_template("admin/users.html", users=users, role_labels=ROLE_LABELS)


@bp.route("/users/new", methods=["GET", "POST"])
@roles_required("admin")
def new_user():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        role = request.form.get("role", "")
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")

        errors = []
        if not username or not full_name:
            errors.append("Заполните логин и ФИО.")
        if role not in ROLE_LABELS:
            errors.append("Выберите корректную роль.")
        errors.extend(validate_password_policy(password))

        db = get_db()
        if not errors and db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone():
            errors.append("Пользователь с таким логином уже существует.")

        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("admin/user_form.html", user=None, role_labels=ROLE_LABELS)

        cur = db.execute(
            """INSERT INTO users (username, password_hash, full_name, role, phone)
               VALUES (?, ?, ?, ?, ?)""",
            (username, hash_password(password), full_name, role, phone),
        )
        db.commit()
        log_action(g.user, "create", "user", cur.lastrowid, f"{username} ({role})")
        flash("Учётная запись создана.", "success")
        return redirect(url_for("admin.list_users"))

    return render_template("admin/user_form.html", user=None, role_labels=ROLE_LABELS)


@bp.route("/users/<int:user_id>/edit", methods=["GET", "POST"])
@roles_required("admin")
def edit_user(user_id):
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if user is None:
        abort(404)

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        role = request.form.get("role", "")
        phone = request.form.get("phone", "").strip()
        is_active = 1 if request.form.get("is_active") else 0
        new_password = request.form.get("password", "")

        errors = []
        if not full_name or role not in ROLE_LABELS:
            errors.append("Заполните ФИО и выберите корректную роль.")
        if new_password:
            errors.extend(validate_password_policy(new_password))

        if user_id == g.user["id"] and not is_active:
            errors.append("Нельзя деактивировать собственную учётную запись.")

        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("admin/user_form.html", user=user, role_labels=ROLE_LABELS)

        if new_password:
            db.execute(
                "UPDATE users SET full_name=?, role=?, phone=?, is_active=?, password_hash=?, failed_attempts=0, locked_until=NULL WHERE id=?",
                (full_name, role, phone, is_active, hash_password(new_password), user_id),
            )
            log_action(g.user, "update", "user", user_id, "изменены данные + сброшен пароль")
        else:
            db.execute(
                "UPDATE users SET full_name=?, role=?, phone=?, is_active=? WHERE id=?",
                (full_name, role, phone, is_active, user_id),
            )
            log_action(g.user, "update", "user", user_id, "изменены данные")
        db.commit()
        flash("Учётная запись обновлена.", "success")
        return redirect(url_for("admin.list_users"))

    return render_template("admin/user_form.html", user=user, role_labels=ROLE_LABELS)


@bp.route("/audit-log")
@roles_required("admin")
def audit_log():
    db = get_db()
    page = max(int(request.args.get("page", 1)), 1)
    per_page = 50
    entity_filter = request.args.get("entity", "")

    sql = "SELECT * FROM audit_log"
    params = []
    if entity_filter:
        sql += " WHERE entity = ?"
        params.append(entity_filter)
    sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
    params.extend([per_page, (page - 1) * per_page])

    logs = db.execute(sql, params).fetchall()
    total = db.execute("SELECT COUNT(*) c FROM audit_log").fetchone()["c"]

    return render_template(
        "admin/audit_log.html", logs=logs, page=page, per_page=per_page, total=total,
        entity_filter=entity_filter,
    )


@bp.route("/restore/<entity>/<int:entity_id>", methods=["POST"])
@roles_required("admin")
def restore_entity(entity, entity_id):
    """Восстановление мягко удалённых записей (п. 4.1.4 ТЗ — окно восстановления)."""
    table_map = {"client": "clients", "order": "orders"}
    table = table_map.get(entity)
    if table is None:
        abort(404)

    db = get_db()
    row = db.execute(f"SELECT * FROM {table} WHERE id = ?", (entity_id,)).fetchone()
    if row is None:
        abort(404)

    restore_window = timedelta(days=current_app.config["SOFT_DELETE_RESTORE_DAYS"])
    if row["deleted_at"]:
        deleted_at = datetime.fromisoformat(row["deleted_at"])
        if datetime.now() - deleted_at > restore_window:
            flash("Срок восстановления записи истёк.", "danger")
            return redirect(url_for("admin.audit_log"))

    db.execute(f"UPDATE {table} SET is_deleted = 0, deleted_at = NULL WHERE id = ?", (entity_id,))
    db.commit()
    log_action(g.user, "restore", entity, entity_id, "восстановлено администратором")
    flash("Запись восстановлена.", "success")
    return redirect(url_for("admin.audit_log"))


@bp.route("/backup", methods=["POST"])
@roles_required("admin")
def run_backup():
    path = backup_db(current_app._get_current_object())
    log_action(g.user, "backup", "database", None, path)
    flash("Резервная копия базы данных создана.", "success")
    return redirect(url_for("admin.list_users"))
