from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort

from app.db import get_db
from app.security import login_required, roles_required
from app.audit import log_action

bp = Blueprint("materials", __name__, url_prefix="/materials")


@bp.route("/")
@login_required
def list_materials():
    db = get_db()
    materials = db.execute(
        "SELECT * FROM materials WHERE is_deleted = 0 ORDER BY name"
    ).fetchall()
    return render_template("materials/list.html", materials=materials)


@bp.route("/new", methods=["GET", "POST"])
@roles_required("admin", "receptionist")
def new_material():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        unit = request.form.get("unit", "").strip()
        try:
            quantity = float(request.form.get("quantity", "0").replace(",", "."))
            min_quantity = float(request.form.get("min_quantity", "0").replace(",", "."))
            price = float(request.form.get("price", "0").replace(",", "."))
        except ValueError:
            flash("Числовые поля указаны некорректно.", "danger")
            return render_template("materials/form.html", material=None)

        if not name or not unit:
            flash("Укажите наименование и единицу измерения.", "danger")
            return render_template("materials/form.html", material=None)

        db = get_db()
        cur = db.execute(
            "INSERT INTO materials (name, unit, quantity, min_quantity, price) VALUES (?, ?, ?, ?, ?)",
            (name, unit, quantity, min_quantity, price),
        )
        db.commit()
        log_action(g.user, "create", "material", cur.lastrowid, name)
        flash("Материал добавлен на склад.", "success")
        return redirect(url_for("materials.list_materials"))

    return render_template("materials/form.html", material=None)


@bp.route("/<int:material_id>/edit", methods=["GET", "POST"])
@roles_required("admin", "receptionist")
def edit_material(material_id):
    db = get_db()
    material = db.execute("SELECT * FROM materials WHERE id = ?", (material_id,)).fetchone()
    if material is None:
        abort(404)

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        unit = request.form.get("unit", "").strip()
        try:
            quantity = float(request.form.get("quantity", "0").replace(",", "."))
            min_quantity = float(request.form.get("min_quantity", "0").replace(",", "."))
            price = float(request.form.get("price", "0").replace(",", "."))
        except ValueError:
            flash("Числовые поля указаны некорректно.", "danger")
            return render_template("materials/form.html", material=material)

        db.execute(
            "UPDATE materials SET name=?, unit=?, quantity=?, min_quantity=?, price=? WHERE id=?",
            (name, unit, quantity, min_quantity, price, material_id),
        )
        db.commit()
        log_action(g.user, "update", "material", material_id, name)
        flash("Данные материала обновлены.", "success")
        return redirect(url_for("materials.list_materials"))

    return render_template("materials/form.html", material=material)


@bp.route("/<int:material_id>/delete", methods=["POST"])
@roles_required("admin")
def delete_material(material_id):
    db = get_db()
    material = db.execute("SELECT * FROM materials WHERE id = ?", (material_id,)).fetchone()
    if material is None:
        abort(404)
    db.execute("UPDATE materials SET is_deleted = 1 WHERE id = ?", (material_id,))
    db.commit()
    log_action(g.user, "delete", "material", material_id, material["name"])
    flash("Материал удалён со склада.", "info")
    return redirect(url_for("materials.list_materials"))
