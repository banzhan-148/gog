import sqlite3
import os
import shutil
from datetime import datetime

from flask import current_app, g


def get_db():
    """Возвращает соединение с БД, привязанное к контексту текущего запроса."""
    if "db" not in g:
        g.db = sqlite3.connect(
            current_app.config["DATABASE_PATH"],
            detect_types=sqlite3.PARSE_DECLTYPES,
        )
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db(app):
    """Создаёт таблицы БД, если они ещё не существуют (идемпотентно)."""
    schema_path = os.path.join(os.path.dirname(app.root_path), "schema.sql")
    with app.app_context():
        db = get_db()
        with open(schema_path, "r", encoding="utf-8") as f:
            db.executescript(f.read())
        db.commit()


def backup_db(app):
    """
    Резервное копирование БД (п. 4.1.8 ТЗ): атомарная копия файла БД
    средствами SQLite Online Backup API, с меткой времени в имени файла.
    """
    backup_dir = app.config["BACKUP_DIR"]
    os.makedirs(backup_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest_path = os.path.join(backup_dir, f"atelie_{timestamp}.db")

    src = sqlite3.connect(app.config["DATABASE_PATH"])
    dest = sqlite3.connect(dest_path)
    with dest:
        src.backup(dest)
    src.close()
    dest.close()

    _cleanup_old_backups(app)
    return dest_path


def _cleanup_old_backups(app):
    backup_dir = app.config["BACKUP_DIR"]
    retention_days = app.config["BACKUP_RETENTION_DAYS"]
    if not os.path.isdir(backup_dir):
        return
    cutoff = datetime.now().timestamp() - retention_days * 86400
    for fname in os.listdir(backup_dir):
        fpath = os.path.join(backup_dir, fname)
        if os.path.isfile(fpath) and os.path.getmtime(fpath) < cutoff:
            os.remove(fpath)


def register_db(app):
    app.teardown_appcontext(close_db)
