import json
from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort

from app.db import get_db
from app.security import login_required, roles_required
from app.audit import log_action

bp = Blueprint("clients", __name__, url_prefix="/clients")

# Типовой набор антропометрических параметров (п. 4.2.1 ТЗ — не менее 15 параметров)
MEASUREMENT_FIELDS = [
    "Рост", "Обхват шеи", "Обхват груди", "Обхват талии", "Обхват бёдер",
    "Ширина плеча", "Длина рукава", "Длина спины до талии", "Длина изделия",
    "Обхват запястья", "Обхват бицепса", "Высота груди", "Центр груди",
    "Длина брюк/юбки", "Обхват колена",
]


@bp.route("/")
@login_required
def list_clients():
    db = get_db()
    q = request.args.get("q", "").strip()
    if q:
        rows = db.execute(
            """SELECT * FROM clients WHERE is_deleted = 0
               AND (full_name LIKE ? OR phone LIKE ?) ORDER BY full_name""",
            (f"%{q}%", f"%{q}%"),
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM clients WHERE is_deleted = 0 ORDER BY created_at DESC"
        ).fetchall()
    return render_template("clients/list.html", clients=rows, q=q)


@bp.route("/new", methods=["GET", "POST"])
@roles_required("receptionist", "director")
def new_client():
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        birth_date = request.form.get("birth_date", "").strip() or None
        notes = request.form.get("notes", "").strip()

        errors = []
        if not full_name:
            errors.append("Укажите ФИО клиента.")
        if not phone:
            errors.append("Укажите контактный телефон.")

        db = get_db()
        if not errors:
            existing = db.execute(
                "SELECT id FROM clients WHERE is_deleted = 0 AND full_name = ? AND phone = ?",
                (full_name, phone),
            ).fetchone()
            if existing:
                flash("Клиент с таким ФИО и телефоном уже зарегистрирован — открываю карточку.", "warning")
                return redirect(url_for("clients.view_client", client_id=existing["id"]))

            cur = db.execute(
                """INSERT INTO clients (full_name, phone, email, birth_date, notes, created_by)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (full_name, phone, email, birth_date, notes, g.user["id"]),
            )
            db.commit()
            log_action(g.user, "create", "client", cur.lastrowid, full_name)
            flash("Клиент зарегистрирован.", "success")
            return redirect(url_for("clients.view_client", client_id=cur.lastrowid))

        for e in errors:
            flash(e, "danger")

    return render_template("clients/form.html", client=None)


@bp.route("/<int:client_id>")
@login_required
def view_client(client_id):
    db = get_db()
    client = db.execute("SELECT * FROM clients WHERE id = ?", (client_id,)).fetchone()
    if client is None:
        abort(404)
    orders = db.execute(
        "SELECT * FROM orders WHERE client_id = ? AND is_deleted = 0 ORDER BY created_at DESC",
        (client_id,),
    ).fetchall()
    measurements = db.execute(
        "SELECT * FROM measurements WHERE client_id = ? ORDER BY measured_at DESC",
        (client_id,),
    ).fetchall()
    measurements = [
        {**dict(m), "params": json.loads(m["params_json"])} for m in measurements
    ]
    return render_template(
        "clients/view.html", client=client, orders=orders, measurements=measurements,
        measurement_fields=MEASUREMENT_FIELDS,
    )


@bp.route("/<int:client_id>/edit", methods=["GET", "POST"])
@roles_required("receptionist", "director")
def edit_client(client_id):
    db = get_db()
    client = db.execute("SELECT * FROM clients WHERE id = ?", (client_id,)).fetchone()
    if client is None:
        abort(404)

    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        birth_date = request.form.get("birth_date", "").strip() or None
        notes = request.form.get("notes", "").strip()

        if not full_name or not phone:
            flash("ФИО и телефон обязательны для заполнения.", "danger")
        else:
            db.execute(
                """UPDATE clients SET full_name=?, phone=?, email=?, birth_date=?, notes=?
                   WHERE id=?""",
                (full_name, phone, email, birth_date, notes, client_id),
            )
            db.commit()
            log_action(g.user, "update", "client", client_id, full_name)
            flash("Данные клиента обновлены.", "success")
            return redirect(url_for("clients.view_client", client_id=client_id))

    return render_template("clients/form.html", client=client)


@bp.route("/<int:client_id>/measurements/new", methods=["POST"])
@roles_required("receptionist", "director")
def add_measurement(client_id):
    db = get_db()
    client = db.execute("SELECT id FROM clients WHERE id = ?", (client_id,)).fetchone()
    if client is None:
        abort(404)

    params = {}
    for field in MEASUREMENT_FIELDS:
        val = request.form.get(f"m_{field}", "").strip()
        if val:
            params[field] = val
    extra_name = request.form.get("extra_name", "").strip()
    extra_value = request.form.get("extra_value", "").strip()
    if extra_name and extra_value:
        params[extra_name] = extra_value

    note = request.form.get("note", "").strip()

    if not params:
        flash("Укажите хотя бы одну мерку.", "danger")
        return redirect(url_for("clients.view_client", client_id=client_id))

    db.execute(
        """INSERT INTO measurements (client_id, measured_at, params_json, note, created_by)
           VALUES (?, ?, ?, ?, ?)""",
        (client_id, datetime.now().isoformat(timespec="seconds"), json.dumps(params, ensure_ascii=False), note, g.user["id"]),
    )
    db.commit()
    log_action(g.user, "create", "measurement", client_id, f"{len(params)} параметров")
    flash("Мерки сохранены.", "success")
    return redirect(url_for("clients.view_client", client_id=client_id))


@bp.route("/<int:client_id>/delete", methods=["POST"])
@roles_required("admin", "receptionist")
def delete_client(client_id):
    db = get_db()
    client = db.execute("SELECT * FROM clients WHERE id = ?", (client_id,)).fetchone()
    if client is None:
        abort(404)
    db.execute(
        "UPDATE clients SET is_deleted = 1, deleted_at = ? WHERE id = ?",
        (datetime.now().isoformat(timespec="seconds"), client_id),
    )
    db.commit()
    log_action(g.user, "delete", "client", client_id, client["full_name"])
    flash("Клиент удалён (запись можно восстановить в журнале действий).", "info")
    return redirect(url_for("clients.list_clients"))
