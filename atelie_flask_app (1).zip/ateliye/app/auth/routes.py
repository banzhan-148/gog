from flask import Blueprint, render_template, request, redirect, url_for, flash, session

from app.db import get_db
from app.security import (
    verify_password, login_user, logout_user, get_current_user,
    is_account_locked, register_failed_login, register_successful_login,
)
from app.audit import log_action

bp = Blueprint("auth", __name__, url_prefix="/auth")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if get_current_user() is not None:
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()

        if user is None:
            log_action(None, "login_failed", "user", None, f"неизвестный логин '{username}'")
            flash("Неверный логин или пароль.", "danger")
        elif is_account_locked(user):
            flash("Учётная запись временно заблокирована из-за нескольких неудачных попыток входа. Повторите позже.", "danger")
            log_action(user, "login_failed", "user", user["id"], "попытка входа в заблокированный аккаунт")
        elif not user["is_active"]:
            flash("Учётная запись отключена. Обратитесь к администратору.", "danger")
        elif not verify_password(user["password_hash"], password):
            register_failed_login(db, user)
            log_action(user, "login_failed", "user", user["id"], "неверный пароль")
            flash("Неверный логин или пароль.", "danger")
        else:
            register_successful_login(db, user)
            login_user(user)
            log_action(user, "login", "user", user["id"], "успешный вход")
            flash(f"Добро пожаловать, {user['full_name']}!", "success")
            next_url = request.args.get("next") or url_for("main.dashboard")
            return redirect(next_url)

    return render_template("auth/login.html")


@bp.route("/logout", methods=["POST"])
def logout():
    user = get_current_user()
    if user is not None:
        log_action(user, "logout", "user", user["id"], "выход из системы")
    logout_user()
    flash("Вы вышли из системы.", "info")
    return redirect(url_for("auth.login"))
