import os
from flask import Flask, render_template, request, g

from config import Config
from app.db import register_db, init_db
from app.security import get_csrf_token, validate_csrf, get_current_user, ROLE_LABELS


def create_app(config_class=Config):
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(config_class)

    register_db(app)

    # Инициализация схемы БД при первом запуске
    if not os.path.exists(app.config["DATABASE_PATH"]):
        init_db(app)
    else:
        init_db(app)  # идемпотентно (CREATE TABLE IF NOT EXISTS)

    # --- Регистрация blueprint'ов (подсистем по ТЗ, п. 4.1.1) ---
    from app.auth.routes import bp as auth_bp
    from app.main.routes import bp as main_bp
    from app.clients.routes import bp as clients_bp
    from app.orders.routes import bp as orders_bp
    from app.materials.routes import bp as materials_bp
    from app.admin.routes import bp as admin_bp
    from app.reports.routes import bp as reports_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(clients_bp)
    app.register_blueprint(orders_bp)
    app.register_blueprint(materials_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(reports_bp)

    # --- CSRF: проверка токена на каждом изменяющем запросе ---
    @app.before_request
    def _csrf_protect():
        # Разрешаем сам вход в систему без предварительно установленного
        # пользователя, но токен всё равно обязателен для любых POST.
        validate_csrf()

    # --- Текущий пользователь доступен во всех обработчиках как g.user ---
    @app.before_request
    def _load_current_user():
        g.user = get_current_user()

    # --- Заголовки безопасности ответа (защита от clickjacking/MIME-sniffing/XSS) ---
    @app.after_request
    def _set_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self' 'unsafe-inline'; "
            "script-src 'self' 'unsafe-inline'; img-src 'self' data:"
        )
        if app.config.get("SESSION_COOKIE_SECURE"):
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        return response

    # --- Доступно во всех шаблонах ---
    @app.context_processor
    def inject_globals():
        from datetime import date
        return {
            "csrf_token": get_csrf_token,
            "current_user": g.get("user"),
            "role_labels": ROLE_LABELS,
            "now_date": date.today().isoformat(),
        }

    # --- Обработчики ошибок ---
    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(400)
    def bad_request(e):
        return render_template("errors/400.html", description=getattr(e, "description", "")), 400

    return app
