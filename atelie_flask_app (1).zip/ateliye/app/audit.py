from flask import request

from app.db import get_db


def log_action(user, action: str, entity: str, entity_id=None, details: str = ""):
    """
    Записывает действие пользователя в журнал (п. 4.1.9 ТЗ).
    user — sqlite3.Row текущего пользователя либо None (напр. неуспешный вход).
    """
    db = get_db()
    db.execute(
        """INSERT INTO audit_log (user_id, username, action, entity, entity_id, details, ip_address)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (
            user["id"] if user else None,
            user["username"] if user else request.form.get("username", ""),
            action,
            entity,
            entity_id,
            details,
            request.remote_addr,
        ),
    )
    db.commit()
