from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort

from app.db import get_db
from app.security import login_required, roles_required
from app.audit import log_action

bp = Blueprint("orders", __name__, url_prefix="/orders")

ORDER_STATUSES = ["принят", "в работе", "на примерке", "готов", "выдан", "отменён"]
ORDER_TYPES = ["пошив", "ремонт", "подгонка"]


def _order_paid_amount(db, order_id):
    row = db.execute(
        "SELECT COALESCE(SUM(amount), 0) s FROM payments WHERE order_id = ? AND is_deleted = 0",
        (order_id,),
    ).fetchone()
    return row["s"]


@bp.route("/")
@login_required
def list_orders():
    db = get_db()
    status = request.args.get("status", "")
    client_q = request.args.get("client", "").strip()
    executor_id = request.args.get("executor_id", "")
    date_from = request.args.get("date_from", "")
    date_to = request.args.get("date_to", "")

    sql = """SELECT o.*, c.full_name AS client_name, u.full_name AS executor_name
              FROM orders o
              JOIN clients c ON c.id = o.client_id
              LEFT JOIN users u ON u.id = o.executor_id
              WHERE o.is_deleted = 0"""
    params = []

    # Исполнителю показываем только его заказы
    if g.user["role"] == "executor":
        sql += " AND o.executor_id = ?"
        params.append(g.user["id"])

    if status:
        sql += " AND o.status = ?"
        params.append(status)
    if client_q:
        sql += " AND c.full_name LIKE ?"
        params.append(f"%{client_q}%")
    if executor_id:
        sql += " AND o.executor_id = ?"
        params.append(executor_id)
    if date_from:
        sql += " AND date(o.created_at) >= date(?)"
        params.append(date_from)
    if date_to:
        sql += " AND date(o.created_at) <= date(?)"
        params.append(date_to)

    sql += " ORDER BY o.created_at DESC"
    orders = db.execute(sql, params).fetchall()

    executors = db.execute(
        "SELECT id, full_name FROM users WHERE role = 'executor' AND is_active = 1 ORDER BY full_name"
    ).fetchall()

    return render_template(
        "orders/list.html", orders=orders, statuses=ORDER_STATUSES, executors=executors,
        filters=dict(status=status, client=client_q, executor_id=executor_id, date_from=date_from, date_to=date_to),
    )


@bp.route("/new", methods=["GET", "POST"])
@roles_required("receptionist", "director")
def new_order():
    db = get_db()
    clients = db.execute("SELECT id, full_name, phone FROM clients WHERE is_deleted = 0 ORDER BY full_name").fetchall()
    executors = db.execute("SELECT id, full_name FROM users WHERE role = 'executor' AND is_active = 1 ORDER BY full_name").fetchall()
    materials = db.execute("SELECT id, name, unit, quantity FROM materials WHERE is_deleted = 0 ORDER BY name").fetchall()

    preset_client_id = request.args.get("client_id", "")

    if request.method == "POST":
        client_id = request.form.get("client_id", "")
        executor_id = request.form.get("executor_id") or None
        order_type = request.form.get("order_type", "")
        description = request.form.get("description", "").strip()
        deadline = request.form.get("deadline", "").strip() or None

        item_names = request.form.getlist("item_name")
        item_descs = request.form.getlist("item_description")
        item_prices = request.form.getlist("item_price")

        errors = []
        if not client_id:
            errors.append("Выберите клиента.")
        if order_type not in ORDER_TYPES:
            errors.append("Укажите корректный вид работ.")
        valid_items = []
        total_price = 0.0
        for name, desc, price in zip(item_names, item_descs, item_prices):
            name = name.strip()
            if not name:
                continue
            try:
                price_val = float(price.replace(",", ".")) if price else 0.0
            except ValueError:
                price_val = 0.0
                errors.append(f"Некорректная стоимость для позиции «{name}».")
            valid_items.append((name, desc.strip(), price_val))
            total_price += price_val
        if not valid_items:
            errors.append("Добавьте хотя бы одно изделие в заказ.")

        if errors:
            for e in errors:
                flash(e, "danger")
        else:
            cur = db.execute(
                """INSERT INTO orders (client_id, executor_id, order_type, status, description, price, deadline, created_by)
                   VALUES (?, ?, ?, 'принят', ?, ?, ?, ?)""",
                (client_id, executor_id, order_type, description, total_price, deadline, g.user["id"]),
            )
            order_id = cur.lastrowid
            for name, desc, price_val in valid_items:
                db.execute(
                    "INSERT INTO order_items (order_id, item_name, description, price) VALUES (?, ?, ?, ?)",
                    (order_id, name, desc, price_val),
                )

            # Списание материалов (опционально указывается при оформлении)
            mat_ids = request.form.getlist("material_id")
            mat_qtys = request.form.getlist("material_qty")
            for mid, qty in zip(mat_ids, mat_qtys):
                if not mid or not qty:
                    continue
                try:
                    qty_val = float(qty.replace(",", "."))
                except ValueError:
                    continue
                if qty_val <= 0:
                    continue
                material = db.execute("SELECT * FROM materials WHERE id = ?", (mid,)).fetchone()
                if material is None:
                    continue
                new_qty = max(material["quantity"] - qty_val, 0)
                db.execute("UPDATE materials SET quantity = ? WHERE id = ?", (new_qty, mid))
                db.execute(
                    "INSERT INTO material_writeoffs (material_id, order_id, quantity, created_by) VALUES (?, ?, ?, ?)",
                    (mid, order_id, qty_val, g.user["id"]),
                )

            db.commit()
            log_action(g.user, "create", "order", order_id, f"{order_type}, сумма {total_price:.2f}")
            flash("Заказ оформлен.", "success")
            return redirect(url_for("orders.view_order", order_id=order_id))

    return render_template(
        "orders/form.html", clients=clients, executors=executors, materials=materials,
        order_types=ORDER_TYPES, preset_client_id=preset_client_id,
    )


@bp.route("/<int:order_id>")
@login_required
def view_order(order_id):
    db = get_db()
    order = db.execute(
        """SELECT o.*, c.full_name AS client_name, c.phone AS client_phone,
                  u.full_name AS executor_name
           FROM orders o JOIN clients c ON c.id = o.client_id
           LEFT JOIN users u ON u.id = o.executor_id
           WHERE o.id = ?""",
        (order_id,),
    ).fetchone()
    if order is None:
        abort(404)
    if g.user["role"] == "executor" and order["executor_id"] != g.user["id"]:
        abort(403)

    items = db.execute("SELECT * FROM order_items WHERE order_id = ?", (order_id,)).fetchall()
    payments = db.execute(
        "SELECT * FROM payments WHERE order_id = ? AND is_deleted = 0 ORDER BY created_at", (order_id,)
    ).fetchall()
    writeoffs = db.execute(
        """SELECT w.*, m.name AS material_name, m.unit FROM material_writeoffs w
           JOIN materials m ON m.id = w.material_id WHERE w.order_id = ?""",
        (order_id,),
    ).fetchall()
    paid = _order_paid_amount(db, order_id)
    balance = order["price"] - paid

    executors = db.execute(
        "SELECT id, full_name FROM users WHERE role = 'executor' AND is_active = 1 ORDER BY full_name"
    ).fetchall()

    return render_template(
        "orders/view.html", order=order, items=items, payments=payments, writeoffs=writeoffs,
        paid=paid, balance=balance, statuses=ORDER_STATUSES, executors=executors,
    )


@bp.route("/<int:order_id>/status", methods=["POST"])
@roles_required("receptionist", "executor", "director")
def change_status(order_id):
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    if order is None:
        abort(404)
    if g.user["role"] == "executor" and order["executor_id"] != g.user["id"]:
        abort(403)

    new_status = request.form.get("status", "")
    if new_status not in ORDER_STATUSES:
        flash("Некорректный статус.", "danger")
        return redirect(url_for("orders.view_order", order_id=order_id))

    if new_status == "выдан":
        paid = _order_paid_amount(db, order_id)
        if paid < order["price"] and not request.form.get("confirm_debt"):
            flash("Нельзя выдать заказ без полной оплаты. Если это выдача в долг — подтвердите явно на форме.", "danger")
            return redirect(url_for("orders.view_order", order_id=order_id))

    db.execute(
        "UPDATE orders SET status = ?, updated_at = ? WHERE id = ?",
        (new_status, datetime.now().isoformat(timespec="seconds"), order_id),
    )
    db.commit()
    log_action(g.user, "update", "order", order_id, f"статус → {new_status}")
    flash(f"Статус заказа изменён на «{new_status}».", "success")
    return redirect(url_for("orders.view_order", order_id=order_id))


@bp.route("/<int:order_id>/executor", methods=["POST"])
@roles_required("receptionist", "director")
def assign_executor(order_id):
    db = get_db()
    order = db.execute("SELECT id FROM orders WHERE id = ?", (order_id,)).fetchone()
    if order is None:
        abort(404)
    executor_id = request.form.get("executor_id") or None
    db.execute("UPDATE orders SET executor_id = ?, updated_at = ? WHERE id = ?",
               (executor_id, datetime.now().isoformat(timespec="seconds"), order_id))
    db.commit()
    log_action(g.user, "update", "order", order_id, f"назначен исполнитель id={executor_id}")
    flash("Исполнитель назначен.", "success")
    return redirect(url_for("orders.view_order", order_id=order_id))


@bp.route("/<int:order_id>/payments/new", methods=["POST"])
@roles_required("receptionist", "director")
def add_payment(order_id):
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    if order is None:
        abort(404)

    try:
        amount = float(request.form.get("amount", "0").replace(",", "."))
    except ValueError:
        amount = 0
    method = request.form.get("method", "")
    payment_type = request.form.get("payment_type", "")

    errors = []
    if amount <= 0:
        errors.append("Сумма оплаты должна быть положительной.")
    if method not in ("наличные", "безналичный"):
        errors.append("Укажите способ оплаты.")
    if payment_type not in ("предоплата", "доплата", "полная оплата"):
        errors.append("Укажите тип оплаты.")

    paid_before = _order_paid_amount(db, order_id)
    if amount > (order["price"] - paid_before) + 0.01:
        errors.append(
            f"Сумма превышает остаток задолженности ({order['price'] - paid_before:.2f} ₽)."
        )

    if errors:
        for e in errors:
            flash(e, "danger")
    else:
        db.execute(
            """INSERT INTO payments (order_id, amount, method, payment_type, created_by)
               VALUES (?, ?, ?, ?, ?)""",
            (order_id, amount, method, payment_type, g.user["id"]),
        )
        db.commit()
        log_action(g.user, "create", "payment", order_id, f"{amount:.2f} ₽ ({payment_type})")
        flash("Оплата зарегистрирована.", "success")

    return redirect(url_for("orders.view_order", order_id=order_id))


@bp.route("/<int:order_id>/print")
@login_required
def print_order(order_id):
    db = get_db()
    order = db.execute(
        """SELECT o.*, c.full_name AS client_name, c.phone AS client_phone
           FROM orders o JOIN clients c ON c.id = o.client_id WHERE o.id = ?""",
        (order_id,),
    ).fetchone()
    if order is None:
        abort(404)
    items = db.execute("SELECT * FROM order_items WHERE order_id = ?", (order_id,)).fetchall()
    paid = _order_paid_amount(db, order_id)
    return render_template("orders/print.html", order=order, items=items, paid=paid, balance=order["price"] - paid)


@bp.route("/<int:order_id>/delete", methods=["POST"])
@roles_required("admin", "receptionist")
def delete_order(order_id):
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    if order is None:
        abort(404)
    db.execute(
        "UPDATE orders SET is_deleted = 1, deleted_at = ? WHERE id = ?",
        (datetime.now().isoformat(timespec="seconds"), order_id),
    )
    db.commit()
    log_action(g.user, "delete", "order", order_id, f"заказ №{order_id}")
    flash("Заказ удалён (можно восстановить через журнал действий в течение 30 дней).", "info")
    return redirect(url_for("orders.list_orders"))
