"""
Первичное наполнение базы данных: создаёт учётную запись администратора
(и, при желании, демонстрационные данные). Запускать один раз после
установки: `python seed.py`
"""
import getpass
import sys

from app import create_app
from app.db import get_db
from app.security import hash_password, validate_password_policy


def main():
    app = create_app()
    with app.app_context():
        db = get_db()
        existing_admin = db.execute("SELECT id FROM users WHERE role = 'admin'").fetchone()
        if existing_admin:
            print("Учётная запись администратора уже существует — пропускаю создание.")
        else:
            print("Создание первой учётной записи администратора системы.")
            username = input("Логин администратора [admin]: ").strip() or "admin"
            full_name = input("ФИО администратора: ").strip() or "Администратор системы"
            while True:
                password = getpass.getpass("Пароль (мин. 8 симв., буквы+цифры): ")
                errors = validate_password_policy(password)
                if errors:
                    for e in errors:
                        print(" -", e)
                    continue
                confirm = getpass.getpass("Повторите пароль: ")
                if password != confirm:
                    print(" - Пароли не совпадают, попробуйте ещё раз.")
                    continue
                break

            db.execute(
                "INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, 'admin')",
                (username, hash_password(password), full_name),
            )
            db.commit()
            print(f"Готово. Учётная запись «{username}» с ролью «Администратор» создана.")

        if "--demo" in sys.argv:
            _seed_demo_data(db)
            print("Демонстрационные данные добавлены.")


def _seed_demo_data(db):
    def ensure_user(username, full_name, role):
        row = db.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
        if row:
            return row["id"]
        cur = db.execute(
            "INSERT INTO users (username, password_hash, full_name, role) VALUES (?,?,?,?)",
            (username, hash_password("Demo1234"), full_name, role),
        )
        db.commit()
        return cur.lastrowid

    receptionist_id = ensure_user("receptionist", "Иванова Мария Сергеевна", "receptionist")
    executor_id = ensure_user("tailor1", "Петров Пётр Иванович", "executor")
    ensure_user("director", "Сидорова Анна Викторовна", "director")

    client = db.execute("SELECT id FROM clients LIMIT 1").fetchone()
    if not client:
        cur = db.execute(
            "INSERT INTO clients (full_name, phone, email, created_by) VALUES (?,?,?,?)",
            ("Кузнецова Ольга Николаевна", "+7 900 111-22-33", "olga@example.com", receptionist_id),
        )
        db.commit()
        client_id = cur.lastrowid
    else:
        client_id = client["id"]

    material = db.execute("SELECT id FROM materials LIMIT 1").fetchone()
    if not material:
        db.execute(
            "INSERT INTO materials (name, unit, quantity, min_quantity, price) VALUES (?,?,?,?,?)",
            ("Костюмная ткань (шерсть), синяя", "м", 25, 5, 1200),
        )
        db.commit()

    order = db.execute("SELECT id FROM orders LIMIT 1").fetchone()
    if not order:
        cur = db.execute(
            """INSERT INTO orders (client_id, executor_id, order_type, status, description, price, deadline, created_by)
               VALUES (?,?,?,?,?,?,?,?)""",
            (client_id, executor_id, "пошив", "в работе", "Пошив классического костюма", 8500, "2026-10-15", receptionist_id),
        )
        db.commit()
        order_id = cur.lastrowid
        db.execute(
            "INSERT INTO order_items (order_id, item_name, description, price) VALUES (?,?,?,?)",
            (order_id, "Костюм классический", "Пиджак + брюки, индивидуальный пошив", 8500),
        )
        db.execute(
            "INSERT INTO payments (order_id, amount, method, payment_type, created_by) VALUES (?,?,?,?,?)",
            (order_id, 4000, "наличные", "предоплата", receptionist_id),
        )
        db.commit()


if __name__ == "__main__":
    main()
