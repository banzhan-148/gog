-- Схема базы данных АИС «Ателье»
-- СУБД: SQLite. Соответствует разделу 4.3.2 ТЗ на АС.

PRAGMA foreign_keys = ON;

-- Пользователи системы и их роли (п. 4.1.9, 3.1 ТЗ)
CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    username        TEXT NOT NULL UNIQUE,
    password_hash   TEXT NOT NULL,
    full_name       TEXT NOT NULL,
    role            TEXT NOT NULL CHECK (role IN ('admin', 'receptionist', 'executor', 'director')),
    phone           TEXT,
    is_active       INTEGER NOT NULL DEFAULT 1,
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    locked_until    TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    last_login_at   TEXT
);

-- Клиенты ателье (п. 4.2.1 ТЗ)
CREATE TABLE IF NOT EXISTS clients (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name   TEXT NOT NULL,
    phone       TEXT NOT NULL,
    email       TEXT,
    birth_date  TEXT,
    notes       TEXT,
    created_by  INTEGER REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    is_deleted  INTEGER NOT NULL DEFAULT 0,
    deleted_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_clients_name ON clients(full_name);
CREATE INDEX IF NOT EXISTS idx_clients_phone ON clients(phone);

-- Мерки клиента, с историей по датам снятия (п. 4.2.1 ТЗ)
CREATE TABLE IF NOT EXISTS measurements (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   INTEGER NOT NULL REFERENCES clients(id),
    measured_at TEXT NOT NULL DEFAULT (datetime('now')),
    params_json TEXT NOT NULL,   -- JSON: {"Рост": 170, "Обхват груди": 96, ...}
    note        TEXT,
    created_by  INTEGER REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_measurements_client ON measurements(client_id);

-- Материалы и фурнитура (п. 4.2.3 ТЗ)
CREATE TABLE IF NOT EXISTS materials (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL,
    unit            TEXT NOT NULL,           -- м, шт, компл. и т.п.
    quantity        REAL NOT NULL DEFAULT 0,
    min_quantity    REAL NOT NULL DEFAULT 0,
    price           REAL NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    is_deleted      INTEGER NOT NULL DEFAULT 0
);

-- Заказы (п. 4.2.2 ТЗ)
CREATE TABLE IF NOT EXISTS orders (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id    INTEGER NOT NULL REFERENCES clients(id),
    executor_id  INTEGER REFERENCES users(id),
    order_type   TEXT NOT NULL CHECK (order_type IN ('пошив', 'ремонт', 'подгонка')),
    status       TEXT NOT NULL DEFAULT 'принят'
                 CHECK (status IN ('принят', 'в работе', 'на примерке', 'готов', 'выдан', 'отменён')),
    description  TEXT,
    price        REAL NOT NULL DEFAULT 0,
    deadline     TEXT,
    created_by   INTEGER REFERENCES users(id),
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now')),
    is_deleted   INTEGER NOT NULL DEFAULT 0,
    deleted_at   TEXT
);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_client ON orders(client_id);
CREATE INDEX IF NOT EXISTS idx_orders_executor ON orders(executor_id);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);

-- Позиции (изделия) заказа
CREATE TABLE IF NOT EXISTS order_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id    INTEGER NOT NULL REFERENCES orders(id),
    item_name   TEXT NOT NULL,
    description TEXT,
    price       REAL NOT NULL DEFAULT 0
);

-- Списание материалов по заказу (п. 4.2.3 ТЗ)
CREATE TABLE IF NOT EXISTS material_writeoffs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    material_id INTEGER NOT NULL REFERENCES materials(id),
    order_id    INTEGER REFERENCES orders(id),
    quantity    REAL NOT NULL,
    created_by  INTEGER REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Оплаты по заказам (п. 4.2.5 ТЗ)
CREATE TABLE IF NOT EXISTS payments (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id       INTEGER NOT NULL REFERENCES orders(id),
    amount         REAL NOT NULL,
    method         TEXT NOT NULL CHECK (method IN ('наличные', 'безналичный')),
    payment_type   TEXT NOT NULL CHECK (payment_type IN ('предоплата', 'доплата', 'полная оплата')),
    created_by     INTEGER REFERENCES users(id),
    created_at     TEXT NOT NULL DEFAULT (datetime('now')),
    is_deleted     INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_payments_order ON payments(order_id);

-- Журнал действий пользователей (п. 4.1.9 ТЗ — защита информации от НСД)
CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER REFERENCES users(id),
    username    TEXT,
    action      TEXT NOT NULL,      -- create / update / delete / restore / login / login_failed / logout
    entity      TEXT NOT NULL,      -- client / order / payment / material / user ...
    entity_id   INTEGER,
    details     TEXT,
    ip_address  TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);
