"""Material write-off and stock adjustments."""
from __future__ import annotations

import logging
from typing import Any

from db import q, transaction, execute

logger = logging.getLogger(__name__)


class MaterialService:
    @staticmethod
    def writeoff(oid: int, material_id: int, qty: float) -> dict[str, Any]:
        o = q('SELECT * FROM orders WHERE id=? AND is_deleted=0', (oid,), one=True)
        if not o:
            raise ValueError('order_not_found')
        m = q('SELECT * FROM materials WHERE id=?', (material_id,), one=True)
        if not m:
            raise ValueError('material_not_found')
        if qty <= 0:
            raise ValueError('invalid_qty')
        if qty > m['stock']:
            raise ValueError('insufficient_stock')

        new_stock = round(m['stock'] - qty, 3)
        with transaction() as db:
            db.execute(
                'INSERT INTO material_writeoffs (order_id, material_id, qty) '
                'VALUES (?, ?, ?)',
                (oid, material_id, qty),
            )
            db.execute('UPDATE materials SET stock=? WHERE id=?', (new_stock, material_id))
        logger.info(
            'Writeoff material=%s qty=%.3f order=%s stock_now=%.3f',
            m['name'], qty, o['number'], new_stock,
        )
        return m

    @staticmethod
    def adjust_stock(material_id: int, delta: float) -> float:
        m = q('SELECT * FROM materials WHERE id=?', (material_id,), one=True)
        if not m:
            raise ValueError('material_not_found')
        new_stock = round(m['stock'] + delta, 3)
        if new_stock < 0:
            raise ValueError('negative_stock')
        execute('UPDATE materials SET stock=? WHERE id=?', (new_stock, material_id))
        return new_stock
