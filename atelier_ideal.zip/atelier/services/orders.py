"""Order domain service: create, status, debt flags."""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from config import Config
from db import q, transaction

logger = logging.getLogger(__name__)


class OrderService:
    @staticmethod
    def next_number() -> str:
        last = q('SELECT id FROM orders ORDER BY id DESC LIMIT 1', one=True)
        seq = (last['id'] if last else 0) + 1
        year = datetime.now(timezone.utc).year
        return f'AT-{year}-{seq:05d}'

    @staticmethod
    def create(
        *,
        client_id: int,
        worker_id: int | None,
        work_type: str,
        description: str,
        due_date: str | None,
        items: list[tuple[str, int, float]],
        created_by: int,
    ) -> int:
        if work_type not in Config.WORK_TYPES:
            work_type = 'пошив'
        total = sum(qty * price for _, qty, price in items)
        number = OrderService.next_number()

        with transaction() as db:
            cur = db.execute(
                """INSERT INTO orders
                   (number, client_id, worker_id, work_type, description,
                    status, total, paid, due_date, created_by)
                   VALUES (?, ?, ?, ?, ?, 'принят', ?, 0, ?, ?)""",
                (number, client_id, worker_id, work_type, description,
                 total, due_date, created_by),
            )
            oid = cur.lastrowid
            for name, qty, price in items:
                db.execute(
                    'INSERT INTO order_items (order_id, name, qty, price) '
                    'VALUES (?, ?, ?, ?)',
                    (oid, name, qty, price),
                )
        logger.info('Order created number=%s id=%s total=%.2f', number, oid, total)
        return oid

    @staticmethod
    def update_status(oid: int, new_status: str, *, allow_unpaid_issue: bool) -> dict[str, Any]:
        o = q('SELECT * FROM orders WHERE id=? AND is_deleted=0', (oid,), one=True)
        if not o:
            raise ValueError('order_not_found')
        if new_status not in Config.ORDER_STATUSES:
            raise ValueError('invalid_status')
        debt = (o['total'] or 0) - (o['paid'] or 0)
        if new_status == 'выдан' and debt > 0 and not o['is_debt'] and not allow_unpaid_issue:
            raise ValueError('unpaid_issue_forbidden')
        from db import execute
        execute('UPDATE orders SET status=? WHERE id=?', (new_status, oid))
        logger.info('Order %s status %s -> %s', o['number'], o['status'], new_status)
        return o

    @staticmethod
    def set_debt(oid: int, is_debt: bool) -> None:
        from db import execute
        execute('UPDATE orders SET is_debt=? WHERE id=?', (1 if is_debt else 0, oid))

    @staticmethod
    def soft_delete(oid: int) -> None:
        from db import execute
        execute('UPDATE orders SET is_deleted=1 WHERE id=?', (oid,))
