"""Payment domain service — atomic payment + order.paid update."""
from __future__ import annotations

import logging
from typing import Any

from db import q, transaction

logger = logging.getLogger(__name__)


class PaymentService:
    @staticmethod
    def add_payment(
        oid: int,
        amount: float,
        method: str = 'наличные',
        kind: str = 'доплата',
    ) -> dict[str, Any]:
        o = q('SELECT * FROM orders WHERE id=? AND is_deleted=0', (oid,), one=True)
        if not o:
            raise ValueError('order_not_found')
        if amount <= 0:
            raise ValueError('invalid_amount')

        new_paid = round((o['paid'] or 0) + amount, 2)
        with transaction() as db:
            db.execute(
                'INSERT INTO payments (order_id, amount, method, kind) '
                'VALUES (?, ?, ?, ?)',
                (oid, amount, method, kind),
            )
            db.execute('UPDATE orders SET paid=? WHERE id=?', (new_paid, oid))
        logger.info('Payment %.2f for order %s (paid now %.2f)', amount, o['number'], new_paid)
        return o
