"""User / password policy service."""
from __future__ import annotations

import logging
import re
from typing import Any

from werkzeug.security import generate_password_hash

from config import Config
from db import q, execute

logger = logging.getLogger(__name__)


class UserService:
    @staticmethod
    def validate_password(password: str) -> str | None:
        """Return error message or None if OK."""
        min_len = Config.PASSWORD_MIN_LENGTH
        if not password or len(password) < min_len:
            return f'Пароль должен содержать минимум {min_len} символов'
        if Config.PASSWORD_REQUIRE_LETTER and not re.search(r'[A-Za-zА-Яа-я]', password):
            return 'Пароль должен содержать хотя бы одну букву'
        if Config.PASSWORD_REQUIRE_DIGIT and not re.search(r'\d', password):
            return 'Пароль должен содержать хотя бы одну цифру'
        return None

    @staticmethod
    def create(username: str, full_name: str, password: str, role: str) -> int:
        err = UserService.validate_password(password)
        if err:
            raise ValueError(err)
        if role not in Config.ROLES:
            raise ValueError('invalid_role')
        exists = q('SELECT id FROM users WHERE username=?', (username,), one=True)
        if exists:
            raise ValueError('username_taken')
        uid = execute(
            'INSERT INTO users (username, full_name, password_hash, role) '
            'VALUES (?, ?, ?, ?)',
            (username, full_name, generate_password_hash(password), role),
        )
        logger.info('User created id=%s username=%s role=%s', uid, username, role)
        return uid

    @staticmethod
    def reset_password(uid: int, password: str) -> None:
        err = UserService.validate_password(password)
        if err:
            raise ValueError(err)
        u = q('SELECT id FROM users WHERE id=?', (uid,), one=True)
        if not u:
            raise ValueError('user_not_found')
        execute(
            'UPDATE users SET password_hash=? WHERE id=?',
            (generate_password_hash(password), uid),
        )
        logger.info('Password reset for user id=%s', uid)
