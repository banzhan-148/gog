"""Client CRUD helpers."""
from __future__ import annotations

import logging
from typing import Any

from db import q, execute

logger = logging.getLogger(__name__)


class ClientService:
    @staticmethod
    def create(
        full_name: str,
        phone: str = '',
        email: str = '',
        birth_date: str | None = None,
    ) -> int:
        if not full_name:
            raise ValueError('full_name_required')
        dup = q(
            "SELECT id FROM clients WHERE is_deleted=0 "
            "AND full_name=? AND IFNULL(phone,'')=?",
            (full_name, phone),
            one=True,
        )
        if dup:
            raise ValueError(f'duplicate:{dup["id"]}')
        cid = execute(
            'INSERT INTO clients (full_name, phone, email, birth_date) '
            'VALUES (?, ?, ?, ?)',
            (full_name, phone, email, birth_date),
        )
        logger.info('Client created id=%s name=%s', cid, full_name)
        return cid

    @staticmethod
    def update(
        cid: int,
        *,
        full_name: str,
        phone: str = '',
        email: str = '',
        birth_date: str | None = None,
    ) -> None:
        c = q('SELECT id FROM clients WHERE id=? AND is_deleted=0', (cid,), one=True)
        if not c:
            raise ValueError('client_not_found')
        if not full_name:
            raise ValueError('full_name_required')
        execute(
            'UPDATE clients SET full_name=?, phone=?, email=?, birth_date=? WHERE id=?',
            (full_name, phone, email, birth_date, cid),
        )
        logger.info('Client updated id=%s', cid)

    @staticmethod
    def soft_delete(cid: int) -> None:
        execute('UPDATE clients SET is_deleted=1 WHERE id=?', (cid,))
