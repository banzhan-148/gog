"""АИС «Ателье» — application factory and entry point."""
from __future__ import annotations

import logging
import os
import traceback

from flask import Flask, render_template, flash, redirect, url_for
from flask_wtf.csrf import CSRFError

from config import get_config, Config as DefaultConfig
from extensions import csrf, limiter
from db import close_db, init_db
from security import load_secret_key, init_talisman
from logging_config import setup_logging

logger = logging.getLogger(__name__)


def create_app(config_name: str | None = None) -> Flask:
    """Application factory.

    config_name: 'development' | 'testing' | 'production' | None (from FLASK_ENV)
    """
    cfg = get_config(config_name)

    # Keep module-level Config in sync for modules that import it directly
    import config as config_module
    config_module.Config = cfg

    app = Flask(
        __name__,
        static_folder=cfg.STATIC_DIR,
        template_folder=cfg.TEMPLATES_DIR,
    )

    app.config.from_object(cfg)
    app.secret_key = load_secret_key(cfg)

    app.config.update(
        PERMANENT_SESSION_LIFETIME=cfg.PERMANENT_SESSION_LIFETIME,
        SESSION_COOKIE_SECURE=cfg.SESSION_COOKIE_SECURE,
        SESSION_COOKIE_HTTPONLY=cfg.SESSION_COOKIE_HTTPONLY,
        SESSION_COOKIE_SAMESITE=cfg.SESSION_COOKIE_SAMESITE,
        WTF_CSRF_ENABLED=cfg.WTF_CSRF_ENABLED,
        WTF_CSRF_TIME_LIMIT=cfg.WTF_CSRF_TIME_LIMIT,
        WTF_CSRF_SSL_STRICT=cfg.WTF_CSRF_SSL_STRICT,
        WTF_CSRF_CHECK_DEFAULT=cfg.WTF_CSRF_CHECK_DEFAULT,
        MAX_CONTENT_LENGTH=cfg.MAX_CONTENT_LENGTH,
        PREFERRED_URL_SCHEME=cfg.PREFERRED_URL_SCHEME,
        TRAP_HTTP_EXCEPTIONS=False,
        TRAP_BAD_REQUEST_ERRORS=False,
        PROPAGATE_EXCEPTIONS=False,
        RATELIMIT_STORAGE_URI=cfg.RATELIMIT_STORAGE_URI,
    )

    setup_logging(app)

    # Extensions
    csrf.init_app(app)
    # Reconfigure limiter storage from config (Redis preferred in prod)
    limiter._storage_uri = cfg.RATELIMIT_STORAGE_URI
    limiter.init_app(app)
    app.config['RATELIMIT_DEFAULT'] = cfg.DEFAULT_LIMIT

    if not cfg.IS_DEV and cfg.RATELIMIT_STORAGE_URI.startswith('memory://'):
        logger.warning(
            'Production is using in-memory rate limiter — '
            'set RATELIMIT_STORAGE_URI=redis://... for multi-process safety',
        )

    init_talisman(app, cfg)
    app.teardown_appcontext(close_db)

    # Blueprints
    from blueprints.auth import bp as auth_bp
    from blueprints.dashboard import bp as dashboard_bp
    from blueprints.clients import bp as clients_bp
    from blueprints.orders import bp as orders_bp
    from blueprints.materials import bp as materials_bp
    from blueprints.workers import bp as workers_bp
    from blueprints.payments import bp as payments_bp
    from blueprints.reports import bp as reports_bp
    from blueprints.admin import bp as admin_bp
    from blueprints.api import bp as api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(clients_bp)
    app.register_blueprint(orders_bp)
    app.register_blueprint(materials_bp)
    app.register_blueprint(workers_bp)
    app.register_blueprint(payments_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(api_bp)

    from utils import current_user, has_role

    @app.context_processor
    def inject_user():
        return {
            'current_user': current_user(),
            'has_role': has_role,
            'ORDER_STATUSES': cfg.ORDER_STATUSES,
            'WORK_TYPES': cfg.WORK_TYPES,
        }

    # Error handlers
    @app.errorhandler(CSRFError)
    def handle_csrf_error(e):
        logger.warning('CSRF rejected: %s', e.description)
        flash('Ошибка безопасности: обновите страницу и попробуйте снова.', 'error')
        return redirect(url_for('auth.login'))

    @app.errorhandler(429)
    def ratelimit_handler(e):
        from flask_limiter.util import get_remote_address
        logger.warning('Rate limit hit: IP=%s', get_remote_address())
        return render_template(
            'login.html',
            error429=True,
            error_message=str(e.description),
        ), 429

    @app.errorhandler(403)
    def err403(e):
        return render_template(
            'error.html', code=403,
            message='Недостаточно прав для доступа к странице',
        ), 403

    @app.errorhandler(404)
    def err404(e):
        return render_template(
            'error.html', code=404, message='Страница не найдена',
        ), 404

    @app.errorhandler(405)
    def err405(e):
        return render_template(
            'error.html', code=405, message='Метод не разрешён',
        ), 405

    @app.errorhandler(500)
    def err500(e):
        logger.exception('Internal server error')
        return render_template(
            'error.html', code=500, message='Внутренняя ошибка сервера',
        ), 500

    return app


def print_diagnostics(cfg=None) -> None:
    cfg = cfg or DefaultConfig
    logger.info('=' * 60)
    logger.info('АИС «Ателье» — диагностика')
    logger.info('Режим         : %s', 'РАЗРАБОТКА' if cfg.IS_DEV else 'ПРОДАКШЕН')
    logger.info('Secure cookie : %s', cfg.SESSION_COOKIE_SECURE)
    logger.info('HSTS / HTTPS  : %s', not cfg.IS_DEV)
    logger.info('CSRF time     : %s сек', cfg.WTF_CSRF_TIME_LIMIT)
    logger.info('Limiter       : %s', cfg.RATELIMIT_STORAGE_URI)
    logger.info('DB_PATH       : %s (exists: %s)', cfg.DATABASE, os.path.isfile(cfg.DATABASE))
    logger.info('=' * 60)


# Module-level app for flask run / WSGI
app = create_app()


if __name__ == '__main__':
    print_diagnostics()
    init_db()
    if DefaultConfig.IS_DEV:
        logger.info('Open: http://localhost:5000')
        logger.info('DEV: first login admin / admin123 — change password immediately!')
    else:
        logger.info('PRODUCTION mode. Use HTTPS reverse proxy (nginx/caddy).')
        logger.info('Admin is created only via ADMIN_PASSWORD env on first run.')
    app.run(debug=False, host='0.0.0.0', port=5000, use_reloader=False)
