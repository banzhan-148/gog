# Security policy — АИС «Ателье»

## Что уже закрыто

| Угроза | Мера |
|--------|------|
| SQL-injection | Только параметризованные запросы (`?` placeholders) |
| CSRF | Flask-WTF на всех формах, `WTF_CSRF_CHECK_DEFAULT=True` |
| XSS / clickjacking | CSP **без** `unsafe-inline`, `X-Frame-Options: DENY`, Talisman |
| Session fixation | `session.clear()` перед логином, Secure/HttpOnly/SameSite cookies |
| Brute-force login | Flask-Limiter (`10 per minute` на POST /login) |
| CSV formula injection | `csv_safe()` префиксует `= + - @` |
| Privilege escalation | `@role_required` на каждом чувствительном маршруте |
| Race на оплату/списание | `transaction()` (BEGIN/COMMIT/ROLLBACK) |
| Слабые пароли (prod) | минимум 12 символов, буква + цифра (`UserService.validate_password`) |
| Хардкод секретов | `FLASK_SECRET_KEY` / `.secret_key` (chmod 600), prod-админ только из env |
| Demo-аккаунты в prod | запрещены; `ADMIN_PASSWORD` обязателен |

## Обязательные настройки production

```bash
export FLASK_ENV=production
export FLASK_SECRET_KEY="$(openssl rand -hex 32)"
export ADMIN_PASSWORD="..."          # ≥ 12 символов
export RATELIMIT_STORAGE_URI="redis://127.0.0.1:6379/0"
```

**Не используйте `memory://` rate-limiter** при нескольких процессах Gunicorn — лимиты не шарятся.

## Рекомендации

1. HTTPS-only (прокси + `force_https` Talisman).
2. Регулярный `pip-audit -r requirements.lock`.
3. Бэкапы БД (кнопка в `/admin` или cron).
4. Смена паролей demo-пользователей сразу после первого входа в dev.
5. Ограничить доступ к файлу `atelier.db` и `.secret_key` (права ОС).
6. Не открывать порт Flask наружу — только через reverse proxy.

## Отчёт об уязвимостях

Сообщайте ответственному за систему. Не публикуйте эксплойты до исправления.
