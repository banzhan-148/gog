"""Shared helpers: auth decorators, sanitizers, pagination, CSV safety."""
from __future__ import annotations

import logging
import re
from functools import wraps
from typing import Any

from flask import session, redirect, url_for, abort, request

from db import q, execute

logger = logging.getLogger(__name__)


def current_user() -> dict[str, Any] | None:
    uid = session.get('user_id')
    if not uid:
        return None
    return q('SELECT * FROM users WHERE id=? AND is_active=1', (uid,), one=True)


def login_required(f):
    @wraps(f)
    def wrapper(*a, **kw):
        if not current_user():
            return redirect(url_for('auth.login', next=request.path))
        return f(*a, **kw)
    return wrapper


def role_required(*roles):
    def deco(f):
        @wraps(f)
        def wrapper(*a, **kw):
            u = current_user()
            if not u:
                return redirect(url_for('auth.login'))
            if roles and u['role'] not in roles:
                abort(403)
            return f(*a, **kw)
        return wrapper
    return deco


def has_role(*roles) -> bool:
    u = current_user()
    return bool(u and u['role'] in roles)


def log_action(action: str, target: str | None = None, target_id: int | None = None) -> None:
    u = current_user()
    try:
        execute(
            'INSERT INTO audit_log (user_id, action, target, target_id) '
            'VALUES (?, ?, ?, ?)',
            (u['id'] if u else None, action, target, target_id),
        )
    except Exception as exc:
        logger.error(
            'AUDIT ERROR action=%r target=%r target_id=%r: %s',
            action, target, target_id, exc,
        )


def log_failed_login(username: str, reason: str = 'bad_credentials') -> None:
    try:
        ip = request.remote_addr or '-'
        execute(
            'INSERT INTO audit_log (user_id, action, target, target_id) '
            'VALUES (?, ?, ?, ?)',
            (None, f'Неудачный вход: {username} ({reason}) IP={ip}', 'auth', None),
        )
    except Exception as exc:
        logger.error('AUDIT ERROR failed_login username=%r: %s', username, exc)


def clean_text(value: Any, max_len: int = 500) -> str:
    if value is None:
        return ''
    s = str(value).strip()
    s = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', s)
    return s[:max_len]


def clean_phone(value: Any) -> str:
    if not value:
        return ''
    return re.sub(r'[^\d+\-() ]', '', str(value))[:32]


def clean_email(value: Any) -> str:
    if not value:
        return ''
    s = str(value).strip().lower()[:128]
    if re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', s):
        return s
    return ''


def safe_float(
    value: Any,
    default: float = 0.0,
    min_val: float | None = None,
    max_val: float | None = None,
) -> float:
    try:
        f = float(value if value not in (None, '') else default)
    except (TypeError, ValueError):
        return default
    if min_val is not None and f < min_val:
        return default
    if max_val is not None and f > max_val:
        return default
    return f


def safe_int(
    value: Any,
    default: int = 0,
    min_val: int | None = None,
    max_val: int | None = None,
) -> int:
    try:
        i = int(value if value not in (None, '') else default)
    except (TypeError, ValueError):
        return default
    if min_val is not None and i < min_val:
        return default
    if max_val is not None and i > max_val:
        return default
    return i


def csv_safe(value: Any) -> str:
    """Neutralize CSV formula injection (=, +, -, @, tab, CR)."""
    if value is None:
        return ''
    s = str(value)
    if s and s[0] in ('=', '+', '-', '@', '\t', '\r'):
        return "'" + s
    return s


def paginate(
    total: int,
    page: int,
    per_page: int,
) -> dict[str, Any]:
    """Return pagination metadata."""
    from config import Config
    per_page = max(1, min(per_page, Config.PER_PAGE_MAX))
    page = max(1, page)
    pages = max(1, (total + per_page - 1) // per_page)
    if page > pages:
        page = pages
    offset = (page - 1) * per_page
    return {
        'page': page,
        'per_page': per_page,
        'total': total,
        'pages': pages,
        'offset': offset,
        'has_prev': page > 1,
        'has_next': page < pages,
        'prev_page': page - 1 if page > 1 else None,
        'next_page': page + 1 if page < pages else None,
    }
