"""Application configuration.

Supports named configs for create_app(config_name):
  development | testing | production
"""
from __future__ import annotations

import os
from datetime import timedelta


BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class BaseConfig:
    SECRET_KEY_FILE = os.path.join(BASE_DIR, '.secret_key')
    DATABASE = os.path.join(BASE_DIR, 'atelier.db')
    STATIC_DIR = os.path.join(BASE_DIR, 'static')
    TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')
    BACKUPS_DIR = os.path.join(BASE_DIR, 'backups')

    # Session
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    PERMANENT_SESSION_LIFETIME_SECONDS = int(PERMANENT_SESSION_LIFETIME.total_seconds())

    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'

    # CSRF
    WTF_CSRF_TIME_LIMIT = 8 * 60 * 60
    WTF_CSRF_ENABLED = True
    WTF_CSRF_CHECK_DEFAULT = True

    # Request limits
    MAX_CONTENT_LENGTH = 1024 * 1024  # 1 MB
    LOGIN_LIMIT = '10 per minute'
    API_LIMIT = '60 per minute'
    DEFAULT_LIMIT = '300 per minute'

    # Rate-limiter storage: prefer Redis in production
    # Override with RATELIMIT_STORAGE_URI env
    RATELIMIT_STORAGE_URI = os.environ.get('RATELIMIT_STORAGE_URI', 'memory://')

    # Password policy
    PASSWORD_MIN_LENGTH = 12
    PASSWORD_REQUIRE_DIGIT = True
    PASSWORD_REQUIRE_LETTER = True

    # Pagination
    PER_PAGE_DEFAULT = 25
    PER_PAGE_MAX = 100

    # Domain constants
    ORDER_STATUSES = ['принят', 'в работе', 'на примерке', 'готов', 'выдан', 'отменён']
    WORK_TYPES = ['пошив', 'ремонт', 'подгонка']
    ROLES = ['admin', 'receptionist', 'worker', 'director']

    ROLE_ORDERS_VIEW = ('admin', 'receptionist', 'worker', 'director')
    ROLE_ORDERS_STATUS = ('admin', 'receptionist', 'worker')
    ROLE_CLIENTS_VIEW = ('admin', 'receptionist', 'director')
    ROLE_DASHBOARD = ('admin', 'receptionist', 'worker', 'director')
    ROLE_PAYMENTS_VIEW = ('admin', 'receptionist', 'director')
    ROLE_API_CLIENTS = ('admin', 'receptionist')

    # Logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOG_FORMAT = '%(asctime)s [%(levelname)s] %(name)s: %(message)s'

    TESTING = False
    IS_DEV = False


class DevelopmentConfig(BaseConfig):
    IS_DEV = True
    SESSION_COOKIE_SECURE = False
    WTF_CSRF_SSL_STRICT = False
    PREFERRED_URL_SCHEME = 'http'
    LOG_LEVEL = 'DEBUG'
    PASSWORD_MIN_LENGTH = 8


class TestingConfig(BaseConfig):
    TESTING = True
    IS_DEV = True
    SESSION_COOKIE_SECURE = False
    WTF_CSRF_SSL_STRICT = False
    WTF_CSRF_ENABLED = False
    PREFERRED_URL_SCHEME = 'http'
    DATABASE = os.environ.get('TEST_DATABASE', '/tmp/atelier_test.db')
    RATELIMIT_STORAGE_URI = 'memory://'
    PASSWORD_MIN_LENGTH = 8
    LOG_LEVEL = 'WARNING'


class ProductionConfig(BaseConfig):
    IS_DEV = False
    SESSION_COOKIE_SECURE = True
    WTF_CSRF_SSL_STRICT = True
    PREFERRED_URL_SCHEME = 'https'
    RATELIMIT_STORAGE_URI = os.environ.get(
        'RATELIMIT_STORAGE_URI',
        'redis://localhost:6379/0',
    )


CONFIG_MAP = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig,
}


def get_config(name: str | None = None) -> type[BaseConfig]:
    """Resolve config class by name or FLASK_ENV."""
    if name is None:
        env = os.environ.get('FLASK_ENV', 'development').lower()
        if env == 'production':
            name = 'production'
        elif env == 'testing':
            name = 'testing'
        else:
            name = 'development'
    return CONFIG_MAP.get(name, DevelopmentConfig)


# Backwards-compatible module-level Config used by existing imports
Config = get_config()
