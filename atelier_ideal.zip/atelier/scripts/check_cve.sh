#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v pip-audit &>/dev/null; then
  pip install pip-audit
fi
pip-audit -r requirements.lock
