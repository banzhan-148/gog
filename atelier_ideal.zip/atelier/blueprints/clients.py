"""Clients blueprint — list (paginated), create, edit, detail, measurements."""
from __future__ import annotations

import json
import logging
from datetime import datetime, date

from flask import (Blueprint, render_template, request, redirect,
                   url_for, flash, abort)

from config import Config
from db import q, execute
from utils import (login_required, role_required,
                   clean_text, clean_phone, clean_email,
                   log_action, safe_int, paginate)
from services.clients import ClientService

logger = logging.getLogger(__name__)
bp = Blueprint('clients', __name__, url_prefix='/clients')


@bp.route('/')
@login_required
@role_required(*Config.ROLE_CLIENTS_VIEW)
def index():
    term = clean_text(request.args.get('q', ''), 100)
    page = safe_int(request.args.get('page'), 1, min_val=1)
    per_page = safe_int(
        request.args.get('per_page'),
        Config.PER_PAGE_DEFAULT,
        min_val=1,
        max_val=Config.PER_PAGE_MAX,
    )

    if term:
        like = f'%{term}%'
        total = q(
            """SELECT COUNT(*) c FROM clients WHERE is_deleted=0
               AND (full_name LIKE ? OR phone LIKE ?)""",
            (like, like), one=True,
        )['c']
        meta = paginate(total, page, per_page)
        rows = q(
            """SELECT * FROM clients WHERE is_deleted=0
               AND (full_name LIKE ? OR phone LIKE ?)
               ORDER BY full_name LIMIT ? OFFSET ?""",
            (like, like, meta['per_page'], meta['offset']),
        )
    else:
        total = q(
            'SELECT COUNT(*) c FROM clients WHERE is_deleted=0', one=True,
        )['c']
        meta = paginate(total, page, per_page)
        rows = q(
            'SELECT * FROM clients WHERE is_deleted=0 '
            'ORDER BY full_name LIMIT ? OFFSET ?',
            (meta['per_page'], meta['offset']),
        )
    return render_template('clients.html', clients=rows, q=term, pagination=meta)


@bp.route('/new', methods=['POST'])
@login_required
@role_required('admin', 'receptionist')
def new():
    try:
        full_name = clean_text(request.form.get('full_name'), 128)
        phone = clean_phone(request.form.get('phone'))
        email = clean_email(request.form.get('email'))
        birth = clean_text(request.form.get('birth_date'), 20)

        birth_date = None
        if birth:
            try:
                birth_date = datetime.strptime(birth, '%Y-%m-%d').date().isoformat()
            except ValueError:
                birth_date = None

        cid = ClientService.create(full_name, phone, email, birth_date)
        log_action(f'Создан клиент: {full_name}', 'client', cid)
        flash('Клиент добавлен', 'success')
        return redirect(url_for('clients.detail', cid=cid))
    except ValueError as e:
        msg = str(e)
        if msg.startswith('duplicate:'):
            dup_id = msg.split(':')[1]
            flash(f'Клиент с такими данными уже есть (ID={dup_id})', 'warning')
            return redirect(url_for('clients.detail', cid=int(dup_id)))
        if msg == 'full_name_required':
            flash('ФИО обязательно', 'error')
        else:
            flash(msg, 'error')
        return redirect(url_for('clients.index'))
    except Exception:
        logger.exception('Client create failed')
        flash('Ошибка при создании клиента', 'error')
        return redirect(url_for('clients.index'))


@bp.route('/<int:cid>')
@login_required
@role_required(*Config.ROLE_CLIENTS_VIEW)
def detail(cid):
    c = q('SELECT * FROM clients WHERE id=? AND is_deleted=0', (cid,), one=True)
    if not c:
        abort(404)
    orders = q(
        """SELECT o.*, w.full_name AS worker_name
           FROM orders o LEFT JOIN workers w ON w.id=o.worker_id
           WHERE o.client_id=? AND o.is_deleted=0
           ORDER BY o.created_at DESC""",
        (cid,),
    )
    measurements = q(
        'SELECT * FROM measurements WHERE client_id=? ORDER BY taken_at DESC',
        (cid,),
    )
    for m in measurements:
        try:
            m['data'] = json.loads(m['data_json'])
        except Exception:
            m['data'] = {}
    return render_template(
        'client_detail.html', client=c, orders=orders, measurements=measurements,
    )


@bp.route('/<int:cid>/edit', methods=['POST'])
@login_required
@role_required('admin', 'receptionist')
def edit(cid):
    try:
        full_name = clean_text(request.form.get('full_name'), 128)
        phone = clean_phone(request.form.get('phone'))
        email = clean_email(request.form.get('email'))
        birth = clean_text(request.form.get('birth_date'), 20)
        birth_date = None
        if birth:
            try:
                birth_date = datetime.strptime(birth, '%Y-%m-%d').date().isoformat()
            except ValueError:
                birth_date = None
        ClientService.update(
            cid, full_name=full_name, phone=phone, email=email, birth_date=birth_date,
        )
        log_action(f'Редактирование клиента: {full_name}', 'client', cid)
        flash('Клиент обновлён', 'success')
    except ValueError as e:
        flash({'full_name_required': 'ФИО обязательно',
               'client_not_found': 'Клиент не найден'}.get(str(e), str(e)), 'error')
    return redirect(url_for('clients.detail', cid=cid))


@bp.route('/<int:cid>/delete', methods=['POST'])
@login_required
@role_required('admin')
def delete(cid):
    c = q('SELECT * FROM clients WHERE id=? AND is_deleted=0', (cid,), one=True)
    if not c:
        abort(404)
    ClientService.soft_delete(cid)
    log_action(f'Удалён клиент: {c["full_name"]}', 'client', cid)
    flash('Клиент удалён', 'success')
    return redirect(url_for('clients.index'))


@bp.route('/<int:cid>/measurements', methods=['POST'])
@login_required
@role_required('admin', 'receptionist')
def measurement_add(cid):
    raw = (request.form.get('data_json') or '').strip()
    if len(raw) > 5000:
        flash('Слишком большой JSON мерок', 'error')
        return redirect(url_for('clients.detail', cid=cid))
    try:
        parsed = json.loads(raw)
        if not isinstance(parsed, dict):
            raise ValueError('Должен быть объект')
    except Exception:
        flash('Некорректный JSON (пример: {"рост":170,"обхват_груди":96})', 'error')
        return redirect(url_for('clients.detail', cid=cid))
    execute(
        'INSERT INTO measurements (client_id, taken_at, data_json, note) '
        'VALUES (?, ?, ?, ?)',
        (cid, date.today().isoformat(),
         json.dumps(parsed, ensure_ascii=False),
         clean_text(request.form.get('note'), 255)),
    )
    log_action('Добавлены мерки', 'client', cid)
    flash('Мерки сохранены', 'success')
    return redirect(url_for('clients.detail', cid=cid))
