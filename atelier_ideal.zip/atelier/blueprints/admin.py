"""Admin: users, password reset, backup, audit log."""
from __future__ import annotations

import logging
import os
import re
import shutil
from datetime import datetime, timezone

from flask import Blueprint, render_template, request, redirect, url_for, flash

from config import Config
from db import q, execute
from utils import login_required, role_required, clean_text, log_action, safe_int, paginate
from services.users import UserService

logger = logging.getLogger(__name__)
bp = Blueprint('admin', __name__, url_prefix='/admin')


@bp.route('/')
@login_required
@role_required('admin')
def index():
    users = q('SELECT * FROM users ORDER BY username')
    page = safe_int(request.args.get('page'), 1, min_val=1)
    total = q('SELECT COUNT(*) c FROM audit_log', one=True)['c']
    meta = paginate(total, page, Config.PER_PAGE_DEFAULT)
    logs = q(
        """SELECT l.*, u.username FROM audit_log l
           LEFT JOIN users u ON u.id=l.user_id
           ORDER BY l.created_at DESC LIMIT ? OFFSET ?""",
        (meta['per_page'], meta['offset']),
    )
    return render_template('admin.html', users=users, logs=logs, pagination=meta)


@bp.route('/users/new', methods=['POST'])
@login_required
@role_required('admin')
def user_new():
    username = clean_text(request.form.get('username'), 64)
    full_name = clean_text(request.form.get('full_name'), 128)
    password = request.form.get('password') or ''
    role = clean_text(request.form.get('role'), 32)

    if not username or len(username) < 3:
        flash('Логин должен содержать минимум 3 символа', 'error')
        return redirect(url_for('admin.index'))
    if not re.match(r'^[a-zA-Z0-9_.\-]+$', username):
        flash('Логин: только латиница, цифры, _ . -', 'error')
        return redirect(url_for('admin.index'))
    if not full_name:
        flash('ФИО обязательно', 'error')
        return redirect(url_for('admin.index'))
    if role not in Config.ROLES:
        flash('Некорректная роль', 'error')
        return redirect(url_for('admin.index'))

    try:
        uid = UserService.create(username, full_name, password, role)
        log_action(f'Создан пользователь {username} ({role})', 'user', uid)
        flash('Пользователь создан', 'success')
    except ValueError as e:
        flash(str(e) if not str(e).startswith('username') else
              'Пользователь с таким логином уже существует', 'error')
    return redirect(url_for('admin.index'))


@bp.route('/users/<int:uid>/toggle', methods=['POST'])
@login_required
@role_required('admin')
def user_toggle(uid):
    u = q('SELECT * FROM users WHERE id=?', (uid,), one=True)
    if u and u['username'] != 'admin':
        execute(
            'UPDATE users SET is_active=? WHERE id=?',
            (0 if u['is_active'] else 1, uid),
        )
        log_action(f'Изменена активность {u["username"]}', 'user', uid)
        flash('Статус пользователя изменён', 'success')
    else:
        flash('Нельзя заблокировать главного администратора', 'warning')
    return redirect(url_for('admin.index'))


@bp.route('/users/<int:uid>/reset', methods=['POST'])
@login_required
@role_required('admin')
def user_reset(uid):
    password = request.form.get('password') or ''
    try:
        UserService.reset_password(uid, password)
        u = q('SELECT username FROM users WHERE id=?', (uid,), one=True)
        log_action(f'Сброс пароля {u["username"] if u else uid}', 'user', uid)
        flash('Пароль изменён', 'success')
    except ValueError as e:
        flash(str(e), 'error')
    return redirect(url_for('admin.index'))


@bp.route('/backup', methods=['POST'])
@login_required
@role_required('admin')
def backup():
    os.makedirs(Config.BACKUPS_DIR, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    dst = os.path.join(Config.BACKUPS_DIR, f'atelier_{stamp}.db')
    shutil.copy2(Config.DATABASE, dst)
    log_action(f'Резервная копия: {os.path.basename(dst)}', 'system', None)
    flash(f'Резервная копия создана: {os.path.basename(dst)}', 'success')
    return redirect(url_for('admin.index'))
