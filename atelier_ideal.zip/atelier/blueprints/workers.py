"""Workers (исполнители) blueprint — list, create, edit, toggle."""
from __future__ import annotations

import logging

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort

from db import q, execute
from utils import (login_required, role_required, clean_text, safe_float,
                   log_action, safe_int, paginate)
from config import Config

logger = logging.getLogger(__name__)
bp = Blueprint('workers', __name__, url_prefix='/workers')


@bp.route('/')
@login_required
def index():
    page = safe_int(request.args.get('page'), 1, min_val=1)
    per_page = safe_int(
        request.args.get('per_page'),
        Config.PER_PAGE_DEFAULT,
        min_val=1,
        max_val=Config.PER_PAGE_MAX,
    )
    total = q('SELECT COUNT(*) c FROM workers', one=True)['c']
    meta = paginate(total, page, per_page)
    items = q(
        'SELECT * FROM workers ORDER BY full_name LIMIT ? OFFSET ?',
        (meta['per_page'], meta['offset']),
    )
    for w in items:
        cnt = q(
            "SELECT COUNT(*) c FROM orders WHERE worker_id=? "
            "AND is_deleted=0 AND status NOT IN ('выдан','отменён')",
            (w['id'],), one=True,
        )['c']
        w['load'] = cnt
    return render_template('workers.html', workers=items, pagination=meta)


@bp.route('/new', methods=['POST'])
@login_required
@role_required('admin')
def new():
    full_name = clean_text(request.form.get('full_name'), 128)
    if not full_name:
        flash('ФИО обязательно', 'error')
        return redirect(url_for('workers.index'))
    wid = execute(
        'INSERT INTO workers (full_name, specialization, rate) VALUES (?, ?, ?)',
        (full_name,
         clean_text(request.form.get('specialization', ''), 64),
         safe_float(request.form.get('rate'), 0, min_val=0, max_val=10_000_000)),
    )
    log_action('Создан исполнитель', 'worker', wid)
    flash('Исполнитель добавлен', 'success')
    return redirect(url_for('workers.index'))


@bp.route('/<int:wid>/edit', methods=['POST'])
@login_required
@role_required('admin')
def edit(wid):
    w = q('SELECT * FROM workers WHERE id=?', (wid,), one=True)
    if not w:
        abort(404)
    full_name = clean_text(request.form.get('full_name'), 128)
    if not full_name:
        flash('ФИО обязательно', 'error')
        return redirect(url_for('workers.index'))
    execute(
        'UPDATE workers SET full_name=?, specialization=?, rate=? WHERE id=?',
        (full_name,
         clean_text(request.form.get('specialization', ''), 64),
         safe_float(request.form.get('rate'), 0, min_val=0, max_val=10_000_000),
         wid),
    )
    log_action(f'Редактирование исполнителя {full_name}', 'worker', wid)
    flash('Исполнитель обновлён', 'success')
    return redirect(url_for('workers.index'))


@bp.route('/<int:wid>/toggle', methods=['POST'])
@login_required
@role_required('admin')
def toggle(wid):
    w = q('SELECT * FROM workers WHERE id=?', (wid,), one=True)
    if not w:
        abort(404)
    new_active = 0 if w['is_active'] else 1
    execute('UPDATE workers SET is_active=? WHERE id=?', (new_active, wid))
    log_action(
        f'{"Активирован" if new_active else "Деактивирован"} исполнитель {w["full_name"]}',
        'worker', wid,
    )
    flash('Статус исполнителя изменён', 'success')
    return redirect(url_for('workers.index'))
