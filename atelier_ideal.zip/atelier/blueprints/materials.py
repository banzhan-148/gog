"""Materials blueprint — list, create, edit, stock adjust."""
from __future__ import annotations

import logging

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort

from config import Config
from db import q, execute
from utils import (login_required, role_required, clean_text, safe_float,
                   log_action, safe_int, paginate)
from services.materials import MaterialService

logger = logging.getLogger(__name__)
bp = Blueprint('materials', __name__, url_prefix='/materials')


@bp.route('/')
@login_required
def index():
    page = safe_int(request.args.get('page'), 1, min_val=1)
    per_page = safe_int(
        request.args.get('per_page'),
        Config.PER_PAGE_DEFAULT,
        min_val=1,
        max_val=Config.PER_PAGE_MAX,
    )
    total = q('SELECT COUNT(*) c FROM materials', one=True)['c']
    meta = paginate(total, page, per_page)
    items = q(
        'SELECT * FROM materials ORDER BY name LIMIT ? OFFSET ?',
        (meta['per_page'], meta['offset']),
    )
    return render_template('materials.html', materials=items, pagination=meta)


@bp.route('/new', methods=['POST'])
@login_required
@role_required('admin')
def new():
    name = clean_text(request.form.get('name'), 128)
    if not name:
        flash('Название материала обязательно', 'error')
        return redirect(url_for('materials.index'))
    mid = execute(
        'INSERT INTO materials (name, kind, unit, stock, min_stock, price) '
        'VALUES (?, ?, ?, ?, ?, ?)',
        (name,
         clean_text(request.form.get('kind', ''), 64),
         clean_text(request.form.get('unit', 'м'), 16),
         safe_float(request.form.get('stock'), 0, min_val=0, max_val=1_000_000),
         safe_float(request.form.get('min_stock'), 0, min_val=0, max_val=1_000_000),
         safe_float(request.form.get('price'), 0, min_val=0, max_val=100_000_000)),
    )
    log_action('Создан материал', 'material', mid)
    flash('Материал добавлен', 'success')
    return redirect(url_for('materials.index'))


@bp.route('/<int:mid>/edit', methods=['POST'])
@login_required
@role_required('admin')
def edit(mid):
    m = q('SELECT * FROM materials WHERE id=?', (mid,), one=True)
    if not m:
        abort(404)
    name = clean_text(request.form.get('name'), 128)
    if not name:
        flash('Название обязательно', 'error')
        return redirect(url_for('materials.index'))
    execute(
        'UPDATE materials SET name=?, kind=?, unit=?, min_stock=?, price=? WHERE id=?',
        (name,
         clean_text(request.form.get('kind', ''), 64),
         clean_text(request.form.get('unit', 'м'), 16),
         safe_float(request.form.get('min_stock'), 0, min_val=0, max_val=1_000_000),
         safe_float(request.form.get('price'), 0, min_val=0, max_val=100_000_000),
         mid),
    )
    log_action(f'Редактирование материала {name}', 'material', mid)
    flash('Материал обновлён', 'success')
    return redirect(url_for('materials.index'))


@bp.route('/<int:mid>/stock', methods=['POST'])
@login_required
@role_required('admin', 'receptionist')
def stock(mid):
    delta = safe_float(
        request.form.get('delta'), 0, min_val=-1_000_000, max_val=1_000_000,
    )
    if delta == 0:
        flash('Введите ненулевое значение', 'error')
        return redirect(url_for('materials.index'))
    try:
        new_stock = MaterialService.adjust_stock(mid, delta)
        m = q('SELECT name FROM materials WHERE id=?', (mid,), one=True)
        log_action(f'Поступление/корректировка {m["name"]}: {delta}', 'material', mid)
        flash(f'Остаток обновлён: {new_stock}', 'success')
    except ValueError as e:
        flash({
            'material_not_found': 'Материал не найден',
            'negative_stock': 'Остаток не может быть отрицательным',
        }.get(str(e), str(e)), 'error')
    return redirect(url_for('materials.index'))
