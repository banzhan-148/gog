"""Orders blueprint — list (paginated), create, detail, status, payment, writeoff."""
from __future__ import annotations

import logging
from datetime import datetime, timezone

from flask import (Blueprint, render_template, request, redirect,
                   url_for, flash, abort)

from config import Config
from db import q
from utils import (login_required, role_required, has_role,
                   clean_text, safe_float, safe_int, log_action,
                   current_user, paginate)
from services.orders import OrderService
from services.payments import PaymentService
from services.materials import MaterialService

logger = logging.getLogger(__name__)
bp = Blueprint('orders', __name__, url_prefix='/orders')


def _order_with_extra(o: dict) -> dict:
    o['debt'] = round((o['total'] or 0) - (o['paid'] or 0), 2)
    return o


@bp.route('/')
@login_required
@role_required(*Config.ROLE_ORDERS_VIEW)
def index():
    status = clean_text(request.args.get('status', ''), 32)
    term = clean_text(request.args.get('q', ''), 100)
    page = safe_int(request.args.get('page'), 1, min_val=1)
    per_page = safe_int(
        request.args.get('per_page'),
        Config.PER_PAGE_DEFAULT,
        min_val=1,
        max_val=Config.PER_PAGE_MAX,
    )

    where = 'o.is_deleted = 0'
    params: list = []
    if status:
        where += ' AND o.status = ?'
        params.append(status)
    if term:
        where += ' AND (o.number LIKE ? OR c.full_name LIKE ? OR c.phone LIKE ?)'
        like = f'%{term}%'
        params += [like, like, like]

    total_row = q(
        f"""SELECT COUNT(*) AS c FROM orders o
            LEFT JOIN clients c ON c.id = o.client_id
            WHERE {where}""",
        tuple(params),
        one=True,
    )
    total = total_row['c'] if total_row else 0
    meta = paginate(total, page, per_page)

    sql = f"""SELECT o.*, c.full_name AS client_name, w.full_name AS worker_name
              FROM orders o
              LEFT JOIN clients c ON c.id = o.client_id
              LEFT JOIN workers w ON w.id = o.worker_id
              WHERE {where}
              ORDER BY o.created_at DESC
              LIMIT ? OFFSET ?"""
    rows = q(sql, tuple(params) + (meta['per_page'], meta['offset']))
    for o in rows:
        _order_with_extra(o)
    return render_template(
        'orders.html',
        orders=rows,
        cur_status=status,
        q=term,
        pagination=meta,
    )


@bp.route('/new', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'receptionist')
def new():
    if request.method == 'POST':
        try:
            client_id = safe_int(request.form.get('client_id'), 0, min_val=1)
            if not client_id or not q(
                'SELECT id FROM clients WHERE id=? AND is_deleted=0',
                (client_id,), one=True,
            ):
                flash('Клиент не найден', 'error')
                return redirect(url_for('orders.new'))

            worker_id = request.form.get('worker_id') or None
            if worker_id:
                worker_id = safe_int(worker_id, 0, min_val=1) or None
                if worker_id and not q(
                    'SELECT id FROM workers WHERE id=? AND is_active=1',
                    (worker_id,), one=True,
                ):
                    worker_id = None

            work_type = clean_text(request.form.get('work_type', ''), 32)
            description = clean_text(request.form.get('description'), 1000)
            due_date_raw = clean_text(request.form.get('due_date'), 20)

            names = request.form.getlist('item_name[]')
            qtys = request.form.getlist('item_qty[]')
            prices = request.form.getlist('item_price[]')
            items = []
            for n, qq, p in zip(names, qtys, prices):
                name = clean_text(n, 128)
                if not name:
                    continue
                qq = safe_int(qq, 1, min_val=1, max_val=10000)
                p = safe_float(p, 0, min_val=0, max_val=10_000_000)
                items.append((name, qq, p))

            due_date = None
            if due_date_raw:
                try:
                    due_date = datetime.strptime(due_date_raw, '%Y-%m-%d').date().isoformat()
                except ValueError:
                    due_date = None

            oid = OrderService.create(
                client_id=client_id,
                worker_id=worker_id,
                work_type=work_type,
                description=description,
                due_date=due_date,
                items=items,
                created_by=current_user()['id'],
            )
            number = q('SELECT number FROM orders WHERE id=?', (oid,), one=True)['number']
            log_action(f'Создан заказ {number}', 'order', oid)
            flash(f'Заказ {number} создан', 'success')
            return redirect(url_for('orders.detail', oid=oid))
        except Exception:
            logger.exception('Order create failed')
            flash('Ошибка создания заказа', 'error')
            return redirect(url_for('orders.new'))

    clients_list = q('SELECT * FROM clients WHERE is_deleted=0 ORDER BY full_name')
    workers_list = q('SELECT * FROM workers WHERE is_active=1 ORDER BY full_name')
    materials_list = q('SELECT * FROM materials ORDER BY name')
    return render_template(
        'order_new.html',
        clients=clients_list,
        workers=workers_list,
        materials=materials_list,
        selected_client=request.args.get('client_id', ''),
    )


@bp.route('/<int:oid>')
@login_required
@role_required(*Config.ROLE_ORDERS_VIEW)
def detail(oid):
    o = q(
        """SELECT o.*, c.full_name AS client_name, c.phone AS client_phone,
                  w.full_name AS worker_name
           FROM orders o
           LEFT JOIN clients c ON c.id=o.client_id
           LEFT JOIN workers w ON w.id=o.worker_id
           WHERE o.id=? AND o.is_deleted=0""",
        (oid,), one=True,
    )
    if not o:
        abort(404)
    _order_with_extra(o)
    o['items'] = q('SELECT * FROM order_items WHERE order_id=?', (oid,))
    o['payments'] = q(
        'SELECT * FROM payments WHERE order_id=? ORDER BY created_at DESC', (oid,),
    )
    o['writeoffs'] = q(
        """SELECT mw.*, m.name AS material_name, m.unit AS unit
           FROM material_writeoffs mw
           LEFT JOIN materials m ON m.id=mw.material_id
           WHERE mw.order_id=? ORDER BY mw.created_at DESC""",
        (oid,),
    )
    materials_list = q('SELECT * FROM materials ORDER BY name')
    workers_list = q('SELECT * FROM workers WHERE is_active=1 ORDER BY full_name')
    return render_template(
        'order_detail.html',
        order=o,
        materials=materials_list,
        workers=workers_list,
    )


@bp.route('/<int:oid>/edit', methods=['POST'])
@login_required
@role_required('admin', 'receptionist')
def edit(oid):
    o = q('SELECT * FROM orders WHERE id=? AND is_deleted=0', (oid,), one=True)
    if not o:
        abort(404)
    description = clean_text(request.form.get('description'), 1000)
    worker_id = request.form.get('worker_id') or None
    if worker_id:
        worker_id = safe_int(worker_id, 0, min_val=1) or None
    due_date_raw = clean_text(request.form.get('due_date'), 20)
    due_date = None
    if due_date_raw:
        try:
            due_date = datetime.strptime(due_date_raw, '%Y-%m-%d').date().isoformat()
        except ValueError:
            due_date = o.get('due_date')
    from db import execute
    execute(
        'UPDATE orders SET description=?, worker_id=?, due_date=? WHERE id=?',
        (description, worker_id, due_date, oid),
    )
    log_action(f'Редактирование заказа {o["number"]}', 'order', oid)
    flash('Заказ обновлён', 'success')
    return redirect(url_for('orders.detail', oid=oid))


@bp.route('/<int:oid>/status', methods=['POST'])
@login_required
@role_required(*Config.ROLE_ORDERS_STATUS)
def status(oid):
    new_status = clean_text(request.form.get('status', ''), 32)
    try:
        o = OrderService.update_status(
            oid,
            new_status,
            allow_unpaid_issue=has_role('admin', 'director'),
        )
        log_action(
            f'Статус заказа {o["number"]}: {o["status"]} -> {new_status}',
            'order', oid,
        )
        flash('Статус обновлён', 'success')
    except ValueError as e:
        msg = {
            'order_not_found': 'Заказ не найден',
            'invalid_status': 'Некорректный статус',
            'unpaid_issue_forbidden': 'Нельзя выдать заказ без полной оплаты',
        }.get(str(e), str(e))
        flash(msg, 'error')
    return redirect(url_for('orders.detail', oid=oid))


@bp.route('/<int:oid>/payment', methods=['POST'])
@login_required
@role_required('admin', 'receptionist')
def payment(oid):
    amount = safe_float(request.form.get('amount'), 0, min_val=0.01, max_val=10_000_000)
    method = clean_text(request.form.get('method', 'наличные'), 32)
    kind = clean_text(request.form.get('kind', 'доплата'), 32)
    try:
        o = PaymentService.add_payment(oid, amount, method, kind)
        log_action(f'Оплата по заказу {o["number"]}: {amount} руб.', 'order', oid)
        flash('Платёж добавлен', 'success')
    except ValueError as e:
        msg = {
            'order_not_found': 'Заказ не найден',
            'invalid_amount': 'Сумма должна быть от 0.01 до 10 000 000',
        }.get(str(e), str(e))
        flash(msg, 'error')
    return redirect(url_for('orders.detail', oid=oid))


@bp.route('/<int:oid>/writeoff', methods=['POST'])
@login_required
@role_required('admin', 'receptionist', 'worker')
def writeoff(oid):
    mid = safe_int(request.form.get('material_id'), 0, min_val=1)
    qty = safe_float(request.form.get('qty'), 0, min_val=0.001, max_val=1_000_000)
    try:
        m = MaterialService.writeoff(oid, mid, qty)
        o = q('SELECT number FROM orders WHERE id=?', (oid,), one=True)
        log_action(
            f'Списание материала {m["name"]}: {qty} {m["unit"]} по заказу {o["number"]}',
            'order', oid,
        )
        flash('Материал списан', 'success')
    except ValueError as e:
        msg = {
            'order_not_found': 'Заказ не найден',
            'material_not_found': 'Материал не найден',
            'invalid_qty': 'Некорректное количество',
            'insufficient_stock': 'Недостаточно остатка на складе',
        }.get(str(e), str(e))
        flash(msg, 'error')
    return redirect(url_for('orders.detail', oid=oid))


@bp.route('/<int:oid>/debt', methods=['POST'])
@login_required
@role_required('admin', 'director')
def debt(oid):
    o = q('SELECT * FROM orders WHERE id=? AND is_deleted=0', (oid,), one=True)
    if not o:
        abort(404)
    is_debt = request.form.get('is_debt') == '1'
    OrderService.set_debt(oid, is_debt)
    log_action(
        f'Флаг долга заказа {o["number"]}: {"вкл" if is_debt else "выкл"}',
        'order', oid,
    )
    flash('Флаг долга обновлён', 'success')
    return redirect(url_for('orders.detail', oid=oid))


@bp.route('/<int:oid>/delete', methods=['POST'])
@login_required
@role_required('admin')
def delete(oid):
    o = q('SELECT * FROM orders WHERE id=? AND is_deleted=0', (oid,), one=True)
    if not o:
        abort(404)
    OrderService.soft_delete(oid)
    log_action(f'Удалён заказ {o["number"]}', 'order', oid)
    flash('Заказ удалён', 'success')
    return redirect(url_for('orders.index'))
