"""Secret key management and Talisman security headers."""
from __future__ import annotations

import logging
import os
import secrets
from typing import TYPE_CHECKING

from flask_talisman import Talisman

if TYPE_CHECKING:
    from flask import Flask

logger = logging.getLogger(__name__)


def load_secret_key(cfg=None) -> str:
    """Return SECRET_KEY: env → file → new."""
    from config import Config
    cfg = cfg or Config
    key = os.environ.get('FLASK_SECRET_KEY')
    if key:
        return key
    if os.path.exists(cfg.SECRET_KEY_FILE):
        try:
            with open(cfg.SECRET_KEY_FILE, 'r', encoding='utf-8') as f:
                saved = f.read().strip()
                if saved:
                    return saved
        except OSError as exc:
            logger.warning('Could not read secret key file: %s', exc)
    key = secrets.token_hex(32)
    try:
        with open(cfg.SECRET_KEY_FILE, 'w', encoding='utf-8') as f:
            f.write(key)
        try:
            os.chmod(cfg.SECRET_KEY_FILE, 0o600)
        except OSError:
            pass
    except OSError as exc:
        logger.warning('Could not write secret key file: %s', exc)
    return key


def init_talisman(app: 'Flask', cfg=None) -> None:
    """Security headers. No 'unsafe-inline' for scripts — external JS only."""
    from config import Config
    cfg = cfg or Config
    csp = {
        'default-src': "'self'",
        'script-src': "'self'",
        'style-src': "'self'",
        'img-src': "'self' data:",
        'font-src': "'self'",
        'connect-src': "'self'",
        'frame-ancestors': "'none'",
        'base-uri': "'self'",
        'form-action': "'self'",
        'object-src': "'none'",
    }
    Talisman(
        app,
        force_https=not cfg.IS_DEV,
        force_https_permanent=True,
        strict_transport_security=not cfg.IS_DEV,
        strict_transport_security_max_age=31536000,
        strict_transport_security_include_subdomains=True,
        strict_transport_security_preload=True,
        content_security_policy=csp,
        content_security_policy_report_only=False,
        frame_options='DENY',
        frame_options_allow_from=None,
        x_content_type_options=True,
        x_xss_protection=True,
        referrer_policy='strict-origin-when-cross-origin',
        session_cookie_secure=not cfg.IS_DEV,
        session_cookie_http_only=True,
        session_cookie_samesite='Lax',
    )
