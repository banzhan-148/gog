# Деплой АИС «Ателье»

## 1. Сервер

- Ubuntu 22.04+ / Debian 12
- Python 3.12 или 3.13
- Redis (для rate-limiter)
- nginx или Caddy
- systemd

## 2. Установка

```bash
sudo useradd -r -m -d /opt/atelier atelier
sudo -u atelier -i
cd /opt/atelier
git clone <repo> app && cd app
python3.12 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install gunicorn
```

## 3. Окружение

```bash
# /opt/atelier/app/.env (не коммитить)
FLASK_ENV=production
FLASK_SECRET_KEY=<openssl rand -hex 32>
ADMIN_USERNAME=admin
ADMIN_PASSWORD=<min-12-chars>
ADMIN_FULL_NAME=Администратор
RATELIMIT_STORAGE_URI=redis://127.0.0.1:6379/0
LOG_LEVEL=INFO
```

Первый запуск создаст админа из `ADMIN_*`.

## 4. Gunicorn + systemd

```ini
# /etc/systemd/system/atelier.service
[Unit]
Description=Atelier AIS
After=network.target redis.service

[Service]
User=atelier
Group=atelier
WorkingDirectory=/opt/atelier/app
EnvironmentFile=/opt/atelier/app/.env
ExecStart=/opt/atelier/app/.venv/bin/gunicorn \
  -w 2 -b 127.0.0.1:8000 \
  --access-logfile - --error-logfile - \
  "run:create_app()"
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now atelier
```

> Примечание: factory вызывается как `"run:create_app()"` — Gunicorn поддерживает callable.

Альтернатива: `run:app` если модульный `app = create_app()` уже создан при импорте.

## 5. nginx (фрагмент)

```nginx
server {
    listen 443 ssl http2;
    server_name atelier.example.com;
    # ssl_certificate ...;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

## 6. Бэкапы

```bash
# cron daily
0 3 * * * cp /opt/atelier/app/atelier.db /opt/atelier/backups/atelier_$(date +\%Y\%m\%d).db
```

Или кнопка «Резервная копия» в `/admin`.

## 7. Обновление

```bash
cd /opt/atelier/app
git pull
source .venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart atelier
```

Схема БД: `CREATE TABLE IF NOT EXISTS` — безопасна для повторного `init_db`, но миграции вручную при изменении колонок.
