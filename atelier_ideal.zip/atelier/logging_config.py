"""Centralized logging setup — replaces scattered print() calls."""
from __future__ import annotations

import logging
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flask import Flask


def setup_logging(app: 'Flask') -> None:
    level_name = app.config.get('LOG_LEVEL', 'INFO')
    level = getattr(logging, str(level_name).upper(), logging.INFO)
    fmt = app.config.get(
        'LOG_FORMAT',
        '%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    )

    root = logging.getLogger()
    # Avoid duplicate handlers on reload
    if not root.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(fmt))
        root.addHandler(handler)
    root.setLevel(level)

    # Quiet noisy libs
    logging.getLogger('werkzeug').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)

    app.logger.setLevel(level)
    app.logger.info('Logging configured: level=%s', level_name)
