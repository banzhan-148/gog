"""Order / payment / writeoff integration tests."""
from tests.conftest import login
from db import q
from services.orders import OrderService
from services.payments import PaymentService
from services.materials import MaterialService


def test_create_order(auth_client, app):
    with app.app_context():
        client_row = q('SELECT id FROM clients LIMIT 1', one=True)
        cid = client_row['id']
    rv = auth_client.post('/orders/new', data={
        'client_id': str(cid),
        'work_type': 'пошив',
        'description': 'Тестовый заказ',
        'item_name[]': ['Пиджак'],
        'item_qty[]': ['1'],
        'item_price[]': ['5000'],
    }, follow_redirects=True)
    assert rv.status_code == 200
    with app.app_context():
        o = q("SELECT * FROM orders WHERE description='Тестовый заказ'", one=True)
        assert o is not None
        assert o['total'] == 5000
        assert o['number'].startswith('AT-')


def test_payment_atomic(app):
    with app.app_context():
        oid = OrderService.create(
            client_id=1, worker_id=None, work_type='ремонт',
            description='pay test', due_date=None,
            items=[('item', 1, 1000.0)], created_by=1,
        )
        PaymentService.add_payment(oid, 300.0)
        o = q('SELECT * FROM orders WHERE id=?', (oid,), one=True)
        assert o['paid'] == 300.0
        pays = q('SELECT * FROM payments WHERE order_id=?', (oid,))
        assert len(pays) == 1


def test_writeoff_insufficient(app):
    with app.app_context():
        oid = OrderService.create(
            client_id=1, worker_id=None, work_type='пошив',
            description='wo', due_date=None,
            items=[('x', 1, 10)], created_by=1,
        )
        try:
            MaterialService.writeoff(oid, 1, 9999)
            assert False, 'should raise'
        except ValueError as e:
            assert str(e) == 'insufficient_stock'


def test_status_unpaid_issue_forbidden(app):
    with app.app_context():
        oid = OrderService.create(
            client_id=1, worker_id=None, work_type='пошив',
            description='status', due_date=None,
            items=[('x', 1, 100)], created_by=1,
        )
        try:
            OrderService.update_status(oid, 'выдан', allow_unpaid_issue=False)
            assert False
        except ValueError as e:
            assert str(e) == 'unpaid_issue_forbidden'


def test_orders_list_paginated(auth_client):
    rv = auth_client.get('/orders/?page=1')
    assert rv.status_code == 200
