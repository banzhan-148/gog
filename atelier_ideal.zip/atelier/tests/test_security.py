"""Security-related checks."""
from utils import csv_safe
from services.users import UserService
from config import TestingConfig
import config as config_module


def test_csv_injection_variants():
    for prefix in ('=', '+', '-', '@', '\t', '\r'):
        assert csv_safe(prefix + 'FORMULA').startswith("'")


def test_password_min_length_production_policy():
    # Production policy is stricter; TestingConfig uses 8
    config_module.Config = TestingConfig
    assert UserService.validate_password('abcdefg') is not None  # 7 chars
    assert UserService.validate_password('abcdefgh') is not None  # no digit
    assert UserService.validate_password('abcdefgh1') is None


def test_csrf_token_in_forms(auth_client):
    rv = auth_client.get('/clients/')
    # With WTF_CSRF_ENABLED=False in testing, token may still appear in templates
    assert rv.status_code == 200
