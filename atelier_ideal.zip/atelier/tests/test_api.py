"""API endpoint tests."""
from tests.conftest import login


def test_api_clients_requires_auth(client):
    rv = client.get('/api/clients?q=Ив')
    assert rv.status_code in (302, 401, 403)


def test_api_clients_search(auth_client):
    rv = auth_client.get('/api/clients?q=Ива')
    assert rv.status_code == 200
    data = rv.get_json()
    assert isinstance(data, list)


def test_api_clients_short_query(auth_client):
    rv = auth_client.get('/api/clients?q=a')
    assert rv.status_code == 200
    assert rv.get_json() == []
