"""Validator and sanitizer unit tests."""
from utils import clean_text, clean_phone, clean_email, safe_float, safe_int, csv_safe, paginate
from services.users import UserService
from config import TestingConfig
import config as config_module


def test_clean_text_strips_control():
    assert clean_text('  hello\x00world  ', 20) == 'helloworld'
    assert len(clean_text('x' * 100, 10)) == 10


def test_clean_phone():
    assert clean_phone('+7 (999) 123-45-67') == '+7 (999) 123-45-67'
    assert 'abc' not in clean_phone('abc+7999')


def test_clean_email():
    assert clean_email('Test@Example.COM') == 'test@example.com'
    assert clean_email('not-an-email') == ''


def test_safe_float():
    assert safe_float('12.5') == 12.5
    assert safe_float('bad', 1.0) == 1.0
    assert safe_float('-5', 0, min_val=0) == 0


def test_safe_int():
    assert safe_int('42') == 42
    assert safe_int(None, 7) == 7
    assert safe_int('99', 0, max_val=10) == 0


def test_csv_safe():
    assert csv_safe('=CMD()') == "'=CMD()"
    assert csv_safe('normal') == 'normal'
    assert csv_safe(None) == ''


def test_paginate():
    meta = paginate(100, 2, 25)
    assert meta['page'] == 2
    assert meta['pages'] == 4
    assert meta['offset'] == 25
    assert meta['has_prev'] and meta['has_next']


def test_password_policy(app):
    config_module.Config = TestingConfig
    assert UserService.validate_password('short') is not None
    assert UserService.validate_password('longenough1') is None
