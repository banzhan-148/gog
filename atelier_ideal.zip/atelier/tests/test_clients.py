"""Client service and routes."""
from services.clients import ClientService
from db import q
from tests.conftest import login


def test_client_create_and_update(app):
    with app.app_context():
        cid = ClientService.create('Петров П.П.', '+7111', 'p@ex.com')
        assert cid > 0
        ClientService.update(cid, full_name='Петров Пётр', phone='+7222', email='p2@ex.com')
        c = q('SELECT * FROM clients WHERE id=?', (cid,), one=True)
        assert c['full_name'] == 'Петров Пётр'
        assert c['phone'] == '+7222'


def test_client_duplicate(app):
    with app.app_context():
        ClientService.create('Unique Name', '111')
        try:
            ClientService.create('Unique Name', '111')
            assert False
        except ValueError as e:
            assert str(e).startswith('duplicate:')


def test_clients_list(auth_client):
    rv = auth_client.get('/clients/')
    assert rv.status_code == 200


def test_client_create_via_http(auth_client):
    rv = auth_client.post('/clients/new', data={
        'full_name': 'HTTP Client',
        'phone': '+70001112233',
    }, follow_redirects=True)
    assert rv.status_code == 200
