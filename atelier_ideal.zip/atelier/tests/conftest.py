"""Pytest fixtures for АИС «Ателье»."""
from __future__ import annotations

import os
import sys

import pytest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

os.environ['TEST_DATABASE'] = '/tmp/atelier_test.db'

from run import create_app
from db import init_db
from config import TestingConfig
from werkzeug.security import generate_password_hash
import sqlite3


@pytest.fixture()
def app():
    db_path = TestingConfig.DATABASE
    if os.path.exists(db_path):
        try:
            os.remove(db_path)
        except OSError:
            pass
    application = create_app('testing')
    with application.app_context():
        init_db(TestingConfig)
        db = sqlite3.connect(db_path)
        db.execute('DELETE FROM users')
        users = [
            ('admin', 'Admin', 'adminpass1', 'admin'),
            ('reception', 'Reception', 'reception1', 'receptionist'),
            ('worker', 'Worker', 'workerpass1', 'worker'),
            ('director', 'Director', 'director1', 'director'),
        ]
        for u, fn, pw, r in users:
            db.execute(
                'INSERT INTO users (username, full_name, password_hash, role) '
                'VALUES (?, ?, ?, ?)',
                (u, fn, generate_password_hash(pw), r),
            )
        db.execute(
            "INSERT INTO workers (full_name, specialization, rate) "
            "VALUES ('Test Worker', 'портной', 1000)"
        )
        db.execute(
            "INSERT INTO materials (name, kind, unit, stock, min_stock, price) "
            "VALUES ('Ткань тест', 'ткань', 'м', 20, 5, 100)"
        )
        db.execute(
            "INSERT INTO clients (full_name, phone, email) "
            "VALUES ('Иванов Тест', '+79990001122', 'test@example.com')"
        )
        db.commit()
        db.close()
    yield application
    if os.path.exists(db_path):
        try:
            os.remove(db_path)
        except OSError:
            pass


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def auth_client(client):
    client.post('/login', data={'username': 'admin', 'password': 'adminpass1'},
                follow_redirects=True)
    return client


def login(client, username='admin', password='adminpass1'):
    return client.post(
        '/login',
        data={'username': username, 'password': password},
        follow_redirects=True,
    )
