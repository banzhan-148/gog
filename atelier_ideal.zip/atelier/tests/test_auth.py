"""Authentication and role tests."""
from tests.conftest import login


def test_login_success(client):
    rv = login(client)
    assert rv.status_code == 200
    assert b'\xd0\x93\xd0\xbb\xd0\xb0\xd0\xb2\xd0\xbd\xd0\xb0\xd1\x8f' in rv.data or b'dashboard' in rv.data.lower() or rv.request.path in ('/',)


def test_login_bad_password(client):
    rv = client.post('/login', data={'username': 'admin', 'password': 'wrong'},
                     follow_redirects=True)
    assert b'\xd0\x9d\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd' in rv.data or b'error' in rv.data.lower() or rv.status_code == 200


def test_login_unknown_user(client):
    rv = client.post('/login', data={'username': 'nobody', 'password': 'x'},
                     follow_redirects=True)
    assert rv.status_code == 200


def test_logout(client):
    login(client)
    rv = client.get('/logout', follow_redirects=True)
    assert rv.status_code == 200


def test_protected_redirect(client):
    rv = client.get('/orders/', follow_redirects=False)
    assert rv.status_code in (302, 301)


def test_role_forbidden(client):
    login(client, 'worker', 'workerpass1')
    rv = client.get('/admin/', follow_redirects=False)
    assert rv.status_code in (403, 302)
