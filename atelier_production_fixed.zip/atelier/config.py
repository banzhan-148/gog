import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Production only when FLASK_ENV is explicitly set to "production"
IS_DEV = os.environ.get('FLASK_ENV', 'development') != 'production'


class Config:
    SECRET_KEY_FILE = os.path.join(BASE_DIR, '.secret_key')
    DATABASE = os.path.join(BASE_DIR, 'atelier.db')
    STATIC_DIR = os.path.join(BASE_DIR, 'static')
    TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')
    BACKUPS_DIR = os.path.join(BASE_DIR, 'backups')

    # Session
    PERMANENT_SESSION_LIFETIME_SECONDS = 8 * 60 * 60   # 8 hours

    # Cookies — always secure in production
    SESSION_COOKIE_SECURE = not IS_DEV
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'

    # CSRF (seconds)
    WTF_CSRF_TIME_LIMIT = 8 * 60 * 60
    WTF_CSRF_SSL_STRICT = not IS_DEV

    # Request limits
    MAX_CONTENT_LENGTH = 1024 * 1024
    LOGIN_LIMIT = '10 per minute'
    API_LIMIT = '60 per minute'
    DEFAULT_LIMIT = '300 per minute'

    # Mode flags
    IS_DEV = IS_DEV
    PREFERRED_URL_SCHEME = 'http' if IS_DEV else 'https'

    # Domain constants
    ORDER_STATUSES = ['принят', 'в работе', 'на примерке', 'готов', 'выдан', 'отменён']
    WORK_TYPES = ['пошив', 'ремонт', 'подгонка']
    ROLES = ['admin', 'receptionist', 'worker', 'director']

    # Roles allowed for sensitive endpoints
    ROLE_ORDERS_VIEW = ('admin', 'receptionist', 'worker', 'director')
    ROLE_ORDERS_STATUS = ('admin', 'receptionist', 'worker')
    ROLE_CLIENTS_VIEW = ('admin', 'receptionist', 'director')
    ROLE_DASHBOARD = ('admin', 'receptionist', 'worker', 'director')
    ROLE_PAYMENTS_VIEW = ('admin', 'receptionist', 'director')
    ROLE_API_CLIENTS = ('admin', 'receptionist')
