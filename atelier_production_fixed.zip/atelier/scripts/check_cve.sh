#!/usr/bin/env bash
# Check dependencies for known CVEs using pip-audit.
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v pip-audit >/dev/null 2>&1; then
  echo "Installing pip-audit..."
  pip install --quiet pip-audit
fi
echo "Scanning requirements.lock for CVEs..."
pip-audit -r requirements.lock
echo "OK — no known critical issues reported (or review output above)."
