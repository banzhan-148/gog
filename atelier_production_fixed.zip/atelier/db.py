import os
import sqlite3
from contextlib import contextmanager

from flask import g
from werkzeug.security import generate_password_hash

from config import Config


SCHEMA_FILE = os.path.join(os.path.dirname(__file__), 'schema.sql')


def get_db():
    """Connection for the duration of the request."""
    if 'db' not in g:
        g.db = sqlite3.connect(Config.DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys = ON')
    return g.db


def close_db(exc=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def q(sql, params=(), one=False):
    """Parameterized SELECT."""
    cur = get_db().execute(sql, params)
    rows = cur.fetchall()
    cur.close()
    if one:
        return dict(rows[0]) if rows else None
    return [dict(r) for r in rows]


def execute(sql, params=()):
    """INSERT/UPDATE/DELETE with immediate commit (single statement)."""
    db = get_db()
    cur = db.execute(sql, params)
    db.commit()
    lid = cur.lastrowid
    cur.close()
    return lid


@contextmanager
def transaction():
    """Multi-statement transaction. Commits on success, rolls back on error.

    Usage:
        with transaction() as db:
            cur = db.execute(...)
            oid = cur.lastrowid
            db.execute(...)
    """
    db = get_db()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise


def init_db():
    """Create tables. Demo users only in development; production uses env."""
    with open(SCHEMA_FILE, 'r', encoding='utf-8') as f:
        schema = f.read()

    db = sqlite3.connect(Config.DATABASE)
    db.executescript(schema)
    db.commit()

    user_count = db.execute('SELECT COUNT(*) FROM users').fetchone()[0]

    if user_count == 0:
        if Config.IS_DEV:
            # Development only: weak demo accounts for local testing
            demo = [
                ('admin', 'Администратор системы', 'admin123', 'admin'),
                ('reception', 'Приёмщик заказов', 'reception123', 'receptionist'),
                ('director', 'Директор ателье', 'director123', 'director'),
                ('worker', 'Портной Иванов И.И.', 'worker123', 'worker'),
            ]
            for u, fn, pw, r in demo:
                db.execute(
                    'INSERT INTO users (username, full_name, password_hash, role) '
                    'VALUES (?, ?, ?, ?)',
                    (u, fn, generate_password_hash(pw), r))
            print('[init_db] DEV: созданы демо-пользователи '
                  '(admin/admin123 и др.). Смените пароли перед продакшеном!')
        else:
            # Production: create single admin from environment — never hardcode
            admin_user = os.environ.get('ADMIN_USERNAME', 'admin').strip() or 'admin'
            admin_pass = os.environ.get('ADMIN_PASSWORD', '').strip()
            admin_name = os.environ.get('ADMIN_FULL_NAME', 'Администратор').strip() or 'Администратор'
            if not admin_pass or len(admin_pass) < 12:
                db.close()
                raise RuntimeError(
                    'PRODUCTION: задайте ADMIN_PASSWORD (минимум 12 символов) '
                    'в переменных окружения перед первым запуском. '
                    'Демо-пользователи в production запрещены.'
                )
            db.execute(
                'INSERT INTO users (username, full_name, password_hash, role) '
                'VALUES (?, ?, ?, ?)',
                (admin_user, admin_name, generate_password_hash(admin_pass), 'admin'))
            print(f'[init_db] PRODUCTION: создан администратор "{admin_user}". '
                  'Пароль взят из ADMIN_PASSWORD.')

    if db.execute('SELECT COUNT(*) FROM workers').fetchone()[0] == 0 and Config.IS_DEV:
        db.execute("INSERT INTO workers (full_name, specialization, rate) "
                   "VALUES ('Иванов Иван Иванович', 'портной', 1500)")
        db.execute("INSERT INTO workers (full_name, specialization, rate) "
                   "VALUES ('Петрова Анна Сергеевна', 'закройщик', 1800)")

    if db.execute('SELECT COUNT(*) FROM materials').fetchone()[0] == 0 and Config.IS_DEV:
        db.execute("INSERT INTO materials (name, kind, unit, stock, min_stock, price) "
                   "VALUES ('Ткань хлопок', 'ткань', 'м', 50, 10, 650)")
        db.execute("INSERT INTO materials (name, kind, unit, stock, min_stock, price) "
                   "VALUES ('Молния 20 см', 'фурнитура', 'шт', 100, 20, 45)")

    db.commit()
    db.close()
