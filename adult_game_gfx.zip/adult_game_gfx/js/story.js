window.STORY = {
  start: {
    bg: 'room', pose: 'idle',
    speaker: '', text: 'Дождь за окном. В дверь стучат — ты знаешь, кто это.',
    next: 'door',
  },
  door: {
    bg: 'room', pose: 'idle',
    speaker: '', text: 'На пороге — {name}. Взгляд цепкий, губы чуть приоткрыты.',
    choices: [
      { text: '«Заходи. Я ждал(а).»', next: 'in1', close: 12, desire: 8 },
      { text: 'Молча пропустить внутрь', next: 'in2', close: 8, desire: 12 },
      { text: '«Давай я тебя согрею.»', next: 'in3', close: 6, desire: 18 },
    ],
  },
  in1: {
    bg: 'room', pose: 'close',
    speaker: '{name}', text: '«Знал(а).» Куртка падает на стул. Парфюм и тепло — совсем близко.',
    next: 'sofa', close: 5,
  },
  in2: {
    bg: 'room', pose: 'blush',
    speaker: '{name}', text: 'Плечом касается тебя. «Налей вина. И смотри, если хочешь.»',
    next: 'sofa', desire: 5,
  },
  in3: {
    bg: 'room', pose: 'blush',
    speaker: '{name}', text: 'Улыбка. Пальцы на секунду на твоей груди: «Покажи.»',
    next: 'sofa', desire: 10,
  },
  sofa: {
    bg: 'room', pose: 'close',
    speaker: '', text: 'Диван. Расстояние — меньше ладони. {name} поворачивается к тебе.',
    choices: [
      { text: 'Взять за руку', next: 'hand', close: 15, desire: 8 },
      { text: 'Смотреть в глаза', next: 'eyes', close: 12, desire: 12 },
      { text: 'Наклониться к шее', next: 'neck', close: 6, desire: 22 },
    ],
  },
  hand: {
    bg: 'room', pose: 'blush',
    speaker: '{name}', text: 'Пальцы переплетаются. Она проводит большим пальцем по твоей коже.',
    next: 'kiss', close: 10,
  },
  eyes: {
    bg: 'room', pose: 'blush',
    speaker: '{name}', text: '«Если так смотришь… я не сдержусь.»',
    next: 'kiss', desire: 10,
  },
  neck: {
    bg: 'intimate', pose: 'blush',
    speaker: '{name}', text: 'Тихий вдох. Шея открыта. «Ещё…»',
    next: 'kiss', desire: 15,
  },
  kiss: {
    bg: 'intimate', pose: 'blush',
    speaker: '', text: 'Поцелуй висит в воздухе между вами.',
    choices: [
      { text: 'Поцеловать мягко', next: 'k1', close: 20, desire: 15 },
      { text: 'Поцеловать жадно', next: 'k2', close: 10, desire: 28 },
      { text: '«Скажи, чего хочешь»', next: 'k3', close: 16, desire: 12 },
    ],
  },
  k1: {
    bg: 'intimate', pose: 'heat',
    speaker: '{name}', text: 'Губы тёплые. Она отвечает глубже, рука на затылке.',
    next: 'heat', close: 10, desire: 10,
  },
  k2: {
    bg: 'intimate', pose: 'heat',
    speaker: '{name}', text: 'Зубы, язык, сдавленный стон. Одежда уже мешает.',
    next: 'heat', desire: 15,
  },
  k3: {
    bg: 'intimate', pose: 'heat',
    speaker: '{name}', text: '«Хочу тебя. Здесь. Сейчас.»',
    next: 'heat', close: 10, desire: 15,
  },
  heat: {
    bg: 'intimate', pose: 'heat',
    speaker: '', text: 'Комната кажется меньше. Кожа к коже — почти.',
    choices: [
      { text: 'Раздеть медленно', next: 's1', close: 15, desire: 22 },
      { text: 'Пусть она раздевает тебя', next: 's2', close: 20, desire: 16 },
      { text: 'Притянуть, не снимая всё', next: 's3', close: 6, desire: 28 },
    ],
  },
  s1: {
    bg: 'intimate', pose: 'heat',
    speaker: '{name}', text: 'Каждая пуговица — пауза. «Не торопись… или торопись.»',
    next: 'bed', close: 10, desire: 15,
  },
  s2: {
    bg: 'intimate', pose: 'heat',
    speaker: '{name}', text: 'Её ладони уверенные. «На эту ночь — весь(вся) мой(моя).»',
    next: 'bed', close: 15, desire: 12,
  },
  s3: {
    bg: 'peak', pose: 'heat',
    speaker: '{name}', text: 'Ткань между телами только сильнее. Бёдра — без слов.',
    next: 'bed', desire: 20,
  },
  bed: {
    bg: 'peak', pose: 'love',
    speaker: '', text: 'Кровать. Ночник. Дальше — только ваш выбор.',
    choices: [
      { text: 'Ласки', next: 'p1', close: 15, desire: 30 },
      { text: 'Медленно и глубоко', next: 'p2', close: 22, desire: 30 },
      { text: 'Жёстче', next: 'p3', close: 6, desire: 36 },
    ],
  },
  p1: {
    bg: 'peak', pose: 'love',
    speaker: '{name}', text: 'Дыхание срывается. «Не останавливайся…»',
    next: 'fin', desire: 20, close: 10,
  },
  p2: {
    bg: 'peak', pose: 'love',
    speaker: '{name}', text: 'Глаза в глаза. Каждый движения — ближе. Шепчет твоё имя.',
    next: 'fin', close: 20, desire: 20,
  },
  p3: {
    bg: 'peak', pose: 'love',
    speaker: '{name}', text: 'Стон в подушку. Ногти на лопатках. «Ещё…»',
    next: 'fin', desire: 25,
  },
  fin: {
    bg: 'peak', pose: 'love',
    speaker: '', text: 'На пределе.',
    choices: [
      { text: 'Сначала она', next: 'e1', close: 25, desire: 15 },
      { text: 'Вместе', next: 'e2', close: 20, desire: 25 },
      { text: 'До утра', next: 'e3', close: 15, desire: 20 },
    ],
  },
  e1: { speaker: '{name}', text: 'Дрожь, долгий выдох, тихий смех: «Ты невероятен(на).»', end: 'caring' },
  e2: { speaker: '{name}', text: 'Волна на двоих. Ленивый глубокий поцелуй после.', end: 'passion' },
  e3: { speaker: '{name}', text: '«Утро подождёт.» Новая искра. Дождь всё ещё стучит в окно.', end: 'marathon' },
};

window.ENDINGS = {
  caring: { title: 'Нежность', text: 'Объятия до утра. Кофе, улыбка, «повторим?»' },
  passion: { title: 'Страсть', text: '{name} уходит на рассвете. След на шее. Номер на зеркале.' },
  marathon: { title: 'До рассвета', text: 'Вы не считали. К утру голос сел — губы всё ещё улыбаются.' },
};
