(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const gate = $('gate'), menu = $('menu'), game = $('game'), ending = $('ending');
  const charGrid = $('char-grid');
  const btnEnter = $('btn-enter'), btnStart = $('btn-start');
  const btnNext = $('btn-next'), btnMenu = $('btn-to-menu'), btnAgain = $('btn-again');
  const sceneBg = $('scene-bg'), charLayer = $('char-layer');
  const speakerEl = $('speaker'), lineEl = $('line'), choicesEl = $('choices');
  const barClose = $('bar-close'), barDesire = $('bar-desire');

  let hero = null;
  let close = 0, desire = 0;
  let typingTimer = null;

  function show(name) {
    [gate, menu, game, ending].forEach((s) => s.classList.remove('active'));
    $(name).classList.add('active');
  }

  function fill(s) {
    return (s || '').replace(/\{name\}/g, hero ? hero.name : '');
  }

  function poseFromDesire() {
    if (desire >= 75) return 'love';
    if (desire >= 45) return 'heat';
    if (desire >= 25) return 'blush';
    if (close >= 20) return 'close';
    return 'idle';
  }

  function drawChar(pose) {
    const p = pose || poseFromDesire();
    charLayer.innerHTML = renderCharSVG(hero, p);
    charLayer.className = 'char-layer';
    if (p === 'close' || p === 'blush') charLayer.classList.add('closer');
    if (p === 'heat') charLayer.classList.add('heat');
    if (p === 'love') charLayer.classList.add('kiss');
  }

  function setMeters() {
    close = Math.max(0, Math.min(100, close));
    desire = Math.max(0, Math.min(100, desire));
    barClose.style.width = close + '%';
    barDesire.style.width = desire + '%';
  }

  function typeText(text, cb) {
    clearInterval(typingTimer);
    lineEl.innerHTML = '';
    let i = 0;
    const full = fill(text);
    typingTimer = setInterval(() => {
      if (i <= full.length) {
        lineEl.innerHTML = full.slice(0, i) + '<span class="cursor"></span>';
        i++;
      } else {
        clearInterval(typingTimer);
        lineEl.textContent = full;
        if (cb) cb();
      }
    }, 18);
  }

  function renderMenu() {
    charGrid.innerHTML = '';
    CHAR_DATA.forEach((c) => {
      const el = document.createElement('button');
      el.type = 'button';
      el.className = 'char-card' + (hero && hero.id === c.id ? ' sel' : '');
      el.innerHTML =
        '<div class="mini">' + renderCharSVG(c, 'idle') + '</div>' +
        '<div class="nm">' + c.name + '</div>' +
        '<div class="ds">' + c.desc + ' · ' + c.age + '</div>';
      el.addEventListener('click', () => {
        hero = c;
        renderMenu();
        btnStart.disabled = false;
        FX.burst(el.getBoundingClientRect().left + 40, el.getBoundingClientRect().top + 40, 8);
      });
      charGrid.appendChild(el);
    });
  }

  function applyBg(bg) {
    sceneBg.className = 'scene-bg' + (bg ? ' ' + bg : '');
    if (bg === 'intimate') FX.setMode('heat');
    else if (bg === 'peak') FX.setMode('peak');
    else FX.setMode('soft');
  }

  function go(id) {
    const node = STORY[id];
    if (!node) return;

    if (node.close) close += node.close;
    if (node.desire) desire += node.desire;
    setMeters();

    if (node.end) {
      finish(node.end);
      return;
    }

    if (node.bg) applyBg(node.bg);
    drawChar(node.pose);

    speakerEl.textContent = fill(node.speaker || '');
    choicesEl.innerHTML = '';
    btnNext.classList.add('hidden');

    typeText(node.text, () => {
      if (node.choices) {
        node.choices.forEach((ch) => {
          const b = document.createElement('button');
          b.type = 'button';
          b.className = 'choice';
          b.textContent = fill(ch.text);
          b.addEventListener('click', () => {
            if (ch.close) close += ch.close;
            if (ch.desire) desire += ch.desire;
            setMeters();
            FX.burst(window.innerWidth / 2, window.innerHeight * 0.35, 10);
            go(ch.next);
          });
          choicesEl.appendChild(b);
        });
      } else if (node.next) {
        btnNext.classList.remove('hidden');
        btnNext.onclick = () => go(node.next);
      }
    });
  }

  function finish(key) {
    const e = ENDINGS[key] || ENDINGS.passion;
    FX.setMode('peak');
    for (let i = 0; i < 20; i++) {
      setTimeout(() => FX.spawnHeart(), i * 50);
    }
    $('end-art').innerHTML = renderCharSVG(hero, 'love');
    $('end-title').textContent = e.title;
    $('end-text').textContent = fill(e.text);
    show('ending');
  }

  btnEnter.addEventListener('click', () => {
    show('menu');
    renderMenu();
    FX.setMode('soft');
  });

  btnStart.addEventListener('click', () => {
    if (!hero) return;
    close = 8;
    desire = 5;
    setMeters();
    show('game');
    go('start');
  });

  btnMenu.addEventListener('click', () => {
    FX.setMode('idle');
    show('menu');
  });

  btnAgain.addEventListener('click', () => {
    hero = null;
    btnStart.disabled = true;
    renderMenu();
    show('menu');
  });

  show('gate');
})();
