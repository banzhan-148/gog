/** Canvas particles: hearts, sparks, rain */
window.FX = (function () {
  const canvas = document.getElementById('fx');
  const ctx = canvas.getContext('2d');
  let particles = [];
  let rain = [];
  let mode = 'idle'; // idle | soft | heat | peak
  let raf;

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  function spawnHeart(x, y) {
    particles.push({
      type: 'heart',
      x: x ?? Math.random() * canvas.width,
      y: y ?? canvas.height + 10,
      vy: -(0.8 + Math.random() * 1.5),
      vx: (Math.random() - 0.5) * 0.8,
      life: 1,
      size: 8 + Math.random() * 12,
      rot: Math.random() * Math.PI,
    });
  }

  function burst(x, y, n) {
    for (let i = 0; i < (n || 12); i++) {
      particles.push({
        type: 'spark',
        x, y,
        vx: (Math.random() - 0.5) * 6,
        vy: (Math.random() - 0.5) * 6 - 2,
        life: 1,
        size: 2 + Math.random() * 3,
      });
    }
    for (let i = 0; i < 5; i++) spawnHeart(x + (Math.random() - 0.5) * 40, y);
  }

  function setMode(m) {
    mode = m;
  }

  function initRain() {
    rain = [];
    for (let i = 0; i < 60; i++) {
      rain.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        len: 8 + Math.random() * 14,
        spd: 3 + Math.random() * 4,
      });
    }
  }
  initRain();

  function drawHeart(x, y, s, a, rot) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rot);
    ctx.globalAlpha = a;
    ctx.fillStyle = '#ff4d8d';
    ctx.beginPath();
    const r = s / 2;
    ctx.moveTo(0, r * 0.3);
    ctx.bezierCurveTo(-r, -r * 0.5, -r * 1.2, r * 0.6, 0, r * 1.3);
    ctx.bezierCurveTo(r * 1.2, r * 0.6, r, -r * 0.5, 0, r * 0.3);
    ctx.fill();
    ctx.restore();
  }

  function tick() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // rain
    ctx.strokeStyle = 'rgba(180,160,200,0.2)';
    ctx.lineWidth = 1;
    rain.forEach((r) => {
      ctx.beginPath();
      ctx.moveTo(r.x, r.y);
      ctx.lineTo(r.x - 1, r.y + r.len);
      ctx.stroke();
      r.y += r.spd;
      r.x -= 0.3;
      if (r.y > canvas.height) {
        r.y = -10;
        r.x = Math.random() * canvas.width;
      }
    });

    // ambient hearts in heat/peak
    if (mode === 'heat' && Math.random() < 0.04) spawnHeart();
    if (mode === 'peak' && Math.random() < 0.1) spawnHeart();

    particles = particles.filter((p) => {
      p.life -= 0.012;
      if (p.type === 'heart') {
        p.x += p.vx;
        p.y += p.vy;
        p.rot += 0.02;
        drawHeart(p.x, p.y, p.size, Math.max(0, p.life), p.rot);
      } else {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.1;
        ctx.globalAlpha = Math.max(0, p.life);
        ctx.fillStyle = '#ff9ebb';
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
      return p.life > 0;
    });

    raf = requestAnimationFrame(tick);
  }

  tick();

  return { burst, setMode, spawnHeart };
})();
