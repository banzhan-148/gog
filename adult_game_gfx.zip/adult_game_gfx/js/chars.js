/** SVG adult characters (stylized, 21+) + scene poses */
window.CHAR_DATA = [
  {
    id: 'lena',
    name: 'Лена',
    age: 24,
    desc: 'Соседка',
    skin: '#f5d0c0',
    hair: '#3d2314',
    top: '#e83e8c',
    accent: '#ff9ebb',
  },
  {
    id: 'masha',
    name: 'Маша',
    age: 27,
    desc: 'Коллега',
    skin: '#e8c4a8',
    hair: '#1a1a1a',
    top: '#6b3fa0',
    accent: '#c9a0dc',
  },
  {
    id: 'kira',
    name: 'Кира',
    age: 26,
    desc: 'Бывшая',
    skin: '#f0d5c8',
    hair: '#8b1a3a',
    top: '#222',
    accent: '#ff4d8d',
  },
];

/** pose: idle | close | blush | heat | love */
window.renderCharSVG = function (c, pose) {
  const blush = pose === 'blush' || pose === 'heat' || pose === 'love';
  const eyesHappy = pose === 'love' || pose === 'heat';
  const mouthOpen = pose === 'heat' || pose === 'love';
  const undress = pose === 'heat' || pose === 'love';

  const eyeL = eyesHappy
    ? `<path d="M38 52 Q42 48 46 52" fill="none" stroke="#222" stroke-width="1.5"/>`
    : `<circle cx="42" cy="52" r="2.2" fill="#222"/><circle cx="42.5" cy="51.5" r="0.7" fill="#fff"/>`;
  const eyeR = eyesHappy
    ? `<path d="M54 52 Q58 48 62 52" fill="none" stroke="#222" stroke-width="1.5"/>`
    : `<circle cx="58" cy="52" r="2.2" fill="#222"/><circle cx="58.5" cy="51.5" r="0.7" fill="#fff"/>`;

  const mouth = mouthOpen
    ? `<ellipse cx="50" cy="62" rx="4" ry="2.5" fill="#c45c6a"/>`
    : pose === 'blush'
      ? `<path d="M46 61 Q50 65 54 61" fill="none" stroke="#c45c6a" stroke-width="1.5"/>`
      : `<path d="M47 61 Q50 63 53 61" fill="none" stroke="#b07070" stroke-width="1.3"/>`;

  const blushCircles = blush
    ? `<circle cx="36" cy="58" r="4" fill="#ff8a9a" opacity="0.45"/>
       <circle cx="64" cy="58" r="4" fill="#ff8a9a" opacity="0.45"/>`
    : '';

  // body clothing vs more revealing
  const top = undress
    ? `<path d="M32 88 Q50 95 68 88 L72 130 L28 130 Z" fill="${c.skin}"/>
       <path d="M38 88 Q50 100 62 88" fill="none" stroke="${c.accent}" stroke-width="1.5" opacity="0.5"/>`
    : `<path d="M30 88 Q50 98 70 88 L74 140 L26 140 Z" fill="${c.top}"/>
       <path d="M30 88 Q50 92 70 88" fill="${c.skin}"/>`;

  return `
<svg viewBox="0 0 100 160" xmlns="http://www.w3.org/2000/svg">
  <!-- hair back -->
  <ellipse cx="50" cy="48" rx="28" ry="32" fill="${c.hair}"/>
  <!-- neck -->
  <rect x="44" y="72" width="12" height="18" rx="3" fill="${c.skin}"/>
  <!-- body -->
  ${top}
  <!-- arms soft -->
  <ellipse cx="26" cy="110" rx="8" ry="22" fill="${c.skin}" transform="rotate(8 26 110)"/>
  <ellipse cx="74" cy="110" rx="8" ry="22" fill="${c.skin}" transform="rotate(-8 74 110)"/>
  <!-- head -->
  <ellipse cx="50" cy="52" rx="22" ry="26" fill="${c.skin}"/>
  <!-- hair front -->
  <path d="M28 48 Q30 22 50 20 Q70 22 72 48 Q68 38 50 36 Q32 38 28 48" fill="${c.hair}"/>
  <path d="M22 55 Q18 70 28 85 Q32 70 30 55" fill="${c.hair}"/>
  <path d="M78 55 Q82 70 72 85 Q68 70 70 55" fill="${c.hair}"/>
  <!-- face -->
  ${eyeL}${eyeR}
  ${blushCircles}
  ${mouth}
  <!-- nose hint -->
  <path d="M50 54 L48 58 L52 58" fill="none" stroke="${c.skin}" stroke-width="0.5" opacity="0.5"/>
  <!-- hearts when love -->
  ${pose === 'love' ? `
    <g class="float-heart" opacity="0.85">
      <path d="M18 30 C18 26 22 24 24 28 C26 24 30 26 30 30 C30 36 24 40 24 40 C24 40 18 36 18 30" fill="${c.accent}"/>
      <path d="M72 24 C72 20 76 18 78 22 C80 18 84 20 84 24 C84 30 78 34 78 34 C78 34 72 30 72 24" fill="${c.pink || c.accent}" opacity="0.7"/>
    </g>` : ''}
</svg>`;
};
