/**
 * «Ты меня любишь?» — cute pink love mini-games app
 */
(function () {
  'use strict';

  // ----- DOM -----
  const screenQ = document.getElementById('screen-question');
  const screenGames = document.getElementById('screen-games');
  const screenPlay = document.getElementById('screen-play');
  const screenFinal = document.getElementById('screen-final');
  const card = document.getElementById('question-card');
  const btnYes = document.getElementById('btn-yes');
  const btnNo = document.getElementById('btn-no');
  const gamesGrid = document.getElementById('games-grid');
  const progressBar = document.getElementById('progress-bar');
  const progressText = document.getElementById('progress-text');
  const playArea = document.getElementById('play-area');
  const playTitle = document.getElementById('play-title');
  const playHint = document.getElementById('play-hint');
  const btnBack = document.getElementById('btn-back');
  const btnAgain = document.getElementById('btn-again');
  const bgHearts = document.getElementById('bg-hearts');

  // ----- State -----
  const GAMES = [
    {
      id: 'catch',
      name: 'Поймай сердечки',
      icon: '💘',
      desc: 'Кликни по 8 падающим сердечкам',
      goal: 8,
    },
    {
      id: 'memory',
      name: 'Память любви',
      icon: '🧠',
      desc: 'Найди все пары (6 пар)',
      goal: 6,
    },
    {
      id: 'tap',
      name: 'Догони сердце',
      icon: '💓',
      desc: 'Поймай убегающее сердце 5 раз',
      goal: 5,
    },
  ];

  let completed = new Set();
  let currentGame = null;
  let cleanupFn = null;

  // ----- Helpers -----
  function showScreen(el) {
    [screenQ, screenGames, screenPlay, screenFinal].forEach((s) =>
      s.classList.remove('active')
    );
    el.classList.add('active');
  }

  function updateProgress() {
    const n = completed.size;
    const pct = (n / GAMES.length) * 100;
    progressBar.style.width = pct + '%';
    progressText.textContent = n + ' / ' + GAMES.length;
    if (n >= GAMES.length) {
      setTimeout(() => {
        showScreen(screenFinal);
        spawnConfetti();
      }, 600);
    }
  }

  function renderGameCards() {
    gamesGrid.innerHTML = '';
    GAMES.forEach((g, i) => {
      const done = completed.has(g.id);
      // sequential unlock optional — all open for easy flow
      const locked = false;
      const cardEl = document.createElement('div');
      cardEl.className =
        'game-card' + (done ? ' done' : '') + (locked ? ' locked' : '');
      cardEl.innerHTML =
        '<div class="game-icon">' +
        g.icon +
        '</div>' +
        '<div class="game-name">' +
        g.name +
        '</div>' +
        '<div class="game-desc">' +
        g.desc +
        '</div>' +
        '<span class="game-badge">' +
        (done ? '✓ Готово' : 'Играть') +
        '</span>';
      if (!done && !locked) {
        cardEl.addEventListener('click', () => startGame(g));
      }
      gamesGrid.appendChild(cardEl);
    });
  }

  // ----- Runaway "No" -----
  function moveCardAway(e) {
    const pad = 16;
    const cw = card.offsetWidth;
    const ch = card.offsetHeight;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    // Current card position (may be absolute already)
    const rect = card.getBoundingClientRect();
    let nx, ny;
    let tries = 0;
    do {
      nx = pad + Math.random() * (vw - cw - pad * 2);
      ny = pad + Math.random() * (vh - ch - pad * 2);
      tries++;
    } while (
      tries < 12 &&
      Math.hypot(nx - rect.left, ny - rect.top) < Math.min(vw, vh) * 0.28
    );

    card.classList.add('jumping');
    card.style.position = 'fixed';
    card.style.left = nx + 'px';
    card.style.top = ny + 'px';
    card.style.margin = '0';
    card.style.transform = 'none';
  }

  btnNo.addEventListener('mouseenter', moveCardAway);
  btnNo.addEventListener('touchstart', (e) => {
    e.preventDefault();
    moveCardAway(e);
  }, { passive: false });

  // Also jump if they somehow click near No
  btnNo.addEventListener('click', (e) => {
    e.preventDefault();
    moveCardAway(e);
  });

  btnYes.addEventListener('click', () => {
    showScreen(screenGames);
    renderGameCards();
    updateProgress();
  });

  btnBack.addEventListener('click', () => {
    if (cleanupFn) {
      cleanupFn();
      cleanupFn = null;
    }
    showScreen(screenGames);
    renderGameCards();
  });

  btnAgain.addEventListener('click', () => {
    completed = new Set();
    // reset card position
    card.style.position = '';
    card.style.left = '';
    card.style.top = '';
    card.style.margin = '';
    showScreen(screenQ);
  });

  // ----- Games -----
  function startGame(g) {
    currentGame = g;
    showScreen(screenPlay);
    playTitle.textContent = g.icon + ' ' + g.name;
    playArea.innerHTML = '';
    if (cleanupFn) cleanupFn();

    if (g.id === 'catch') playCatch();
    else if (g.id === 'memory') playMemory();
    else if (g.id === 'tap') playTap();
  }

  function winGame() {
    if (cleanupFn) {
      cleanupFn();
      cleanupFn = null;
    }
    completed.add(currentGame.id);
    playArea.innerHTML =
      '<div class="win-msg">' +
      '<h3>Ура! 💕</h3>' +
      '<p>Мини-игра пройдена</p>' +
      '<button class="btn btn-yes" id="btn-to-hub" type="button">К играм</button>' +
      '</div>';
    document.getElementById('btn-to-hub').addEventListener('click', () => {
      showScreen(screenGames);
      renderGameCards();
      updateProgress();
    });
  }

  // 1) Catch falling hearts
  function playCatch() {
    playHint.textContent = 'Кликай по сердечкам, пока они падают';
    const field = document.createElement('div');
    field.className = 'catch-field';
    playArea.appendChild(field);

    const scoreEl = document.createElement('div');
    scoreEl.className = 'score-badge';
    scoreEl.textContent = '0 / 8';
    playArea.appendChild(scoreEl);

    let score = 0;
    let spawned = 0;
    const timers = [];
    let alive = true;

    function spawn() {
      if (!alive || score >= 8) return;
      spawned++;
      const h = document.createElement('span');
      h.className = 'falling-heart';
      h.textContent = ['💗', '💖', '💕', '💓', '💘'][Math.floor(Math.random() * 5)];
      const left = 8 + Math.random() * 84;
      h.style.left = left + '%';
      h.style.animationDuration = 2.2 + Math.random() * 1.4 + 's';
      h.addEventListener('click', () => {
        if (!alive) return;
        h.remove();
        score++;
        scoreEl.textContent = score + ' / 8';
        if (score >= 8) {
          alive = false;
          winGame();
        }
      });
      h.addEventListener('animationend', () => h.remove());
      field.appendChild(h);
      if (spawned < 40 && score < 8) {
        timers.push(setTimeout(spawn, 450 + Math.random() * 350));
      }
    }
    spawn();
    timers.push(setTimeout(spawn, 500));
    timers.push(setTimeout(spawn, 900));

    cleanupFn = () => {
      alive = false;
      timers.forEach(clearTimeout);
    };
  }

  // 2) Memory match
  function playMemory() {
    playHint.textContent = 'Открой две одинаковые карточки';
    const symbols = ['💗', '🌹', '🎀', '✨', '🍓', '🦋'];
    const deck = [...symbols, ...symbols].sort(() => Math.random() - 0.5);

    const grid = document.createElement('div');
    grid.className = 'memory-grid';
    playArea.appendChild(grid);

    let flipped = [];
    let pairs = 0;
    let lock = false;

    deck.forEach((sym, i) => {
      const btn = document.createElement('button');
      btn.className = 'memory-card';
      btn.type = 'button';
      btn.dataset.sym = sym;
      btn.dataset.idx = String(i);
      btn.textContent = sym;

      btn.addEventListener('click', () => {
        if (lock || btn.classList.contains('flipped') || btn.classList.contains('matched'))
          return;
        btn.classList.add('flipped');
        flipped.push(btn);
        if (flipped.length === 2) {
          lock = true;
          const [a, b] = flipped;
          if (a.dataset.sym === b.dataset.sym) {
            a.classList.add('matched');
            b.classList.add('matched');
            pairs++;
            flipped = [];
            lock = false;
            if (pairs >= 6) setTimeout(winGame, 350);
          } else {
            setTimeout(() => {
              a.classList.remove('flipped');
              b.classList.remove('flipped');
              flipped = [];
              lock = false;
            }, 650);
          }
        }
      });
      grid.appendChild(btn);
    });

    cleanupFn = () => {};
  }

  // 3) Tap runaway heart
  function playTap() {
    playHint.textContent = 'Кликни по сердцу 5 раз — оно убегает!';
    const scoreEl = document.createElement('div');
    scoreEl.className = 'score-badge';
    scoreEl.textContent = '0 / 5';
    playArea.appendChild(scoreEl);

    const target = document.createElement('button');
    target.className = 'click-target';
    target.type = 'button';
    target.textContent = '💗';
    playArea.appendChild(target);

    let score = 0;
    let alive = true;

    function place() {
      const area = playArea.getBoundingClientRect();
      const size = 72;
      const maxX = Math.max(20, area.width - size - 16);
      const maxY = Math.max(20, area.height - size - 16);
      target.style.left = 8 + Math.random() * maxX + 'px';
      target.style.top = 8 + Math.random() * maxY + 'px';
    }
    place();

    target.addEventListener('click', () => {
      if (!alive) return;
      score++;
      scoreEl.textContent = score + ' / 5';
      if (score >= 5) {
        alive = false;
        winGame();
      } else {
        place();
      }
    });

    // gentle auto-move so it's not static
    const interval = setInterval(() => {
      if (alive) place();
    }, 1800);

    cleanupFn = () => {
      alive = false;
      clearInterval(interval);
    };
  }

  // ----- Background hearts -----
  function spawnBgHearts() {
    const emojis = ['💗', '💖', '💕', '💓', '🌸', '✨'];
    for (let i = 0; i < 14; i++) {
      const el = document.createElement('span');
      el.className = 'bg-heart';
      el.textContent = emojis[i % emojis.length];
      el.style.left = Math.random() * 100 + '%';
      el.style.fontSize = 0.9 + Math.random() * 1.2 + 'rem';
      el.style.animationDuration = 12 + Math.random() * 16 + 's';
      el.style.animationDelay = Math.random() * 10 + 's';
      bgHearts.appendChild(el);
    }
  }

  // ----- Confetti on final -----
  function spawnConfetti() {
    const emojis = ['💗', '💖', '💕', '💓', '💘', '🌸', '✨', '🌹'];
    for (let i = 0; i < 28; i++) {
      setTimeout(() => {
        const el = document.createElement('span');
        el.className = 'confetti-heart';
        el.textContent = emojis[Math.floor(Math.random() * emojis.length)];
        el.style.left = Math.random() * 100 + 'vw';
        el.style.top = -20 + Math.random() * 30 + 'px';
        el.style.fontSize = 1 + Math.random() * 1.4 + 'rem';
        document.body.appendChild(el);
        setTimeout(() => el.remove(), 2600);
      }, i * 70);
    }
  }

  // ----- Init -----
  spawnBgHearts();
  showScreen(screenQ);
})();
