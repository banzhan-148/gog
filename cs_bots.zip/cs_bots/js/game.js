(function () {
  'use strict';

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const menu = document.getElementById('menu');
  const hud = document.getElementById('hud');
  const overlay = document.getElementById('overlay');
  const hpFill = document.getElementById('hp-fill');
  const ammoEl = document.getElementById('ammo');
  const weaponEl = document.getElementById('weapon');
  const scoreEl = document.getElementById('score');
  const msgEl = document.getElementById('msg');
  const killfeed = document.getElementById('killfeed');

  let running = false;
  let paused = false;
  let lastT = 0;
  let difficulty = 'normal';
  let botCount = 5;

  const keys = {};
  const player = {
    x: 3, y: 3, angle: 0,
    hp: 100, maxHp: 100, alive: true,
    walkPhase: 0, muzzle: 0,
    kills: 0, deaths: 0,
  };

  let weaponKey = 'rifle';
  let mag = 30, reserve = 90;
  let shootTimer = 0;
  let reloading = false;
  let reloadT = 0;
  let bots = [];
  let particles = [];
  let respawnT = 0;
  let msgT = 0;

  MAP.init();

  function showMsg(text, sec) {
    msgEl.textContent = text;
    msgEl.classList.add('show');
    msgT = sec || 2;
  }

  function feed(text) {
    const d = document.createElement('div');
    d.textContent = text;
    killfeed.prepend(d);
    while (killfeed.children.length > 5) killfeed.lastChild.remove();
    setTimeout(() => d.remove(), 4000);
  }

  function resetPlayer() {
    const p = MAP.randomEmpty();
    player.x = p.x;
    player.y = p.y;
    player.angle = 0;
    player.hp = 100;
    player.alive = true;
    weaponKey = 'rifle';
    const w = WEAPONS[weaponKey];
    mag = w.mag;
    reserve = w.reserve;
    reloading = false;
    respawnT = 0;
  }

  function startGame() {
    difficulty = document.getElementById('diff').value;
    botCount = +document.getElementById('botCount').value;
    player.kills = 0;
    player.deaths = 0;
    resetPlayer();
    bots = [];
    for (let i = 0; i < botCount; i++) {
      const b = BotAI.create(MAP, difficulty);
      // keep away from player spawn
      if (Math.hypot(b.x - player.x, b.y - player.y) < 4) {
        const p = MAP.randomEmpty();
        b.x = p.x; b.y = p.y;
      }
      bots.push(b);
    }
    particles = [];
    menu.classList.add('hidden');
    overlay.classList.add('hidden');
    hud.classList.remove('hidden');
    running = true;
    paused = false;
    lastT = performance.now();
    canvas.requestPointerLock();
    showMsg('Удачи!', 1.5);
    requestAnimationFrame(loop);
  }

  function pauseGame() {
    if (!running) return;
    paused = true;
    document.exitPointerLock();
    overlay.classList.remove('hidden');
    document.getElementById('overlay-title').textContent = 'Пауза';
    document.getElementById('overlay-text').textContent = 'Esc — продолжить';
    document.getElementById('btn-resume').classList.remove('hidden');
  }

  function resumeGame() {
    paused = false;
    overlay.classList.add('hidden');
    canvas.requestPointerLock();
    lastT = performance.now();
    requestAnimationFrame(loop);
  }

  function toMenu() {
    running = false;
    paused = false;
    document.exitPointerLock();
    hud.classList.add('hidden');
    overlay.classList.add('hidden');
    menu.classList.remove('hidden');
  }

  function switchWeapon(key) {
    if (reloading || key === weaponKey) return;
    weaponKey = key;
    const w = WEAPONS[weaponKey];
    mag = w.mag;
    // keep some reserve fantasy
    weaponEl.textContent = w.name;
  }

  function reload() {
    const w = WEAPONS[weaponKey];
    if (reloading || mag >= w.mag || reserve <= 0) return;
    reloading = true;
    reloadT = w.reloadMs / 1000;
    showMsg('Перезарядка…', reloadT);
  }

  function playerShoot() {
    const w = WEAPONS[weaponKey];
    if (!player.alive || reloading || mag <= 0) {
      if (mag <= 0) reload();
      return;
    }
    const interval = 60 / w.rpm;
    if (shootTimer > 0) return;
    shootTimer = interval;
    mag--;
    player.muzzle = 1;

    // hitscan with spread
    const spread = (Math.random() - 0.5) * w.spread * 2;
    const ang = player.angle + spread;
    const cos = Math.cos(ang), sin = Math.sin(ang);
    let hitBot = null;
    let hitDist = w.range;
    for (const b of bots) {
      if (!b.alive) continue;
      const dx = b.x - player.x;
      const dy = b.y - player.y;
      const dist = Math.hypot(dx, dy);
      if (dist > w.range || dist < 0.2) continue;
      const botAng = Math.atan2(dy, dx);
      let dAng = botAng - ang;
      while (dAng > Math.PI) dAng -= Math.PI * 2;
      while (dAng < -Math.PI) dAng += Math.PI * 2;
      const thresh = Math.atan2(0.35, dist);
      if (Math.abs(dAng) < thresh && dist < hitDist) {
        if (BotAI.hasLOS(player.x, player.y, b.x, b.y, MAP)) {
          hitBot = b;
          hitDist = dist;
        }
      }
    }
    // wall check along ray roughly
    if (hitBot) {
      hitBot.hp -= w.dmg;
      // impact particle in screen center-ish
      particles.push({
        sx: canvas.width / 2 + (Math.random() - 0.5) * 40,
        sy: canvas.height / 2 + (Math.random() - 0.5) * 40,
        r: 3, life: 0.4, color: '#ff6666',
      });
      if (hitBot.hp <= 0) {
        hitBot.alive = false;
        player.kills++;
        feed('Вы ★ ' + hitBot.name);
        showMsg('Убит ' + hitBot.name, 1.2);
        setTimeout(() => BotAI.respawn(hitBot, MAP), 2500);
      }
    }
  }

  function onBotShoot(bot, dist) {
    if (!player.alive) return;
    const spread = bot.accuracy * dist;
    if (Math.random() < 0.55 + 1 / (dist + 1)) {
      // hit chance decreases with distance
      const dmg = Math.floor(12 + Math.random() * 18);
      player.hp -= dmg;
      particles.push({
        sx: canvas.width / 2 + (Math.random() - 0.5) * 80,
        sy: canvas.height / 2 + (Math.random() - 0.5) * 60,
        r: 4, life: 0.35, color: '#da3633',
      });
      if (player.hp <= 0) {
        player.hp = 0;
        player.alive = false;
        player.deaths++;
        feed(bot.name + ' ★ Вы');
        showMsg('Вы убиты — возрождение…', 2.5);
        respawnT = 2.5;
      }
    }
  }

  function update(dt) {
    if (msgT > 0) {
      msgT -= dt;
      if (msgT <= 0) msgEl.classList.remove('show');
    }

    if (!player.alive) {
      respawnT -= dt;
      if (respawnT <= 0) resetPlayer();
      return;
    }

    // movement
    const speed = keys['ShiftLeft'] || keys['ShiftRight'] ? 3.2 : 2.4;
    let mx = 0, my = 0;
    if (keys['KeyW']) { mx += Math.cos(player.angle); my += Math.sin(player.angle); }
    if (keys['KeyS']) { mx -= Math.cos(player.angle); my -= Math.sin(player.angle); }
    if (keys['KeyA']) { mx += Math.cos(player.angle - Math.PI / 2); my += Math.sin(player.angle - Math.PI / 2); }
    if (keys['KeyD']) { mx += Math.cos(player.angle + Math.PI / 2); my += Math.sin(player.angle + Math.PI / 2); }
    const len = Math.hypot(mx, my);
    if (len > 0) {
      mx = (mx / len) * speed * dt;
      my = (my / len) * speed * dt;
      Engine.tryMove(player, mx, my, MAP, 0.22);
      player.walkPhase += dt * 10;
    }

    shootTimer = Math.max(0, shootTimer - dt);
    player.muzzle = Math.max(0, player.muzzle - dt * 8);

    if (reloading) {
      reloadT -= dt;
      if (reloadT <= 0) {
        const w = WEAPONS[weaponKey];
        const need = w.mag - mag;
        const take = Math.min(need, reserve);
        mag += take;
        reserve -= take;
        reloading = false;
      }
    }

    if (keys['Mouse0'] && WEAPONS[weaponKey].auto) playerShoot();

    bots.forEach((b) => BotAI.update(b, player, MAP, dt, difficulty, onBotShoot));

    particles = particles.filter((p) => {
      p.life -= dt * 2;
      return p.life > 0;
    });
  }

  function drawHud() {
    const pct = Math.max(0, player.hp / player.maxHp * 100);
    hpFill.style.width = pct + '%';
    hpFill.style.background = pct > 40
      ? 'linear-gradient(90deg, #da3633, #3fb950)'
      : 'linear-gradient(90deg, #7a1010, #da3633)';
    ammoEl.textContent = reloading ? '… / ' + reserve : mag + ' / ' + reserve;
    weaponEl.textContent = WEAPONS[weaponKey].name;
    scoreEl.textContent = 'Убийства: ' + player.kills + ' · Смерти: ' + player.deaths;
  }

  function resize() {
    const maxW = window.innerWidth;
    const maxH = window.innerHeight;
    canvas.width = Math.min(960, maxW);
    canvas.height = Math.min(540, maxH);
    // scale CSS
    canvas.style.width = maxW + 'px';
    canvas.style.height = maxH + 'px';
  }

  function loop(t) {
    if (!running || paused) return;
    const dt = Math.min(0.05, (t - lastT) / 1000);
    lastT = t;
    update(dt);
    Engine.render(ctx, canvas.width, canvas.height, player, bots, MAP, particles);
    drawHud();
    requestAnimationFrame(loop);
  }

  // events
  document.getElementById('btn-start').addEventListener('click', startGame);
  document.getElementById('btn-resume').addEventListener('click', resumeGame);
  document.getElementById('btn-menu').addEventListener('click', toMenu);

  window.addEventListener('keydown', (e) => {
    keys[e.code] = true;
    if (e.code === 'Escape') {
      if (paused) resumeGame();
      else if (running) pauseGame();
    }
    if (!running || paused) return;
    if (e.code === 'KeyR') reload();
    if (e.code === 'Digit1') switchWeapon('rifle');
    if (e.code === 'Digit2') switchWeapon('pistol');
  });
  window.addEventListener('keyup', (e) => { keys[e.code] = false; });

  canvas.addEventListener('mousedown', (e) => {
    if (e.button === 0) {
      keys['Mouse0'] = true;
      if (running && !paused) playerShoot();
    }
  });
  window.addEventListener('mouseup', (e) => {
    if (e.button === 0) keys['Mouse0'] = false;
  });

  document.addEventListener('mousemove', (e) => {
    if (!running || paused) return;
    if (document.pointerLockElement === canvas) {
      player.angle += e.movementX * 0.0025;
    }
  });

  canvas.addEventListener('click', () => {
    if (running && !paused) canvas.requestPointerLock();
  });

  window.addEventListener('resize', resize);
  resize();
})();
