/** Raycasting renderer + player movement */
window.Engine = (function () {
  const FOV = Math.PI / 3;
  const MAX_DIST = 20;

  function raycast(px, py, angle, map) {
    const sin = Math.sin(angle), cos = Math.cos(angle);
    let dist = 0;
    const step = 0.02;
    let hit = 0;
    let side = 0;
    let lx = px, ly = py;
    while (dist < MAX_DIST) {
      dist += step;
      const x = px + cos * dist;
      const y = py + sin * dist;
      if (map.solid(x, y)) {
        hit = 1;
        // approximate side for shading
        side = Math.abs(Math.floor(x) - Math.floor(lx)) > 0 ? 0 : 1;
        break;
      }
      lx = x; ly = y;
    }
    return { dist: dist * Math.cos(angle - (window._playerAngle || angle)), hit, side, raw: dist };
  }

  function render(ctx, w, h, player, bots, map, particles) {
    // sky / floor
    const grd = ctx.createLinearGradient(0, 0, 0, h / 2);
    grd.addColorStop(0, '#1a2332');
    grd.addColorStop(1, '#2d3a4d');
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, w, h / 2);
    const grd2 = ctx.createLinearGradient(0, h / 2, 0, h);
    grd2.addColorStop(0, '#1c1210');
    grd2.addColorStop(1, '#0a0808');
    ctx.fillStyle = grd2;
    ctx.fillRect(0, h / 2, w, h / 2);

    const rays = Math.min(w, 320);
    const colW = w / rays;
    window._playerAngle = player.angle;

    // walls
    const zBuf = new Float32Array(rays);
    for (let i = 0; i < rays; i++) {
      const a = player.angle - FOV / 2 + (i / rays) * FOV;
      const r = raycast(player.x, player.y, a, map);
      zBuf[i] = r.raw;
      if (!r.hit) continue;
      const wallH = Math.min(h * 1.5, (h * 0.85) / (r.dist + 0.0001));
      const shade = Math.max(0.25, 1 - r.dist / MAX_DIST) * (r.side ? 0.7 : 1);
      const c = Math.floor(40 + shade * 90);
      ctx.fillStyle = 'rgb(' + c + ',' + Math.floor(c * 0.85) + ',' + Math.floor(c * 0.65) + ')';
      const y0 = (h - wallH) / 2;
      ctx.fillRect(i * colW, y0, colW + 1, wallH);
    }

    // bots as sprites (billboard)
    const visibles = bots
      .filter((b) => b.alive)
      .map((b) => {
        const dx = b.x - player.x;
        const dy = b.y - player.y;
        const dist = Math.hypot(dx, dy);
        let ang = Math.atan2(dy, dx) - player.angle;
        while (ang > Math.PI) ang -= Math.PI * 2;
        while (ang < -Math.PI) ang += Math.PI * 2;
        return { b, dist, ang };
      })
      .filter((v) => Math.abs(v.ang) < FOV / 2 + 0.15 && v.dist > 0.3)
      .sort((a, b) => b.dist - a.dist);

    visibles.forEach(({ b, dist, ang }) => {
      // occlusion vs walls
      const screenX = (0.5 + ang / FOV) * w;
      const rayIdx = Math.floor((screenX / w) * rays);
      if (rayIdx >= 0 && rayIdx < rays && zBuf[rayIdx] < dist - 0.15) return;

      const size = Math.min(h * 0.9, (h * 0.7) / dist);
      const x = screenX - size * 0.35;
      const y = h / 2 - size * 0.15;

      // body
      ctx.fillStyle = b.team === 't' ? '#8B4513' : '#2a4a7a';
      ctx.fillRect(x, y, size * 0.7, size * 0.85);
      // head
      ctx.fillStyle = '#e0c8a0';
      ctx.beginPath();
      ctx.arc(x + size * 0.35, y - size * 0.08, size * 0.18, 0, Math.PI * 2);
      ctx.fill();
      // HP bar
      ctx.fillStyle = '#333';
      ctx.fillRect(x, y - size * 0.22, size * 0.7, 4);
      ctx.fillStyle = b.hp > 40 ? '#3fb950' : '#da3633';
      ctx.fillRect(x, y - size * 0.22, size * 0.7 * (b.hp / b.maxHp), 4);
    });

    // muzzle / particles
    particles.forEach((p) => {
      ctx.globalAlpha = Math.max(0, p.life);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.sx, p.sy, p.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    // weapon viewmodel
    const bob = Math.sin(player.walkPhase) * 4;
    ctx.fillStyle = '#2a2a2a';
    ctx.fillRect(w * 0.55, h * 0.72 + bob, w * 0.35, h * 0.35);
    ctx.fillStyle = '#3d3d3d';
    ctx.fillRect(w * 0.62, h * 0.68 + bob, w * 0.12, h * 0.12);
    if (player.muzzle > 0) {
      ctx.fillStyle = 'rgba(255,220,100,' + player.muzzle + ')';
      ctx.beginPath();
      ctx.arc(w * 0.68, h * 0.70 + bob, 18 * player.muzzle, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function tryMove(ent, dx, dy, map, radius) {
    const nx = ent.x + dx;
    const ny = ent.y + dy;
    if (!map.solid(nx, ent.y) && !map.solid(nx, ent.y - radius) && !map.solid(nx, ent.y + radius))
      ent.x = nx;
    if (!map.solid(ent.x, ny) && !map.solid(ent.x - radius, ny) && !map.solid(ent.x + radius, ny))
      ent.y = ny;
  }

  return { render, tryMove, FOV, MAX_DIST };
})();
