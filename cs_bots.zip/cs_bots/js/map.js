/** Tile map: 0 empty, 1 wall */
window.MAP = {
  size: 24,
  tiles: null,
  init() {
    const S = this.size;
    const t = Array.from({ length: S }, () => Array(S).fill(0));
    // border walls
    for (let i = 0; i < S; i++) {
      t[0][i] = t[S - 1][i] = t[i][0] = t[i][S - 1] = 1;
    }
    // inner blocks — arena layout
    const blocks = [
      [4, 4, 3, 2], [8, 3, 2, 4], [14, 4, 4, 2], [18, 5, 2, 3],
      [3, 10, 2, 4], [7, 12, 3, 2], [12, 10, 2, 3], [16, 11, 4, 2],
      [5, 17, 3, 2], [10, 16, 2, 4], [15, 17, 3, 2], [19, 15, 2, 3],
      [11, 7, 2, 2],
    ];
    blocks.forEach(([x, y, w, h]) => {
      for (let dy = 0; dy < h; dy++)
        for (let dx = 0; dx < w; dx++)
          if (y + dy < S && x + dx < S) t[y + dy][x + dx] = 1;
    });
    this.tiles = t;
  },
  solid(x, y) {
    const ix = Math.floor(x), iy = Math.floor(y);
    if (iy < 0 || ix < 0 || iy >= this.size || ix >= this.size) return true;
    return this.tiles[iy][ix] === 1;
  },
  /** Random empty cell center */
  randomEmpty() {
    for (let n = 0; n < 80; n++) {
      const x = 1.5 + Math.random() * (this.size - 3);
      const y = 1.5 + Math.random() * (this.size - 3);
      if (!this.solid(x, y) && !this.solid(x + 0.3, y) && !this.solid(x, y + 0.3))
        return { x, y };
    }
    return { x: 2.5, y: 2.5 };
  },
};

window.WEAPONS = {
  rifle: {
    name: 'AK',
    dmg: 28,
    rpm: 600,
    mag: 30,
    reserve: 90,
    spread: 0.018,
    range: 18,
    reloadMs: 2200,
    auto: true,
  },
  pistol: {
    name: 'Glock',
    dmg: 22,
    rpm: 400,
    mag: 20,
    reserve: 60,
    spread: 0.028,
    range: 12,
    reloadMs: 1600,
    auto: false,
  },
};
