/** Simple bot AI: chase player, shoot when in LOS */
window.BotAI = (function () {
  function create(map, difficulty) {
    const pos = map.randomEmpty();
    const mult = difficulty === 'easy' ? 0.7 : difficulty === 'hard' ? 1.35 : 1;
    return {
      x: pos.x,
      y: pos.y,
      angle: Math.random() * Math.PI * 2,
      hp: 100,
      maxHp: 100,
      alive: true,
      team: 't',
      speed: 1.6 * mult,
      accuracy: 0.04 / mult,
      reaction: (difficulty === 'easy' ? 0.55 : difficulty === 'hard' ? 0.15 : 0.35),
      shootCd: 0,
      thinkCd: 0,
      name: 'Bot' + Math.floor(Math.random() * 90 + 10),
    };
  }

  function hasLOS(ax, ay, bx, by, map) {
    const dist = Math.hypot(bx - ax, by - ay);
    const steps = Math.ceil(dist * 8);
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      if (map.solid(ax + (bx - ax) * t, ay + (by - ay) * t)) return false;
    }
    return true;
  }

  function update(bot, player, map, dt, difficulty, onBotShoot) {
    if (!bot.alive || !player.alive) return;

    bot.shootCd = Math.max(0, bot.shootCd - dt);
    bot.thinkCd = Math.max(0, bot.thinkCd - dt);

    const dx = player.x - bot.x;
    const dy = player.y - bot.y;
    const dist = Math.hypot(dx, dy);
    const targetAng = Math.atan2(dy, dx);

    // smooth turn
    let diff = targetAng - bot.angle;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    bot.angle += diff * Math.min(1, 4 * dt);

    const los = dist < 14 && hasLOS(bot.x, bot.y, player.x, player.y, map);

    if (los && dist < 12) {
      // strafe + shoot
      if (dist > 4) {
        const mx = Math.cos(bot.angle) * bot.speed * dt * 0.7;
        const my = Math.sin(bot.angle) * bot.speed * dt * 0.7;
        Engine.tryMove(bot, mx, my, map, 0.25);
      } else {
        // back off a bit
        const mx = -Math.cos(bot.angle) * bot.speed * dt * 0.4;
        const my = -Math.sin(bot.angle) * bot.speed * dt * 0.4;
        Engine.tryMove(bot, mx, my, map, 0.25);
      }
      // lateral strafe
      if (bot.thinkCd <= 0) {
        bot.strafeDir = Math.random() > 0.5 ? 1 : -1;
        bot.thinkCd = 0.6 + Math.random();
      }
      const sx = Math.cos(bot.angle + Math.PI / 2) * bot.strafeDir * bot.speed * dt * 0.5;
      const sy = Math.sin(bot.angle + Math.PI / 2) * bot.strafeDir * bot.speed * dt * 0.5;
      Engine.tryMove(bot, sx, sy, map, 0.25);

      if (bot.shootCd <= 0 && Math.abs(diff) < 0.35) {
        bot.shootCd = difficulty === 'hard' ? 0.28 : difficulty === 'easy' ? 0.55 : 0.4;
        if (Math.random() > bot.reaction) {
          onBotShoot(bot, dist);
        }
      }
    } else {
      // roam toward player roughly
      const mx = Math.cos(bot.angle) * bot.speed * dt;
      const my = Math.sin(bot.angle) * bot.speed * dt;
      const before = { x: bot.x, y: bot.y };
      Engine.tryMove(bot, mx, my, map, 0.25);
      if (Math.hypot(bot.x - before.x, bot.y - before.y) < 0.01) {
        bot.angle += (Math.random() - 0.5) * 1.5;
      }
    }
  }

  function respawn(bot, map) {
    const p = map.randomEmpty();
    bot.x = p.x;
    bot.y = p.y;
    bot.hp = bot.maxHp;
    bot.alive = true;
    bot.angle = Math.random() * Math.PI * 2;
    bot.shootCd = 1;
  }

  return { create, update, respawn, hasLOS };
})();
